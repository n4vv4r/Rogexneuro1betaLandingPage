# PRISMA Engine 0.1.0 — Quickstart (Linux x86_64)

## Run
```bash
chmod +x ./prisma-engine
./prisma-engine --headless --bench-samples 20000   # latency bench
./prisma-engine                                    # native GUI (egui)
```

## Flags
```
--backend simd|akida   # default: simd (AVX2 LIF)
--headless             # no GUI
--channels 8
--sample-rate 250
--neurons 256
--mode mixed|alpha|beta|blink|quiet
```

## Targets (measured on AMD Ryzen 5 · AVX2 release)
- Mean hot-path latency ≈ 2 µs/sample (≪ 1 ms)
- Zero-allocation critical path
- Footprint target < 64 MB RAM

## Limits
Experimental research software. **Not a medical device.**
No diagnosis, no clinical claims.

## Akida stub
```bash
PRISMA_AKIDA_SIM=1 ./prisma-engine --backend akida --headless
```
