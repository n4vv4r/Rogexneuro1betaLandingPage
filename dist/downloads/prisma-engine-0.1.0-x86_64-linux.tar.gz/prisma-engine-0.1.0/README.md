# PRISMA Engine

**Ultra-low-latency native EEG/BCI neuromorphic processor** for x86_64.

Replaces the Python/Streamlit stack with a pure Rust runtime:

| Constraint | Target |
|---|---|
| Language | Rust (C23 hooks ready via HAL) |
| RAM footprint | &lt; 64 MB |
| Event latency | &lt; 1 ms (hot path) |
| Hot path | **Zero dynamic allocation** |
| GUI | egui / eframe @ 60+ FPS |
| NPU | SIMD software emulator + Akida AKD1000 stub |

> Experimental research software. **Not a medical device.**

---

## Architecture

```
ADC / Synth ──► SPSC ring (lock-free, zero-copy)
                    │
                    ▼
            Delta Modulation (θ_adp adaptive)
              idle if |ΔV| < θ_adp
                    │ spikes UP/DOWN
                    ▼
         ┌──────────────────────┐
         │  Neuromorphic HAL    │
         ├──────────┬───────────┤
         │ Backend A│ Backend B │
         │ SIMD LIF │ Akida     │
         │ AVX2/512 │ AKD1000   │
         │ STDP+PC  │ (stub)    │
         └────┬─────┴─────┬─────┘
              ▼           ▼
         Telemetry snapshot ──► egui GUI
```

### Modules

| File | Role |
|---|---|
| `spsc_ring.rs` | Lock-free SPSC circular buffer, cache-line padded |
| `delta_mod.rs` | Adaptive delta modulation → spike trains |
| `snn_lif_avx2.rs` | LIF SNN with AVX2 (runtime detect) + scalar fallback |
| `stdp.rs` | STDP plasticity + local synaptic inhibition |
| `predictive_coding.rs` | Prediction-error anomaly / artifact scores |
| `hal/` | Trait + `SimdSnBackend` + `AkidaStubBackend` |
| `gui_renderer.rs` | egui waveforms, raster, spectrum |
| `pipeline.rs` | Producer/consumer real-time orchestration |

---

## Build

```bash
cd prisma-engine

# Debug
cargo build

# Release (LTO, stripped)
cargo build --release

# Headless only (no egui deps)
cargo build --release --no-default-features --features simd-avx2
```

### Run

```bash
# Native GUI
cargo run --release

# Headless throughput bench (50k samples)
cargo run --release -- --headless --bench-samples 50000

# Live headless 10 s
cargo run --release -- --headless --bench-samples 0 --seconds 10

# Akida stub in sim mode
PRISMA_AKIDA_SIM=1 cargo run --release -- --backend akida --headless
```

### Tests & benches

```bash
cargo test
cargo bench --bench hot_path
```

---

## Production packaging → `/dist`

```bash
chmod +x scripts/build_release.sh
./scripts/build_release.sh
```

Produces (repo root):

```
dist/
  linux/prisma-engine-<ver>-<arch>-linux.tar.gz
  windows/prisma.iss          # Inno Setup → PRISMA-Engine-<ver>-Setup.exe
  windows/prisma.nsi          # NSIS alternative
  macos/create_dmg.sh         # → PRISMA-Engine-<ver>.dmg  (run on macOS)
  macos/prisma-engine.app/    # bundle skeleton
  checksums/SHA256SUMS
  MANIFEST.txt
```

Cross-compile examples:

```bash
# Windows GNU
rustup target add x86_64-pc-windows-gnu
TARGET=x86_64-pc-windows-gnu ./scripts/build_release.sh

# macOS (on Darwin host)
TARGET=x86_64-apple-darwin ./scripts/build_release.sh
```

---

## HAL: adding a real Akida driver

1. Implement `hal::AkidaTransport` (PCIe BAR + DMA rings, or SPI).
2. In `AkidaStubBackend::probe_device`, call your transport instead of `DeviceMissing`.
3. Map `EngineConfig` LIF/STDP fields onto the MetaTF / on-chip network blob.
4. Keep `NeuromorphicHal::process_spikes` zero-alloc (pre-map DMA buffers at `open()`).

---

## License

MIT OR Apache-2.0. Experimental — no warranty, not for clinical use.
