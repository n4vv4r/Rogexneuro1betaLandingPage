#!/usr/bin/env bash
# =============================================================================
# PRISMA Engine — production release builder
# Emits installable artifacts into ../../dist (repo root /dist) or ./dist
# =============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO_ROOT="$(cd "$ROOT/.." && pwd)"
DIST="${DIST_DIR:-$REPO_ROOT/dist}"
VERSION="$(grep -m1 '^version' "$ROOT/Cargo.toml" | sed 's/.*"\(.*\)"/\1/')"
HOST_TRIPLE="$(rustc -vV | sed -n 's/^host: //p')"
TARGET="${TARGET:-$HOST_TRIPLE}"
FEATURES="${FEATURES:-gui,simd-avx2,synth}"
PROFILE="${PROFILE:-release}"
APP_NAME="prisma-engine"
PRODUCT_NAME="PRISMA Engine"

cd "$ROOT"

echo "════════════════════════════════════════════════════════"
echo " PRISMA Engine release build"
echo " version : $VERSION"
echo " target  : $TARGET"
echo " features: $FEATURES"
echo " dist    : $DIST"
echo "════════════════════════════════════════════════════════"

mkdir -p "$DIST"/{linux,windows,macos,checksums}

# ---------------------------------------------------------------------------
# 1. Native binary
# ---------------------------------------------------------------------------
echo "[1/4] cargo build --$PROFILE --target $TARGET …"
cargo build --"$PROFILE" --target "$TARGET" --features "$FEATURES"

BIN_SRC="$ROOT/target/$TARGET/$PROFILE/$APP_NAME"
if [[ ! -f "$BIN_SRC" ]]; then
  # Host build without explicit target dir layout on some setups
  BIN_SRC="$ROOT/target/$PROFILE/$APP_NAME"
fi
if [[ ! -f "$BIN_SRC" ]]; then
  echo "ERROR: binary not found after build" >&2
  exit 1
fi

# ---------------------------------------------------------------------------
# 2. Stage platform-specific packages
# ---------------------------------------------------------------------------
STAGE="$DIST/_stage"
rm -rf "$STAGE"
mkdir -p "$STAGE/$APP_NAME"
cp "$BIN_SRC" "$STAGE/$APP_NAME/"
cp "$ROOT/README.md" "$STAGE/$APP_NAME/" 2>/dev/null || true
# License placeholder
cat > "$STAGE/$APP_NAME/LICENSE.txt" <<EOF
PRISMA Engine — experimental research software.
Not a medical device. No warranty.
EOF

OS_FAMILY="$(uname -s | tr '[:upper:]' '[:lower:]')"
ARCH="$(uname -m)"

# Always produce a portable tarball of the binary for the host.
TARBALL="$DIST/linux/${APP_NAME}-${VERSION}-${ARCH}-linux.tar.gz"
if [[ "$OS_FAMILY" == "linux" ]]; then
  echo "[2/4] packaging Linux tarball → $TARBALL"
  tar -C "$STAGE" -czf "$TARBALL" "$APP_NAME"
  # Also copy raw binary for convenience
  cp "$BIN_SRC" "$DIST/linux/${APP_NAME}-${VERSION}"
fi

# ---------------------------------------------------------------------------
# 3. Windows installer (Inno Setup) — build when cross or on Windows / wine
# ---------------------------------------------------------------------------
echo "[3/4] Windows packaging …"
ISS="$ROOT/scripts/packaging/windows/prisma.iss"
WIN_DIR="$DIST/windows"
mkdir -p "$WIN_DIR"

# Stage a Windows layout even if we only have the Linux binary today —
# when TARGET is a Windows triple the binary is the real .exe.
if [[ "$TARGET" == *windows* ]]; then
  EXE_SRC="$ROOT/target/$TARGET/$PROFILE/${APP_NAME}.exe"
  cp "$EXE_SRC" "$WIN_DIR/${APP_NAME}.exe"
  # Generate Inno script with substituted paths
  sed -e "s|@APP_VERSION@|${VERSION}|g" \
      -e "s|@DIST_WINDOWS@|${WIN_DIR}|g" \
      -e "s|@SOURCE_EXE@|${EXE_SRC}|g" \
      "$ISS" > "$WIN_DIR/prisma.iss"
  if command -v iscc >/dev/null 2>&1; then
    iscc "$WIN_DIR/prisma.iss"
    echo "  → Inno Setup installer written under $WIN_DIR"
  elif command -v docker >/dev/null 2>&1; then
    echo "  iscc not found; wrote $WIN_DIR/prisma.iss (run with Inno Setup / CI image)"
  else
    echo "  iscc not found; wrote $WIN_DIR/prisma.iss + ${APP_NAME}.exe"
  fi
else
  # Emit packaging sources so CI can build the .exe later.
  sed -e "s|@APP_VERSION@|${VERSION}|g" \
      -e "s|@DIST_WINDOWS@|${WIN_DIR}|g" \
      -e "s|@SOURCE_EXE@|${APP_NAME}.exe|g" \
      "$ISS" > "$WIN_DIR/prisma.iss"
  cat > "$WIN_DIR/README_BUILD.txt" <<EOF
Windows installer sources for PRISMA Engine ${VERSION}

To produce the final .exe installer:
  1. Cross-compile:
       cargo build --release --target x86_64-pc-windows-gnu --features gui,simd-avx2
     or use a Windows CI runner (MSVC).
  2. Copy prisma-engine.exe next to prisma.iss
  3. Run: iscc prisma.iss
     (Inno Setup 6 — https://jrsoftware.org/isinfo.php)

NSIS alternative: see nsis/prisma.nsi in packaging/windows/.
EOF
  # NSIS script copy
  if [[ -f "$ROOT/scripts/packaging/windows/prisma.nsi" ]]; then
    cp "$ROOT/scripts/packaging/windows/prisma.nsi" "$WIN_DIR/"
  fi
  echo "  → staged Windows packaging sources in $WIN_DIR"
fi

# ---------------------------------------------------------------------------
# 4. macOS .dmg
# ---------------------------------------------------------------------------
echo "[4/4] macOS packaging …"
MAC_DIR="$DIST/macos"
mkdir -p "$MAC_DIR"
DMG_SCRIPT="$ROOT/scripts/packaging/macos/create_dmg.sh"

if [[ "$OS_FAMILY" == "darwin" ]]; then
  bash "$DMG_SCRIPT" \
    --bin "$BIN_SRC" \
    --version "$VERSION" \
    --out "$MAC_DIR" \
    --name "$PRODUCT_NAME"
else
  # Emit script + app bundle skeleton for CI (macOS runner).
  cp "$DMG_SCRIPT" "$MAC_DIR/"
  cat > "$MAC_DIR/README_BUILD.txt" <<EOF
macOS .dmg packaging for PRISMA Engine ${VERSION}

On a macOS host (or GitHub Actions macos-latest):
  1. cargo build --release --target x86_64-apple-darwin   # or aarch64-apple-darwin
  2. bash create_dmg.sh --bin path/to/prisma-engine --version ${VERSION} --out . --name "PRISMA Engine"

The resulting .dmg is ad-hoc signed-ready (codesign -s -) and notarization hooks
are documented inside create_dmg.sh.
EOF
  # Also produce a portable "bundle layout" zip that macOS CI can finish.
  APP_BUNDLE="$MAC_DIR/${APP_NAME}.app"
  mkdir -p "$APP_BUNDLE/Contents/MacOS" "$APP_BUNDLE/Contents/Resources"
  cat > "$APP_BUNDLE/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>${PRODUCT_NAME}</string>
  <key>CFBundleDisplayName</key><string>${PRODUCT_NAME}</string>
  <key>CFBundleIdentifier</key><string>local.rogex.prisma-engine</string>
  <key>CFBundleVersion</key><string>${VERSION}</string>
  <key>CFBundleShortVersionString</key><string>${VERSION}</string>
  <key>CFBundleExecutable</key><string>${APP_NAME}</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST
  # Placeholder binary note
  echo "Replace with real prisma-engine binary on macOS CI" > "$APP_BUNDLE/Contents/MacOS/README"
  echo "  → staged macOS app skeleton + create_dmg.sh in $MAC_DIR"
fi

# ---------------------------------------------------------------------------
# Checksums
# ---------------------------------------------------------------------------
echo "Writing checksums …"
(
  cd "$DIST"
  find . -type f \( -name '*.tar.gz' -o -name '*.exe' -o -name '*.dmg' -o -name 'prisma-engine-*' \) \
    ! -path './_stage/*' ! -path './checksums/*' -print0 \
    | sort -z \
    | xargs -0 -r sha256sum
) > "$DIST/checksums/SHA256SUMS" || true

# Manifest
cat > "$DIST/MANIFEST.txt" <<EOF
PRISMA Engine ${VERSION}
Built: $(date -u +%Y-%m-%dT%H:%M:%SZ)
Host:  ${HOST_TRIPLE}
Target:${TARGET}
Features: ${FEATURES}

Artifacts:
$(find "$DIST" -type f ! -path '*/_stage/*' | sort | sed "s|$DIST/||")
EOF

rm -rf "$STAGE"
echo "════════════════════════════════════════════════════════"
echo " Done. Artifacts in: $DIST"
echo "════════════════════════════════════════════════════════"
ls -la "$DIST"/*/ 2>/dev/null || ls -la "$DIST"
