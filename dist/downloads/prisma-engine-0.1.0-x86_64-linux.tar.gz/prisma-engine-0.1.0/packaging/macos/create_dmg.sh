#!/usr/bin/env bash
# Create a structured, signable .dmg for PRISMA Engine on macOS.
set -euo pipefail

BIN=""
VERSION="0.1.0"
OUT="."
NAME="PRISMA Engine"
BUNDLE_ID="local.rogex.prisma-engine"
APP_EXEC="prisma-engine"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --bin) BIN="$2"; shift 2 ;;
    --version) VERSION="$2"; shift 2 ;;
    --out) OUT="$2"; shift 2 ;;
    --name) NAME="$2"; shift 2 ;;
    *) echo "Unknown arg: $1" >&2; exit 1 ;;
  esac
done

if [[ -z "$BIN" || ! -f "$BIN" ]]; then
  echo "Usage: $0 --bin /path/to/prisma-engine [--version X] [--out dir] [--name 'PRISMA Engine']" >&2
  exit 1
fi

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "create_dmg.sh must run on macOS (hdiutil required)" >&2
  exit 1
fi

STAGE="$(mktemp -d)"
APP="$STAGE/${NAME}.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>${NAME}</string>
  <key>CFBundleDisplayName</key><string>${NAME}</string>
  <key>CFBundleIdentifier</key><string>${BUNDLE_ID}</string>
  <key>CFBundleVersion</key><string>${VERSION}</string>
  <key>CFBundleShortVersionString</key><string>${VERSION}</string>
  <key>CFBundleExecutable</key><string>${APP_EXEC}</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>CFBundleIconFile</key><string>AppIcon</string>
</dict>
</plist>
PLIST

cp "$BIN" "$APP/Contents/MacOS/${APP_EXEC}"
chmod +x "$APP/Contents/MacOS/${APP_EXEC}"

# Ad-hoc sign so Gatekeeper is slightly happier on local builds.
if command -v codesign >/dev/null 2>&1; then
  codesign --force --deep --sign - "$APP" || true
fi

# Applications symlink for drag-install UX
ln -s /Applications "$STAGE/Applications"

DMG_RW="$OUT/PRISMA-Engine-${VERSION}-rw.dmg"
DMG_FINAL="$OUT/PRISMA-Engine-${VERSION}.dmg"
rm -f "$DMG_RW" "$DMG_FINAL"

hdiutil create -volname "$NAME" -srcfolder "$STAGE" -ov -format UDRW "$DMG_RW"
# Convert to compressed read-only UDZO
hdiutil convert "$DMG_RW" -format UDZO -imagekey zlib-level=9 -o "$DMG_FINAL"
rm -f "$DMG_RW"
rm -rf "$STAGE"

# Optional notarization hooks (requires Apple Developer ID):
#   xcrun notarytool submit "$DMG_FINAL" --apple-id ... --team-id ... --password ... --wait
#   xcrun stapler staple "$DMG_FINAL"

echo "Created: $DMG_FINAL"
shasum -a 256 "$DMG_FINAL"
