; NSIS alternative installer for PRISMA Engine
; Usage: makensis /DVERSION=0.1.0 prisma.nsi

!ifndef VERSION
  !define VERSION "0.1.0"
!endif

Name "PRISMA Engine ${VERSION}"
OutFile "PRISMA-Engine-${VERSION}-Setup.exe"
InstallDir "$LOCALAPPDATA\PRISMA Engine"
RequestExecutionLevel user
Unicode True
SetCompressor /SOLID lzma

Page directory
Page instfiles

Section "Install"
  SetOutPath "$INSTDIR"
  File "prisma-engine.exe"
  File /nonfatal "LICENSE.txt"
  File /nonfatal "README.md"
  CreateShortcut "$SMPROGRAMS\PRISMA Engine.lnk" "$INSTDIR\prisma-engine.exe"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
SectionEnd

Section "Uninstall"
  Delete "$INSTDIR\prisma-engine.exe"
  Delete "$INSTDIR\LICENSE.txt"
  Delete "$INSTDIR\README.md"
  Delete "$INSTDIR\Uninstall.exe"
  Delete "$SMPROGRAMS\PRISMA Engine.lnk"
  RMDir "$INSTDIR"
SectionEnd
