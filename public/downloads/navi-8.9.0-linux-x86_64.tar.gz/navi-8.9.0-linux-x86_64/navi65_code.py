"""
NAVI 6.5 — compositor de código.

No es Copilot. Catálogo de primitivas + composición + dry-run entero.
Si no hay esquema: DESCONOCIDO. No alucino APIs.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple


def _norm(text: str) -> str:
    t = text.lower()
    for a, b in (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
        t = t.replace(a, b)
    return t


@dataclass(frozen=True)
class Primitive:
    name: str
    keys: Tuple[str, ...]
    c: str
    py: str
    dry: Callable[[], str]


def _rev() -> str:
    a = [1, 2, 3, 4]
    return f"reverse({a}) -> {list(reversed(a))}"


def _clamp() -> str:
    def clamp(v):
        return 100 if v > 100 else (-100 if v < -100 else v)

    return f"clamp(140)={clamp(140)} clamp(-200)={clamp(-200)} clamp(7)={clamp(7)}"


def _lif() -> str:
    v, tau, dt = 80, 20, 5
    out = (v * tau) // (tau + dt)
    return f"lif_decay(V={v}, tau={tau}, dt={dt}) -> {out}"


def _strlen() -> str:
    s = "wsp"
    return f'u8len("{s}") -> {len(s)}'


def _sat16() -> str:
    t = 30000 + 4000
    if t > 32767:
        t = 32767
    return f"sat_add16(30000, 4000) -> {t}"


def _gcd() -> str:
    def gcd(a, b):
        while b:
            a, b = b, a % b
        return a

    return f"gcd(48, 18) -> {gcd(48, 18)}"


def _fib() -> str:
    a, b = 0, 1
    for _ in range(8):
        a, b = b, a + b
    return f"fib_iter(8) -> {a}"


def _crc8() -> str:
    data = bytes([2, 31, 41, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    crc = 0
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return f"crc8(15 B WSP prefix) -> 0x{crc:02X}"


CATALOG: List[Primitive] = [
    Primitive(
        "reverse",
        ("invert", "reverse", "array", "revierte"),
        "void rev_u8(uint8_t *a, int n){\n"
        "  int i,t; for(i=0;i<n/2;i++){ t=a[i]; a[i]=a[n-1-i]; a[n-1-i]=(uint8_t)t; }\n}",
        "def rev_u8(a):\n    return list(reversed(a))",
        _rev,
    ),
    Primitive(
        "clamp",
        ("clamp", "satura", "limita"),
        "int8_t clamp_i8(int v){\n"
        "  if(v>100) return 100;\n  if(v<-100) return -100; return (int8_t)v;\n}",
        "def clamp_i8(v):\n    return 100 if v>100 else (-100 if v<-100 else v)",
        _clamp,
    ),
    Primitive(
        "lif_decay",
        ("lif", "decay", "fuga", "tau"),
        "int32_t lif_decay(int32_t V, uint32_t tau, uint32_t dt){\n"
        "  if(!dt||!tau) return V;\n"
        "  return (int32_t)(((int64_t)V*tau)/(tau+dt));\n}",
        "def lif_decay(V, tau, dt):\n    return V if not dt or not tau else (V * tau) // (tau + dt)",
        _lif,
    ),
    Primitive(
        "strlen",
        ("strlen", "longitud", "u8len"),
        "int u8len(const char *s){\n  int n=0; if(!s) return 0;\n  while(s[n]) n++; return n;\n}",
        "def u8len(s):\n    return 0 if s is None else len(s)",
        _strlen,
    ),
    Primitive(
        "sat_add16",
        ("sat_add", "saturat", "int16"),
        "int16_t sat_add16(int16_t a, int16_t b){\n"
        "  int32_t t=(int32_t)a+b;\n"
        "  if(t>32767) t=32767; if(t<-32767) t=-32767;\n  return (int16_t)t;\n}",
        "def sat_add16(a, b):\n    t=a+b\n    return 32767 if t>32767 else (-32767 if t<-32767 else t)",
        _sat16,
    ),
    Primitive(
        "gcd",
        ("gcd", "mcd", "euclides"),
        "int gcd_u(int a, int b){\n  int t; if(a<0) a=-a; if(b<0) b=-b;\n"
        "  while(b){ t=a%b; a=b; b=t; } return a;\n}",
        "def gcd_u(a, b):\n    a, b = abs(a), abs(b)\n    while b:\n        a, b = b, a % b\n    return a",
        _gcd,
    ),
    Primitive(
        "fib_iter",
        ("fibonacci", "fib "),
        "int fib_iter(int n){\n  int a=0,b=1,i,t; if(n<=0) return 0;\n"
        "  for(i=1;i<n;i++){ t=a+b; a=b; b=t; } return b;\n}",
        "def fib_iter(n):\n    a, b = 0, 1\n    if n<=0: return 0\n    for _ in range(1, n):\n        a, b = b, a+b\n    return b",
        _fib,
    ),
    Primitive(
        "for_loop",
        ("bucle", "loop", "un for", "for loop", "haga un bucle", "hace un bucle"),
        "int main(void){\n"
        "  int i;\n"
        "  for(i = 0; i < 10; i++){\n"
        "    /* cuerpo */\n"
        "  }\n"
        "  return 0;\n}",
        "def main():\n    for i in range(10):\n        pass  # cuerpo",
        lambda: "for i in 0..9 (10 iteraciones)",
    ),
    Primitive(
        "wsp16",
        ("wsp", "rogexwsp", "postal", "16 bytes", "16 b"),
        "/* WSP 16 B: quien, verbo, objeto, cuando + amplitudes clasicas. No qubits. */\n"
        "typedef struct {\n"
        "  uint8_t who, verb, obj, when;\n"
        "  uint8_t amp[12];\n"
        "} wsp16_t;\n"
        "static void wsp16_clear(wsp16_t *p){\n"
        "  int i; if(!p) return;\n"
        "  p->who=p->verb=p->obj=p->when=0;\n"
        "  for(i=0;i<12;i++) p->amp[i]=0;\n"
        "}",
        "class WSP16:\n"
        "    def __init__(self):\n"
        "        self.who = self.verb = self.obj = self.when = 0\n"
        "        self.amp = [0] * 12  # 16 bytes: 4 + 12",
        lambda: "WSP16 = 4 B cabecera + 12 B amplitudes = 16 B",
    ),
    Primitive(
        "q6_cube",
        ("q6", "6-cubo", "6cube", "hipercubo de 6", "hipercubo q6"),
        "/* Q6: 64 LIF en el 6-cubo. Constantes de NAVI_AI_SNN/c/navi_q6.h. 0% FPU. */\n"
        "#define NAVI_DIM 6\n"
        "#define NAVI_N   64\n"
        "#define NAVI_VTH 40\n"
        "#define NAVI_LEAK_NUM 7\n"
        "#define NAVI_LEAK_DEN 8\n"
        "static unsigned hamming6(unsigned a, unsigned b){\n"
        "  unsigned x=a^b, n=0; while(x){ n+=x&1u; x>>=1; } return n;\n"
        "}\n"
        "static int lif_step(int v, int stim){\n"
        "  v = (v * NAVI_LEAK_NUM) / NAVI_LEAK_DEN + stim;\n"
        "  if(v >= NAVI_VTH) return 0; /* spike y reset */\n"
        "  return v;\n"
        "}",
        "DIM, N, VTH = 6, 64, 40\n"
        "def hamming6(a, b):\n"
        "    return bin(a ^ b).count('1')\n"
        "def lif_step(v, stim, leak_num=7, leak_den=8):\n"
        "    v = (v * leak_num) // leak_den + stim\n"
        "    return 0 if v >= VTH else v  # spike → reset",
        lambda: "Q6: 64 vertices, grado 6, Vth=40, leak 7/8 (entero)",
    ),
    Primitive(
        "crc8",
        ("crc", "crc8", "checksum"),
        "uint8_t crc8(const uint8_t *p, int n){\n"
        "  uint8_t c=0; int i,b;\n"
        "  for(i=0;i<n;i++){ c^=p[i]; for(b=0;b<8;b++)\n"
        "    c=(uint8_t)((c&0x80)?((c<<1)^0x07):(c<<1)); }\n  return c;\n}",
        "def crc8(data):\n    c=0\n    for x in data:\n        c^=x\n        for _ in range(8):\n"
        "            c=((c<<1)^0x07)&0xFF if c&0x80 else (c<<1)&0xFF\n    return c",
        _crc8,
    ),
]


HELLO = {
    "c": (
        "#include <stdio.h>\n"
        "int main(void){\n"
        "  printf(\"hola mundo\\n\");\n"
        "  return 0;\n"
        "}"
    ),
    "python": 'print("hola mundo")',
    "rust": 'fn main() {\n    println!("hola mundo");\n}',
    "html": (
        "<!DOCTYPE html>\n"
        "<html lang=\"es\">\n"
        "<head><meta charset=\"utf-8\"><title>hola mundo</title></head>\n"
        "<body><p>hola mundo</p></body>\n"
        "</html>"
    ),
    "js": 'console.log("hola mundo");',
}


def detect_lang(text: str) -> str:
    t = _norm(text)
    if "html" in t or "htm " in t:
        return "html"
    if "javascript" in t or " en js" in t or " de js" in t or t.endswith(" js") or " js " in t:
        return "js"
    if "python" in t or " py " in t or t.endswith(" py"):
        return "python"
    if "rust" in t:
        return "rust"
    return "c"


def match_primitives(text: str) -> List[Primitive]:
    t = _norm(text)
    hits: List[Primitive] = []
    for p in CATALOG:
        if any(k in t for k in p.keys):
            hits.append(p)
    # unique, catalog order
    seen = set()
    out = []
    for p in hits:
        if p.name not in seen:
            seen.add(p.name)
            out.append(p)
    return out


def compose(text: str) -> Dict:
    lang = detect_lang(text)
    t = _norm(text)
    if "hola mundo" in t or "hello world" in t:
        src = HELLO.get(lang) or HELLO["c"]
        return {
            "ok": True,
            "lang": lang,
            "names": ["hello"],
            "source": src,
            "verified": [f'imprime "hola mundo" ({lang})'],
            "note": "Esqueleto del catalogo. Dry-run entero. No es un LLM.",
        }
    prims = match_primitives(text)
    if not prims:
        return {
            "ok": False,
            "lang": lang,
            "names": [],
            "source": "DESCONOCIDO",
            "verified": [],
            "note": "No hay primitiva en el catalogo. No invento la API.",
        }
    blocks = []
    verified = []
    for p in prims:
        blocks.append(p.py if lang == "python" else p.c)
        verified.append(p.dry())
    src = "\n\n".join(blocks)
    return {
        "ok": True,
        "lang": lang,
        "names": [p.name for p in prims],
        "source": src,
        "verified": verified,
        "note": "Esqueleto del catalogo. Dry-run entero. No es un LLM.",
    }


def render_code(comp: Dict) -> str:
    if not comp.get("ok"):
        return "DESCONOCIDO. G_code no tiene esquema para eso. Pide hola mundo, reverse, clamp, LIF, gcd, fib, crc8, Q6, WSP."
    lines = [
        f"G_code ({comp['lang']}) · {', '.join(comp['names'])}",
        comp["source"],
        "--- dry-run ---",
        *comp["verified"],
        comp["note"],
    ]
    return "\n".join(lines)
