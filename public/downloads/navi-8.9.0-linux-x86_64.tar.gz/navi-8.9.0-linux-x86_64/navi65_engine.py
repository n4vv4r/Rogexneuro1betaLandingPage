"""
NAVI 6.5 — modelo oficial de razonamiento, lenguaje y código.

No es un LLM. El núcleo es el bucle PARSE-RETRIEVE-INFER-VERIFY-RENDER.
Las máscaras G_* (4.5 + reason/math/debug/plan/teach) solo pintan.
NAVI 6 (DAG + world-model) se llama cuando el esquema es causal.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from navi65_code import render_code
from navi65_masks import (
    g_code,
    g_debug,
    g_logic,
    g_math,
    g_news,
    g_plan,
    g_poem,
    g_reason,
    g_rxos,
    g_talk,
    g_teach,
    g_unknown,
)
from navi65_reason import Trace, plan as plan_trace


@dataclass
class RLCTurn:
    user: str
    reply: str
    mask: str
    ms: float
    internal: Dict = field(default_factory=dict)


class NAVI65Engine:
    """Transductor RLC. Razona siempre. Habla y codea solo con esquema."""

    VERSION = "6.5"
    ROLE = "reasoning-language-code"

    def __init__(self, trained: Optional[Dict] = None):
        self._navi6 = None
        self._trained = trained
        self.last_trace: Optional[Trace] = None
        self.history: List[RLCTurn] = []
        self.self_turns: List[str] = []
        self.lessons: List[Dict] = []
        self.metrics = {
            "turns": 0,
            "unknown": 0,
            "masks": {},
            "reflects": 0,
            "retries": 0,
            "lessons": 0,
            "fitness": 0.55,
        }
        if trained:
            for les in trained.get("lessons", []):
                self.remember(les.get("keys") or [], les.get("mask") or "", les.get("note") or "")

    @property
    def navi6(self):
        if self._navi6 is None:
            from navi6_engine import NAVI6Engine

            self._navi6 = NAVI6Engine(self._trained)
        return self._navi6

    def remember(self, keys, mask: str, note: str = ""):
        keys = [str(k).lower() for k in keys if k]
        if not keys or not mask:
            return
        for les in self.lessons:
            if les["keys"] == keys and les["mask"] == mask:
                return
        self.lessons.append({"keys": keys, "mask": mask, "note": note[:160]})
        self.metrics["lessons"] = len(self.lessons)

    def _apply_lessons(self, user: str, tr: Trace) -> Trace:
        t = user.lower()
        for les in self.lessons:
            if les["keys"] and all(k in t for k in les["keys"]):
                if tr.mask != les["mask"]:
                    tr.mask = les["mask"]
                    tr.unknown = les["mask"] == "unknown"
                    tr.add("LESSON", f"override→G_{les['mask']} ({les.get('note','')})")
                break
        return tr

    def think(self, user: str, show_trace: bool = False) -> RLCTurn:
        t0 = time.perf_counter()
        tr = plan_trace(user)
        tr = self._apply_lessons(user, tr)
        body = self._render_body(user, tr)
        if tr.unknown:
            body = g_unknown(tr.steps[-2].detail if len(tr.steps) >= 2 else "sin esquema")
            self.metrics["unknown"] += 1
        want_trace = show_trace or tr.mask == "reason" or "traza" in user.lower() or "razona" in user.lower()
        if want_trace and not tr.unknown:
            reply = g_reason(tr.as_dict(), body)
        else:
            reply = body
        tr.conclusion = reply
        self.last_trace = tr
        self.metrics["turns"] += 1
        self.metrics["masks"][tr.mask] = self.metrics["masks"].get(tr.mask, 0) + 1
        self.metrics["fitness"] = 0.55 + 0.05 * min(8, len(self.metrics["masks"]))
        ms = (time.perf_counter() - t0) * 1000.0
        turn = RLCTurn(
            user=user,
            reply=reply,
            mask=tr.mask,
            ms=ms,
            internal={
                "trace": tr.as_dict(),
                "version": self.VERSION,
                "role": self.ROLE,
            },
        )
        self.history.append(turn)
        return turn

    def _render_body(self, user: str, tr: Trace) -> str:
        mask = tr.mask
        if mask == "talk":
            return g_talk(user)
        if mask == "logic":
            return g_logic(user, tr.slots)
        if mask == "poem":
            return g_poem(user)
        if mask == "code":
            return g_code(user)
        if mask == "news":
            return g_news(user)
        if mask == "rxos":
            return g_rxos(user)
        if mask == "math":
            return g_math(tr.payload.get("math") or {"ok": False, "err": "sin expresion"})
        if mask == "plan":
            topic = user.strip()[:80]
            return g_plan(topic, tr.payload.get("steps") or [])
        if mask == "teach":
            return g_teach("tema", tr.payload.get("bits") or [])
        if mask in ("debug", "reason"):
            return self._causal(user, tr)
        if mask == "unknown":
            return g_unknown("sin esquema")
        return g_talk(user)

    def _causal(self, user: str, tr: Trace) -> str:
        t6 = self.navi6.think(user)
        body = t6.reply
        if tr.mask == "debug":
            return g_debug(body)
        return body

    def reflect(self) -> RLCTurn:
        """Razonar solo: se pregunta al DAG y responde."""
        q = self.navi6.ask_self()
        self.self_turns.append(q)
        self.metrics["reflects"] += 1
        return self.think(q, show_trace=True)

    def ask_self(self) -> str:
        return self.navi6.ask_self()

    def snapshot(self) -> Dict:
        snap = self.navi6.snapshot()
        snap["lessons"] = list(self.lessons)
        snap["rlc"] = dict(self.metrics)
        snap["version"] = self.VERSION
        return snap


def reply(text: str, engine: Optional[NAVI65Engine] = None) -> RLCTurn:
    eng = engine or NAVI65Engine()
    return eng.think(text)
