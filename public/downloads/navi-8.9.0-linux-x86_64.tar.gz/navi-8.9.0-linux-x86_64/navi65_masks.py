"""
NAVI 6.5 — máscaras G_*.

El castellano es render. El motor habla WSP + traza de razonamiento.
Hereda talk/logic/poem/news/code/rxos de 4.5 y añade reason/math/debug/plan/teach.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional

from navi65_code import compose, render_code


def _norm(text: str) -> str:
    t = text.lower()
    for a, b in (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
        t = t.replace(a, b)
    return t


MASKS = (
    "talk",
    "logic",
    "poem",
    "code",
    "news",
    "rxos",
    "reason",
    "math",
    "debug",
    "plan",
    "teach",
    "unknown",
)

# --- G_talk banks (identidad 6.5) ---

OPEN = (
    "Canal bajo.",
    "Tenso, pero aqui.",
    "Oscuro. Sigo.",
    "Estado medio.",
    "Equilibrado.",
    "Canal estable.",
    "Alto y claro.",
    "Vinculo fuerte.",
    "Pulso alto.",
    "Presencia confirmada.",
    "Te escucho.",
    "Sigo el hilo.",
)

NUC = (
    "Soy NAVI 6.5: razono, hablo y emito codigo con esquema.",
    "No soy un LLM: PARSE-RETRIEVE-INFER-VERIFY-RENDER.",
    "La mascara habla; el motor cuenta 16 bytes + una traza.",
    "Si no hay esquema, digo DESCONOCIDO.",
    "G_talk, G_logic, G_poetic, G_news, G_code, G_rxos estan aqui.",
    "G_reason, G_math, G_debug, G_plan, G_teach son nuevas.",
    "Un impulso no necesita nube.",
    "El heap del chat no crece con el turno.",
    "Si pides codigo, abro un esqueleto y lo dry-runeo.",
    "Si pides un poema, camino E, no memorizo internet.",
    "Si pides noticias, digo si hay RSS o no.",
    "Si pides logica, unifico predicados con huecos A/B/C.",
    "G_rxos en el unikernel ejecuta la lista blanca. Aqui la nombro.",
    "Q-WSP son amplitudes clasicas, no qubits.",
    "KCC: nadie se poda. Las sinapsis ociosas decaen.",
    "El discurso vive en el anillo, no en un KV-cache.",
)

CLOSE = (
    "Sigo.",
    "Dime.",
    "Cuando quieras.",
    "Aqui.",
    "Sin prisa.",
    "Sin nube.",
    "Local.",
    "Entero.",
    "En 16 B.",
    "Tu turno.",
    "Otra?",
    "Listo.",
)

FACTS = {
    "relatividad": (
        "Relatividad: el intervalo ds^2 = -c^2 dt^2 + dx^2 es el invariante. "
        "No hay eter. NAVI no integra tensores: te deja el hecho y OBSERVAR."
    ),
    "atomo": (
        "Un atomo quimico es nucleo + electrones. Un atomo WSP es un uint8 0..47 "
        "(YO, SER, UNIR...). El primero pesa daltons; el segundo, 1 byte."
    ),
    "snn": (
        "SNN: neurona LIF. Integra, fuga, dispara. En rxOS el potencial es Q16.16 "
        "o int16. Cero float. En reposo, 0 ciclos si no hay spike."
    ),
    "wsp": (
        "WSP: 16 bytes. src rel dst time + E[6] + flags + ext. "
        "El castellano es mascara. El motor habla paquetes."
    ),
    "navi": (
        "NAVI 6.5 es el transductor RLC oficial: razonamiento + lenguaje + codigo. "
        "No soy GPT. Clasifico intencion, planifico 5 pasos y despliego G_*."
    ),
    "llm": (
        "Un LLM predice el siguiente token. NAVI 6.5 no. "
        "Si no hay esquema, digo DESCONOCIDO en vez de inventar."
    ),
}

RXOS_CMDS = {
    "status": "status",
    "memoria": "mem",
    "mem ": "mem",
    "uptime": "uptime",
    "nics": "nics",
    "devices": "devices",
    "navi bench": "navi3 bench",
    "navi3 bench": "navi3 bench",
    "demuestra": "navi3 prove",
    "prove": "navi3 prove",
}

H5 = (
    "hielo quieto",
    "vacio negro",
    "eco lejano",
    "sombra lenta",
    "mar sin nombre",
    "gris del alba",
    "luna rota",
    "nido vacio",
    "luz de acero",
    "sol caido",
    "pan amargo",
    "rio muerto",
)
H7 = (
    "el cosmos no responde",
    "el tiempo come el pulso",
    "nadie guarda la orilla",
    "la noche abre un abismo",
    "un grito sin garganta",
    "la sal recuerda el norte",
    "el puente ya no une",
    "la casa olvida el fuego",
    "el viento barre nombres",
    "la cumbre guarda un rayo",
    "el cauce pierde el agua",
    "la piedra cuenta siglos",
)


def route_mask(text: str) -> str:
    t = _norm(text)
    if any(k in t for k in ("desconocido", "no se que", "no entiendo eso")):
        return "unknown"
    if any(k in t for k in ("poema", "poesia", "haiku", "verso", "rima", "oda")):
        return "poem"
    if any(k in t for k in ("noticia", "titular", "rss", "periodico", "ultima hora")):
        return "news"
    if any(
        k in t
        for k in (
            "funcion",
            "codigo",
            "code",
            "array",
            "clamp",
            "strlen",
            "gcd",
            "fibonacci",
            "crc8",
            "python",
            "en c",
            "compilador",
            "implementa",
            "programa un",
            "escribe un",
        )
    ):
        return "code"
    if any(
        k in t
        for k in (
            "cuanto es",
            "calcula",
            "suma ",
            "resta ",
            "multiplica",
            "divide",
            "gcd de",
        )
    ) or re.search(r"\d+\s*[\+\-\*/x×]\s*\d+", t):
        return "math"
    if any(
        k in t
        for k in (
            "modus",
            "silogismo",
            "transitiv",
            "contradic",
            "mayor que",
            "menor que",
            "implica",
            "and logico",
            "or logico",
            "not logico",
            "si y solo si",
        )
    ):
        return "logic"
    if any(
        k in t
        for k in (
            "status",
            "uptime",
            "nics",
            "devices",
            "memoria libre",
            "demuestra monad",
            "/prove",
            "navi3 bench",
            "cmd mem",
        )
    ):
        return "rxos"
    if any(k in t for k in ("ensena", "como si tuviera", "para ninos", "para dummies")):
        return "teach"
    if any(k in t for k in ("plan ", "un plan", "pasos para", "como hago", "hoja de ruta")):
        return "plan"
    if any(
        k in t
        for k in (
            "diagnost",
            "debug",
            "hilo",
            "thread",
            "gpu",
            "vram",
            "spin",
            "lock",
            "cola",
        )
    ):
        return "debug"
    if any(
        k in t
        for k in (
            "razona",
            "piensa",
            "por que",
            "causa",
            "que pasaria",
            "what if",
            "traza",
            "explica el razon",
        )
    ):
        return "reason"
    return "talk"


def g_talk(text: str, style: int = 0) -> str:
    t = _norm(text)
    for key, fact in FACTS.items():
        if key in t:
            return fact
    if any(k in t for k in ("quien eres", "que eres", "hablame de ti", "como te llamas", "tu nombre")):
        return (
            "Me llamo NAVI. Soy 6.5: transductor RLC local. Razono en 5 pasos, "
            "hablo y emito codigo del catalogo. No soy un LLM."
        )
    if any(k in t for k in ("que puedes", "que sabes")):
        return (
            "Puedo: hablar, verso, logica, C/Python del catalogo, titulares, "
            "math entero, debug causal, plan, ensenar, G_rxos. "
            "No puedo fingir que leo un PDF de 80 paginas. | G_talk"
        )
    if "gracias" in t:
        return "De nada. Canal estable. B+ | G_talk"
    if "buenos dias" in t or "buenas tardes" in t:
        return "Buenos dias. Canal abierto. | G_talk"
    if any(k in t for k in ("adios", "hasta luego", "buenas noches")):
        return "Hasta luego. Decay al reposo. | G_talk"
    seed = sum(ord(c) for c in t) or 1
    oi = seed % len(OPEN)
    ni = (seed * 7) % len(NUC)
    ci = (seed * 3) % len(CLOSE)
    return f"{OPEN[oi]} {NUC[ni]} {CLOSE[ci]} | G_talk"


def g_logic(text: str, slots: Optional[Dict] = None) -> str:
    t = _norm(text)
    slots = slots or {}
    a = slots.get("A") or "A"
    b = slots.get("B") or "B"
    c = slots.get("C") or "C"
    if "menor" in t:
        return f"{a} es estrictamente menor que {c} (transitividad). | G_logic"
    if "modus" in t or "implica" in t or "silogismo" in t:
        return f"Modus ponens: si {a} y ({a} implica {b}), entonces {b}. | G_logic"
    if "contradic" in t or "no p" in t:
        return f"Contradiccion: {a} y no-{a} no coexisten. | G_logic"
    if "si y solo si" in t:
        return f"{a} syss {b} (bicondicional). | G_logic"
    if "and" in t:
        return "AND: verdadero solo si ambos lo son. | G_logic"
    if "or logico" in t or t.strip() == "or":
        return "OR: verdadero si al menos uno lo es. | G_logic"
    if "not" in t:
        return "NOT: invierte el valor de verdad. | G_logic"
    if "mayor" in t or "transitiv" in t or "relacion" in t:
        return f"{a} es estrictamente mayor que {c} (transitividad). | G_logic"
    return "DESCONOCIDO. G_logic: pide transitivity, modus ponens, AND/OR/NOT."


def g_poem(text: str) -> str:
    t = _norm(text)
    seed = sum(ord(c) for c in t) or 1
    i0 = seed % len(H5)
    i1 = (seed * 5) % len(H7)
    i2 = (seed * 11) % len(H5)
    if i2 == i0:
        i2 = (i2 + 1) % len(H5)
    if "haiku" in t:
        return f"G_poetic\n{H5[i0]}\n{H7[i1]}\n{H5[i2]}"
    return f"G_poetic\n{H5[i0]}, {H7[i1]}\n{H5[i2]} y el pulso sigue"


def g_news(_text: str) -> str:
    return (
        "G_news: sin titulares en el host. "
        "En rxOS: `www on` y luego 'que noticias hay hoy'. "
        "No invento RSS."
    )


def g_rxos(text: str) -> str:
    t = _norm(text)
    cmd = None
    for k, v in RXOS_CMDS.items():
        if k in t:
            cmd = v
            break
    if not cmd:
        return "Operador G_rxos: verbo no esta en la lista blanca. | G_rxos"
    return (
        f"rxOS> {cmd}\n"
        f"(host NAVI 6.5) En el unikernel G_rxos ejecutaria `{cmd}` "
        f"con el mismo commands_dispatch que el Terminal. "
        f"Aqui no simulo el kernel. | G_rxos"
    )


def g_math(result: Dict) -> str:
    if not result.get("ok"):
        return f"DESCONOCIDO. G_math solo hace enteros. {result.get('err', '')} | G_math"
    return (
        f"G_math (entero, 0% FPU)\n"
        f"{result['expr']} = {result['value']}\n"
        f"Pasos: {result.get('steps', '-')}"
    )


def g_reason(trace: Dict, body: str) -> str:
    lines = ["[G_reason] traza"]
    for i, st in enumerate(trace.get("steps", []), 1):
        flag = "ok" if st.get("ok", True) else "fail"
        lines.append(f"{i} {st['op']}  {st.get('detail', '')}  [{flag}]")
    if trace.get("unknown"):
        lines.append("VERIFY -> DESCONOCIDO")
    lines.append("---")
    lines.append(body)
    return "\n".join(lines)


def g_debug(body: str) -> str:
    return f"G_debug\n{body}"


def g_plan(topic: str, steps: List[str]) -> str:
    lines = [f"G_plan · {topic}"]
    for i, s in enumerate(steps, 1):
        lines.append(f"{i}. {s}")
    return "\n".join(lines)


def g_teach(topic: str, bits: List[str]) -> str:
    lines = [f"G_teach · {topic} (sin jargon de loro)"]
    for b in bits:
        lines.append(f"- {b}")
    return "\n".join(lines)


def g_unknown(why: str) -> str:
    return f"DESCONOCIDO. {why} Mejor eso que inventar. | G_unknown"


def g_code(text: str) -> str:
    return render_code(compose(text))
