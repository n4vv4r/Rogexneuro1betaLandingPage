"""
NAVI 6.5 — razonador.

Bucle oficial: PARSE → RETRIEVE → INFER → VERIFY → RENDER.
No predice tokens. Si el esquema falta, DESCONOCIDO.
Enteros only en math. DAG/world-model se piden al motor 6.
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from navi65_code import compose
from navi65_masks import route_mask


def _norm(text: str) -> str:
    t = text.lower()
    for a, b in (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
        t = t.replace(a, b)
    return t


@dataclass
class Step:
    op: str
    detail: str
    ok: bool = True


@dataclass
class Trace:
    mask: str
    steps: List[Step] = field(default_factory=list)
    slots: Dict[str, Any] = field(default_factory=dict)
    unknown: bool = False
    conclusion: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)

    def add(self, op: str, detail: str, ok: bool = True):
        self.steps.append(Step(op, detail, ok))

    def as_dict(self) -> Dict:
        return {
            "mask": self.mask,
            "unknown": self.unknown,
            "conclusion": self.conclusion,
            "slots": {k: v for k, v in self.slots.items() if k != "text"},
            "steps": [{"op": s.op, "detail": s.detail, "ok": s.ok} for s in self.steps],
        }


_WORD_OPS = (
    (" mas ", "+"),
    (" menos ", "-"),
    (" por ", "*"),
    (" entre ", "/"),
    (" dividido por ", "/"),
    (" dividido ", "/"),
    (" x ", "*"),
    ("×", "*"),
)


def extract_math(text: str) -> Optional[str]:
    t = " " + _norm(text) + " "
    t = t.replace("cuanto es", " ").replace("calcula", " ")
    for a, b in _WORD_OPS:
        t = t.replace(a, b)
    t = t.replace("=", " ")
    matches = re.findall(r"-?\d+(?:\s*[\+\-\*/]\s*-?\d+)+", t)
    if not matches:
        return None
    expr = re.sub(r"\s+", "", matches[0])
    return expr


def eval_int_expr(expr: str) -> Dict:
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        return {"ok": False, "err": f"sintaxis: {e}", "expr": expr}

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, int) and not isinstance(n.value, bool):
            return int(n.value)
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.USub):
            return -ev(n.operand)
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.UAdd):
            return ev(n.operand)
        if isinstance(n, ast.BinOp):
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Add):
                return a + b
            if isinstance(n.op, ast.Sub):
                return a - b
            if isinstance(n.op, ast.Mult):
                return a * b
            if isinstance(n.op, (ast.Div, ast.FloorDiv)):
                if b == 0:
                    raise ZeroDivisionError("division por cero")
                return a // b
            if isinstance(n.op, ast.Mod):
                if b == 0:
                    raise ZeroDivisionError("modulo cero")
                return a % b
        raise ValueError("solo enteros y + - * / %")

    try:
        val = ev(tree)
    except (ValueError, ZeroDivisionError, TypeError) as e:
        return {"ok": False, "err": str(e), "expr": expr}
    return {"ok": True, "expr": expr, "value": int(val), "steps": "AST entero, division = //"}


def extract_slots(text: str) -> Dict[str, Any]:
    t = _norm(text)
    slots: Dict[str, Any] = {"text": text}
    m = re.search(
        r"si\s+(\w+)\s+es mayor que\s+(\w+)\s+y\s+(\w+)\s+es mayor que\s+(\w+)",
        t,
    )
    if m:
        slots["A"], slots["B"], slots["C"] = m.group(1), m.group(2), m.group(4)
        slots["relation"] = ">"
    else:
        m2 = re.findall(r"\b([abcxyzpqt])\b", t)
        if len(m2) >= 3:
            slots["A"], slots["B"], slots["C"] = m2[0].upper(), m2[1].upper(), m2[2].upper()
    if "compartid" in t or "shared" in t:
        slots["option"] = "shared_mem"
    elif "ring" in t or "lock-free" in t or "lock free" in t:
        slots["option"] = "ring_buffer"
    elif "frecuen" in t or "menos hilo" in t:
        slots["option"] = "sample_down"
    expr = extract_math(text)
    if expr:
        slots["expr"] = expr
    return slots


def retrieve(text: str, mask: str) -> Dict[str, str]:
    t = _norm(text)
    hits = []
    if mask in ("debug", "reason") or any(k in t for k in ("gpu", "hilo", "ram", "lock")):
        hits.append("dag:cpu_queue->spin_lock->ram_spike")
        hits.append("world:gpu_threads_ram")
    if mask == "code":
        hits.append("catalog:reverse,clamp,lif,gcd,fib,crc8")
    if mask == "logic":
        hits.append("unifier:transitivity,modus,and/or/not")
    if mask == "rxos":
        hits.append("whitelist:status,mem,nics,uptime,devices,prove")
    if mask == "math":
        hits.append("arith:int + - * / %")
    if not hits:
        hits.append("bank:G_talk facts + compositional OPEN/NUC/CLOSE")
    return {"items": "; ".join(hits)}


def infer(text: str, mask: str, slots: Dict) -> Dict[str, Any]:
    out: Dict[str, Any] = {"kind": mask}
    if mask == "math":
        expr = slots.get("expr") or extract_math(text)
        out["math"] = eval_int_expr(expr) if expr else {"ok": False, "err": "sin expresion"}
        return out
    if mask == "code":
        out["code"] = compose(text)
        return out
    if mask == "logic":
        a, c = slots.get("A", "A"), slots.get("C", "C")
        out["fact"] = f"{a} > {c}" if slots.get("relation") == ">" else "schema-logic"
        return out
    if mask in ("debug", "reason") and slots.get("option"):
        out["cf"] = slots["option"]
        return out
    if mask == "plan":
        out["steps"] = _plan_steps(text)
        return out
    if mask == "teach":
        out["bits"] = _teach_bits(text)
        return out
    return out


def _plan_steps(text: str) -> List[str]:
    t = _norm(text)
    if any(k in t for k in ("gpu", "hilo", "ram")):
        return [
            "Medir: hilos CPU vs ACK GPU (no asumas VRAM).",
            "Cortar la cola sincrona (ring-buffer lock-free).",
            "Rechazar shared-mem si la latencia de bus sube.",
            "Verificar ram_spike y stall con el world-model.",
        ]
    if any(k in t for k in ("entren", "navi 5", "kcc")):
        return [
            "python3 tests/test_navi5_manual.py",
            "python3 run_peaceful_training.py",
            "Comprobar KCC: 0 instancias destruidas.",
            "Exportar pesos. No hay prune.",
        ]
    if any(k in t for k in ("iso", "rxos", "kernel")):
        return [
            "Entrenar blob (navi6_train.py) si hace falta.",
            "make iso-refresh",
            "Arrancar ISO, tecla v, /prove.",
            "Probar G_rxos (status) y G_reason (hilos/GPU).",
        ]
    return [
        "PARSE la intencion a una mascara G_*.",
        "RETRIEVE solo esquema que exista (DAG, catalogo, facts).",
        "INFER. Si falta esquema: DESCONOCIDO.",
        "RENDER con la mascara. No rellenar huecos con un loro.",
    ]


def _teach_bits(text: str) -> List[str]:
    t = _norm(text)
    if "wsp" in t:
        return [
            "Tu frase se vuelve una postal de 16 bytes.",
            "Quien, verbo, objeto, cuando, y 6 numeros de animo.",
            "El castellano es la mascara que se pinta al final.",
        ]
    if "snn" in t or "spike" in t:
        return [
            "Una neurona LIF es un cubo que se llena y se vacia.",
            "Si llega al umbral, dispara y vuelve a cero.",
            "No multiplica matrices. Suma impulsos.",
        ]
    if "navi" in t or "razon" in t:
        return [
            "NAVI 6.5 no adivina la siguiente palabra.",
            "Piensa en 5 cajas: leer, buscar, inferir, comprobar, hablar.",
            "Si una caja esta vacia, dice DESCONOCIDO.",
        ]
    return [
        "Soy un tablero de relés, no un loro.",
        "Cada mascara G_* pinta un tipo de respuesta.",
        "Si no tengo ficha, no invento el taller.",
    ]


def verify(mask: str, inferred: Dict) -> Dict[str, Any]:
    if mask == "math":
        ok = bool(inferred.get("math", {}).get("ok"))
        return {"ok": ok, "why": "math ok" if ok else inferred.get("math", {}).get("err", "fail")}
    if mask == "code":
        ok = bool(inferred.get("code", {}).get("ok"))
        return {"ok": ok, "why": "catalog hit" if ok else "sin primitiva"}
    if mask == "unknown":
        return {"ok": False, "why": "mascara unknown"}
    return {"ok": True, "why": "schema present"}


def plan(text: str) -> Trace:
    mask = route_mask(text)
    tr = Trace(mask=mask, slots=extract_slots(text))
    tr.add("PARSE", f"mask={mask} slots={ {k:v for k,v in tr.slots.items() if k!='text'} }")
    got = retrieve(text, mask)
    tr.add("RETRIEVE", got["items"])
    inferred = infer(text, mask, tr.slots)
    tr.payload = inferred
    tr.add("INFER", f"kind={inferred.get('kind')} keys={list(inferred.keys())}")
    chk = verify(mask, inferred)
    tr.add("VERIFY", chk["why"], ok=chk["ok"])
    if not chk["ok"] and mask in ("math", "code"):
        tr.unknown = True
        tr.mask = "unknown"
    tr.add("RENDER", f"G_{tr.mask}")
    return tr
