#!/usr/bin/env python3
"""
Entrena NAVI 6.5 por charla: misma tarea hasta que el oráculo la da por buena.

No es backprop ni un LLM. Cada ítem tiene máscara + palabras esperadas.
Si falla: se guarda una lección, se refuerza el DAG y se repite el turno.
El usuario de la ISO no entrena: este script corre en el lab y escribe el blob.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from navi6_pack import write_bin, write_json_sidecar
from navi65_engine import NAVI65Engine


def _norm(s: str) -> str:
    t = s.lower()
    for a, b in (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
        t = t.replace(a, b)
    return t


# Oráculos. capability = media de best_score.
CURRICULUM = [
    {
        "id": "talk-id",
        "ask": "quien eres",
        "mask": "talk",
        "need": ["6.5"],
        "keys": ["quien eres"],
        "note": "identidad RLC",
    },
    {
        "id": "math-87",
        "ask": "cuanto es 12 por 7 mas 3",
        "mask": "math",
        "need": ["87"],
        "keys": ["cuanto es", "12"],
        "note": "entero 12*7+3",
    },
    {
        "id": "math-70",
        "ask": "calcula 8*9-2",
        "mask": "math",
        "need": ["70"],
        "keys": ["calcula"],
        "note": "8*9-2",
    },
    {
        "id": "code-clamp",
        "ask": "funcion en python que haga clamp",
        "mask": "code",
        "need": ["clamp", "dry-run"],
        "keys": ["clamp"],
        "note": "catalogo clamp",
    },
    {
        "id": "code-rev",
        "ask": "escribe una funcion en c que invierta un array",
        "mask": "code",
        "need": ["rev"],
        "keys": ["invierta", "array"],
        "note": "catalogo reverse",
    },
    {
        "id": "logic-gt",
        "ask": "si a es mayor que b y b es mayor que c que relacion hay",
        "mask": "logic",
        "need": ["mayor"],
        "keys": ["mayor que"],
        "note": "transitividad",
    },
    {
        "id": "poem",
        "ask": "haiku",
        "mask": "poem",
        "need": [],
        "keys": ["haiku"],
        "note": "verso contado",
    },
    {
        "id": "rxos",
        "ask": "status",
        "mask": "rxos",
        "need": ["status"],
        "keys": ["status"],
        "note": "lista blanca",
    },
    {
        "id": "debug-gpu",
        "ask": "activo varios hilos la GPU se bloquea y la RAM se dispara",
        "mask": "debug",
        "need": ["spin"],
        "keys": ["hilos", "gpu"],
        "note": "spin-lock no VRAM",
    },
    {
        "id": "cf-shared",
        "ask": "que pasaria si en lugar del ring buffer uso memoria compartida",
        "mask": "debug",
        "need": ["latencia"],
        "keys": ["memoria compartida"],
        "note": "contrafactual shared",
    },
    {
        "id": "reason-trace",
        "ask": "razona cuanto es 2+2",
        "mask": "math",
        "need": ["4"],
        "keys": ["razona", "2+2"],
        "note": "traza + entero",
    },
    {
        "id": "plan-iso",
        "ask": "pasos para hacer la iso",
        "mask": "plan",
        "need": ["1."],
        "keys": ["pasos para"],
        "note": "plan numerado",
    },
    {
        "id": "teach-wsp",
        "ask": "ensena wsp como si tuviera 5 anos",
        "mask": "teach",
        "need": ["16"],
        "keys": ["ensena", "wsp"],
        "note": "postal 16 B",
    },
    {
        "id": "news",
        "ask": "que noticias hay hoy",
        "mask": "news",
        "need": ["rss"],
        "keys": ["noticias"],
        "note": "no inventa titulares",
    },
    {
        "id": "unknown-llvm",
        "ask": "escribe un compilador LLVM completo",
        "mask": "unknown",
        "need": ["DESCONOCIDO"],
        "keys": ["compilador", "llvm"],
        "note": "fuera de catalogo",
    },
]


def score_turn(task: dict, turn) -> float:
    reply = turn.reply or ""
    low = _norm(reply)
    bits = []
    if task.get("mask"):
        bits.append(1.0 if turn.mask == task["mask"] or task["mask"] in low else 0.0)
        # reason overlay: "razona cuanto es" may be math+trace
        if task["id"] == "reason-trace" and "[g_reason]" in low and "4" in low:
            bits[-1] = 1.0
        if task["id"] == "cf-shared" and turn.mask in ("debug", "reason"):
            bits[-1] = 1.0
    for n in task.get("need") or []:
        bits.append(1.0 if _norm(n) in low else 0.0)
    if task["id"] == "poem":
        bits.append(1.0 if reply.count("\n") >= 2 else 0.0)
    return sum(bits) / len(bits) if bits else 0.0


def drill(eng: NAVI65Engine, task: dict, max_tries: int) -> dict:
    best = 0.0
    last = None
    tries = 0
    for k in range(1, max_tries + 1):
        tries = k
        last = eng.think(task["ask"], show_trace=task["id"].startswith("reason"))
        sc = score_turn(task, last)
        best = max(best, sc)
        if sc >= 0.99:
            break
        eng.remember(task.get("keys") or [], task.get("mask") or "", task.get("note") or "")
        eng.metrics["retries"] = eng.metrics.get("retries", 0) + 1
        if "gpu" in task["ask"].lower() or "hilo" in task["ask"].lower():
            eng.navi6.dag.add("thread_flood", "cpu_alloc_queue", 0.06, "tutor-retry", "concurrency")
        drive = eng.navi6.wsp.codec.to_snn_current(
            eng.navi6.wsp.encode(task["ask"]), eng.navi6.snn.config.num_neurons
        )
        for _ in range(6):
            eng.navi6.snn.step(drive)
    return {
        "id": task["id"],
        "ask": task["ask"],
        "tries": tries,
        "score": round(best, 3),
        "mask": last.mask if last else "",
        "preview": (last.reply if last else "")[:180],
        "pass": best >= 0.99,
    }


def train(rounds: int = 1, max_tries: int = 4, skip5: bool = True) -> dict:
    t0 = time.time()
    report5 = None
    if not skip5:
        from navi6_train import train_navi5_short

        report5 = train_navi5_short(12, 3)
    eng = NAVI65Engine()
    log = []
    for _ in range(max(1, rounds)):
        for task in CURRICULUM:
            log.append(drill(eng, task, max_tries))
    passed = sum(1 for r in log[-len(CURRICULUM) :] if r["pass"])
    cap = passed / len(CURRICULUM)
    snap = eng.snapshot()
    snap["capability"] = cap
    snap["curriculum"] = log
    return {
        "engine": eng,
        "snap": snap,
        "log": log,
        "capability": cap,
        "passed": passed,
        "total": len(CURRICULUM),
        "seconds": round(time.time() - t0, 3),
        "navi5": None
        if not report5
        else {
            "kcc": report5["ethics_compliance"]["kcc_compliant"],
            "destroyed": report5["ethics_compliance"]["instances_destroyed"],
        },
    }


def tutor_repl(eng: NAVI65Engine):
    print("NAVI 6.5 tutor  ·  di la tarea y /ok o /fail <mask> para enseñar")
    print("/quit  /stats  /cap")
    last = ""
    while True:
        try:
            line = input("tu> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line in ("/quit", "/exit"):
            break
        if line == "/stats":
            print(json.dumps(eng.metrics, indent=2))
            continue
        if line.startswith("/fail"):
            parts = line.split()
            mask = parts[1] if len(parts) > 1 else "unknown"
            keys = last.lower().split()[:4]
            eng.remember(keys, mask, "tutor humano")
            print("navi> leccion guardada →", mask)
            continue
        if line == "/ok":
            print("navi> anotado")
            continue
        last = line
        turn = eng.think(line)
        print(f"navi> [{turn.mask} · {turn.ms:.1f} ms]\n{turn.reply}\n")


def main():
    ap = argparse.ArgumentParser(description="Train NAVI 6.5 by chat+retry")
    ap.add_argument("--rounds", type=int, default=2)
    ap.add_argument("--tries", type=int, default=4)
    ap.add_argument("--with5", action="store_true")
    ap.add_argument("--tutor", action="store_true")
    ap.add_argument("--target", type=float, default=0.90)
    ap.add_argument("--out", default="NAVI_AI_SNN/l3/navi6_weights.bin")
    args = ap.parse_args()

    if args.tutor:
        tutor_repl(NAVI65Engine())
        return

    extra = 0
    result = train(args.rounds, args.tries, skip5=not args.with5)
    while result["capability"] < args.target and extra < 3:
        extra += 1
        more = train(1, args.tries + extra, skip5=True)
        result["log"].extend(more["log"])
        result["capability"] = more["capability"]
        result["passed"] = more["passed"]
        result["engine"] = more["engine"]
        result["snap"] = more["snap"]
        result["seconds"] += more["seconds"]

    eng = result["engine"]
    snap = result["snap"]
    out = Path(args.out)
    write_bin(out, snap["edges"], snap["snn"]["v_th"], snap["snn"]["tau"])
    write_json_sidecar(out, snap)
    report = {
        "model": "NAVI 6.5",
        "role": "reasoning-language-code",
        "capability": result["capability"],
        "passed": result["passed"],
        "total": result["total"],
        "target": args.target,
        "seconds": result["seconds"],
        "lessons": snap.get("lessons", []),
        "rlc": snap.get("rlc", {}),
        "navi5": result["navi5"],
        "blob": str(out),
        "blob_bytes": out.stat().st_size,
        "log": result["log"],
        "note": "Curriculum + retry. No es un LLM. El usuario de la ISO no entrena.",
    }
    Path("NAVI_AI_SNN/l3/navi65_train_report.json").write_text(
        json.dumps(report, indent=2, default=str, ensure_ascii=False)
    )
    print(f"[TRAIN65] capability {result['capability']:.2%}  "
          f"{result['passed']}/{result['total']}  "
          f"lessons={len(snap.get('lessons', []))}  "
          f"{out} {out.stat().st_size} B  {result['seconds']}s")
    if result["capability"] < args.target:
        print("[TRAIN65] WARN: por debajo del objetivo", args.target)
        raise SystemExit(2)


if __name__ == "__main__":
    main()
