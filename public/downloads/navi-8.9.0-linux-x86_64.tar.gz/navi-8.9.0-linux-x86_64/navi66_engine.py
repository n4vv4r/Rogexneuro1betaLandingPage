"""
NAVI 6.6 — RLC 6.5 + lengua 6.6 + chat TUI.

No es un LLM. El bucle PARSE-RETRIEVE-INFER-VERIFY-RENDER sigue igual.
6.6 añade: corrector (detecta y supone), artículos, concordancia, tiempos,
conectores, y un compositor que arma oraciones humanas con esquema.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from navi65_engine import NAVI65Engine, RLCTurn
from navi65_masks import (
    g_code,
    g_debug,
    g_logic,
    g_math,
    g_news,
    g_plan,
    g_poem,
    g_reason,
    g_rxos,
    g_teach,
    g_unknown,
)
from navi65_reason import plan as plan_trace
from navi66_lang import (
    Corrected,
    compose_human,
    correct_text,
    lang_intent,
    render_lang,
)
from navi66_web import looks_web, run_web


@dataclass
class Turn66(RLCTurn):
    corrected: str = ""
    fixes: List[Dict] = field(default_factory=list)
    version: str = "6.6"


class NAVI66Engine(NAVI65Engine):
    VERSION = "6.6"
    ROLE = "reasoning-language-code-grammar"

    def think(self, user: str, show_trace: bool = False) -> Turn66:
        corr = correct_text(user)
        cleaned = corr.text or user
        if looks_web(cleaned):
            try:
                body = run_web(cleaned)
            except Exception as exc:  # noqa: BLE001 — host path, stay honest
                body = f"G_news: curl fallo ({exc})."
            turn = Turn66(
                user=user,
                reply=body,
                mask="news",
                ms=0.0,
                internal={
                    "version": self.VERSION,
                    "role": self.ROLE,
                    "corrected": cleaned,
                    "fixes": [{"raw": f.raw, "guess": f.guess, "dist": f.dist} for f in corr.fixes],
                    "web": True,
                },
                corrected=cleaned,
                fixes=[{"raw": f.raw, "guess": f.guess, "dist": f.dist} for f in corr.fixes],
            )
            self.history.append(turn)
            return turn
        base = super().think(cleaned, show_trace=show_trace)
        # G_talk / G_lang: compositor humano
        body = base.reply
        intent = lang_intent(cleaned)
        if intent != "talk":
            body = render_lang(cleaned, corr)
            base.mask = "lang"
        elif base.mask == "talk":
            body = self._talk66(cleaned, corr)
        elif corr.dirty:
            body = render_lang(cleaned, corr).split("\n")[0] + "\n" + body
        turn = Turn66(
            user=user,
            reply=body,
            mask=base.mask if intent == "talk" else "lang",
            ms=base.ms,
            internal={
                **base.internal,
                "version": self.VERSION,
                "role": self.ROLE,
                "corrected": cleaned,
                "fixes": [{"raw": f.raw, "guess": f.guess, "dist": f.dist} for f in corr.fixes],
                "lexicon": True,
            },
            corrected=cleaned,
            fixes=[{"raw": f.raw, "guess": f.guess, "dist": f.dist} for f in corr.fixes],
        )
        if self.history:
            self.history[-1] = turn
        else:
            self.history.append(turn)
        return turn

    def _talk66(self, cleaned: str, corr: Corrected) -> str:
        t = cleaned.lower()
        prefix = ""
        if corr.dirty:
            prefix = compose_human("fix", fixes=corr.fixes) + " "
        if any(k in t for k in ("quien eres", "que eres", "hablame de ti", "como te llamas", "tu nombre")):
            return prefix + compose_human("id")
        if any(k in t for k in ("hola", "buenos dias", "buenas tardes", "hey")):
            return prefix + compose_human("greet") + " " + compose_human("id")
        if any(k in t for k in ("que puedes", "que sabes", "que haces")):
            return prefix + compose_human("can") + " | G_talk"
        if any(k in t for k in ("adios", "hasta luego", "buenas noches")):
            return prefix + compose_human("bye") + " | G_talk"
        if "gracias" in t:
            return prefix + "De nada. El canal sigue abierto. | G_talk"
        # 6.5 fact banks still apply via parent render; rebuild a human wrapper
        from navi65_masks import g_talk

        core = g_talk(cleaned).replace("6.5", "6.6")
        if prefix:
            return prefix + core
        # wrap the old OPEN+NUC+CLOSE into a proper sentence if it is the collage
        return (
            f"{prefix}{core} "
            "Hablo con articulos y tiempos; si escribes mal, lo marco y sigo con la correccion."
        )


def reply(text: str, engine: Optional[NAVI66Engine] = None) -> Turn66:
    return (engine or NAVI66Engine()).think(text)
