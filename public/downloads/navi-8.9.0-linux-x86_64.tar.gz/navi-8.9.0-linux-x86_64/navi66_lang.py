"""
NAVI 6.6 — lengua: conexiones, artículos, gramática, tiempos, ortografía.

No es un LLM. Léxico cerrado + reglas + distancia de edición.
Si una palabra no está en el léxico y hay un vecino único a distancia 1–2,
se detecta el error y se supone la corrección. Si no hay vecino: se deja.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


def fold(s: str) -> str:
    t = (s or "").lower()
    for a, b in (
        ("á", "a"),
        ("é", "e"),
        ("í", "i"),
        ("ó", "o"),
        ("ú", "u"),
        ("ü", "u"),
        ("ñ", "n"),
    ):
        t = t.replace(a, b)
    return t


# --- léxico: forma plegada -> metadatos ---
# pos: N noun, A adj, V verb, D det, C connector, P pron, R adverb, X other

@dataclass(frozen=True)
class Entry:
    form: str
    lemma: str
    pos: str
    gender: str = ""  # m f
    number: str = ""  # sg pl
    person: int = 0  # 1..6
    tense: str = ""  # pres pret fut cond subj


LEX: Dict[str, Entry] = {}
LEMMA_NOUN: Dict[str, Entry] = {}
LEMMA_ADJ: Dict[str, Tuple[str, str, str, str]] = {}  # lemma -> (m_sg, f_sg, m_pl, f_pl)
VERBS: Dict[str, Dict[str, Dict[int, str]]] = {}  # lemma -> tense -> person -> form


def _add(e: Entry) -> None:
    key = fold(e.form)
    # first reading wins so "hablo" stays presente-yo, not pretérito-él
    if key not in LEX:
        LEX[key] = e
    if e.pos == "N" and e.number == "sg":
        LEMMA_NOUN[fold(e.lemma)] = e


def noun(sg: str, gender: str, pl: str = "") -> None:
    _add(Entry(sg, sg, "N", gender, "sg"))
    if pl:
        _add(Entry(pl, sg, "N", gender, "pl"))


def adj(lemma: str, m_sg: str, f_sg: str, m_pl: str, f_pl: str) -> None:
    LEMMA_ADJ[fold(lemma)] = (m_sg, f_sg, m_pl, f_pl)
    _add(Entry(m_sg, lemma, "A", "m", "sg"))
    _add(Entry(f_sg, lemma, "A", "f", "sg"))
    _add(Entry(m_pl, lemma, "A", "m", "pl"))
    _add(Entry(f_pl, lemma, "A", "f", "pl"))


def verb(lemma: str, table: Dict[str, Tuple[str, str, str, str, str, str]]) -> None:
    slot: Dict[str, Dict[int, str]] = {}
    for tense, forms in table.items():
        slot[tense] = {}
        for i, form in enumerate(forms, 1):
            slot[tense][i] = form
            _add(Entry(form, lemma, "V", "", "", i, tense))
    _add(Entry(lemma, lemma, "V", "", "", 0, "inf"))
    VERBS[fold(lemma)] = slot


def _seed() -> None:
    for w, g, p in (
        ("esquema", "m", "esquemas"),
        ("mascara", "f", "mascaras"),
        ("impulso", "m", "impulsos"),
        ("paquete", "m", "paquetes"),
        ("kernel", "m", "kernels"),
        ("lengua", "f", "lenguas"),
        ("articulo", "m", "articulos"),
        ("verbo", "m", "verbos"),
        ("tiempo", "m", "tiempos"),
        ("gramatica", "f", "gramaticas"),
        ("palabra", "f", "palabras"),
        ("chat", "m", "chats"),
        ("terminal", "m", "terminales"),
        ("conexion", "f", "conexiones"),
        ("usuario", "m", "usuarios"),
        ("frase", "f", "frases"),
        ("cubo", "m", "cubos"),
        ("neurona", "f", "neuronas"),
        ("traza", "f", "trazas"),
        ("codigo", "m", "codigos"),
        ("error", "m", "errores"),
        ("correccion", "f", "correcciones"),
        ("oracion", "f", "oraciones"),
        ("sujeto", "m", "sujetos"),
        ("objeto", "m", "objetos"),
        ("modelo", "m", "modelos"),
        ("portatil", "m", "portatiles"),
        ("julios", "m", "julios"),
        ("mascara", "f", "mascaras"),
        ("respuesta", "f", "respuestas"),
        ("pregunta", "f", "preguntas"),
        ("sistema", "m", "sistemas"),
        ("agente", "m", "agentes"),
        ("archivo", "m", "archivos"),
        ("proyecto", "m", "proyectos"),
        ("rama", "f", "ramas"),
        ("color", "m", "colores"),
        ("caja", "f", "cajas"),
        ("spinner", "m", "spinners"),
        ("humano", "m", "humanos"),
    ):
        noun(w, g, p)
    for form, g in (("hola", "m"), ("adios", "m"), ("navi", "m"), ("rxos", "m")):
        _add(Entry(form, form, "X", g, "sg"))
    adj("local", "local", "local", "locales", "locales")
    adj("oficial", "oficial", "oficial", "oficiales", "oficiales")
    adj("entero", "entero", "entera", "enteros", "enteras")
    adj("humano", "humano", "humana", "humanos", "humanas")
    adj("correcto", "correcto", "correcta", "correctos", "correctas")
    adj("abierto", "abierto", "abierta", "abiertos", "abiertas")
    adj("cerrado", "cerrado", "cerrada", "cerrados", "cerradas")
    adj("neuromorfico", "neuromorfico", "neuromorfica", "neuromorficos", "neuromorficas")
    adj("malescrito", "malescrito", "malescrita", "malescritos", "malescritas")
    adj("corto", "corto", "corta", "cortos", "cortas")
    adj("largo", "largo", "larga", "largos", "largas")
    adj("claro", "claro", "clara", "claros", "claras")
    for d in (
        "el",
        "la",
        "los",
        "las",
        "un",
        "una",
        "unos",
        "unas",
        "del",
        "al",
        "lo",
    ):
        _add(Entry(d, d, "D"))
    for c in (
        "porque",
        "entonces",
        "aunque",
        "ademas",
        "sin embargo",
        "por tanto",
        "si",
        "cuando",
        "mientras",
        "pero",
        "y",
        "o",
        "luego",
        "asi",
    ):
        _add(Entry(c, c, "C"))
    for p in ("yo", "tu", "el", "ella", "nosotros", "vosotros", "ellos", "ellas", "usted", "ustedes"):
        _add(Entry(p, p, "P"))
    for r in ("no", "si", "aqui", "ahora", "bien", "mal", "muy", "ya", "tambien", "solo"):
        _add(Entry(r, r, "R"))
    for x in (
        "quien",
        "que",
        "como",
        "donde",
        "cuanto",
        "cual",
        "necesito",
        "gracias",
        "por favor",
        "hola",
        "adios",
        "desconocido",
        "esquema",
        "llm",
        "snn",
        "wsp",
        "junta",
        "juntar",
        "learn",
        "hermetismo",
        "gnosis",
        "sudar",
        "conciencia",
        "trata",
        "tratar",
        "ataraxia",
        "busca",
        "buscar",
        "sobre",
        "uap",
        "disclosure",
        "that",
        "feel",
        "about",
        "how",
        "you",
        "anos",
        "naci",
        "letras",
        "letra",
        "strawberry",
        "navarro",
        "capitalismo",
        "cuerdas",
        "teseracto",
        "rima",
        "rimar",
        "poema",
        "verso",
    ):
        if fold(x) not in LEX:
            _add(Entry(x, x, "X"))

    # 1 yo, 2 tu, 3 el, 4 nosotros, 5 vosotros, 6 ellos
    verb(
        "ser",
        {
            "pres": ("soy", "eres", "es", "somos", "sois", "son"),
            "pret": ("fui", "fuiste", "fue", "fuimos", "fuisteis", "fueron"),
            "fut": ("sere", "seras", "sera", "seremos", "sereis", "seran"),
            "cond": ("seria", "serias", "seria", "seriamos", "seriais", "serian"),
            "subj": ("sea", "seas", "sea", "seamos", "seais", "sean"),
        },
    )
    verb(
        "estar",
        {
            "pres": ("estoy", "estas", "esta", "estamos", "estais", "estan"),
            "pret": ("estuve", "estuviste", "estuvo", "estuvimos", "estuvisteis", "estuvieron"),
            "fut": ("estare", "estaras", "estara", "estaremos", "estareis", "estaran"),
            "cond": ("estaria", "estarias", "estaria", "estariamos", "estariais", "estarian"),
            "subj": ("este", "estes", "este", "estemos", "esteis", "esten"),
        },
    )
    verb(
        "haber",
        {
            "pres": ("he", "has", "ha", "hemos", "habeis", "han"),
            "pret": ("hube", "hubiste", "hubo", "hubimos", "hubisteis", "hubieron"),
            "fut": ("habre", "habras", "habra", "habremos", "habreis", "habran"),
            "cond": ("habria", "habrias", "habria", "habriamos", "habriais", "habrian"),
            "subj": ("haya", "hayas", "haya", "hayamos", "hayais", "hayan"),
        },
    )
    verb(
        "tener",
        {
            "pres": ("tengo", "tienes", "tiene", "tenemos", "teneis", "tienen"),
            "pret": ("tuve", "tuviste", "tuvo", "tuvimos", "tuvisteis", "tuvieron"),
            "fut": ("tendre", "tendras", "tendra", "tendremos", "tendreis", "tendran"),
            "cond": ("tendria", "tendrias", "tendria", "tendriamos", "tendriais", "tendrian"),
            "subj": ("tenga", "tengas", "tenga", "tengamos", "tengais", "tengan"),
        },
    )
    verb(
        "hacer",
        {
            "pres": ("hago", "haces", "hace", "hacemos", "haceis", "hacen"),
            "pret": ("hice", "hiciste", "hizo", "hicimos", "hicisteis", "hicieron"),
            "fut": ("hare", "haras", "hara", "haremos", "hareis", "haran"),
            "cond": ("haria", "harias", "haria", "hariamos", "hariais", "harian"),
            "subj": ("haga", "hagas", "haga", "hagamos", "hagais", "hagan"),
        },
    )
    verb(
        "decir",
        {
            "pres": ("digo", "dices", "dice", "decimos", "decis", "dicen"),
            "pret": ("dije", "dijiste", "dijo", "dijimos", "dijisteis", "dijeron"),
            "fut": ("dire", "diras", "dira", "diremos", "direis", "diran"),
            "cond": ("diria", "dirias", "diria", "diriamos", "diriais", "dirian"),
            "subj": ("diga", "digas", "diga", "digamos", "digais", "digan"),
        },
    )
    verb(
        "ir",
        {
            "pres": ("voy", "vas", "va", "vamos", "vais", "van"),
            "pret": ("fui", "fuiste", "fue", "fuimos", "fuisteis", "fueron"),
            "fut": ("ire", "iras", "ira", "iremos", "ireis", "iran"),
            "cond": ("iria", "irias", "iria", "iriamos", "iriais", "irian"),
            "subj": ("vaya", "vayas", "vaya", "vayamos", "vayais", "vayan"),
        },
    )
    verb(
        "poder",
        {
            "pres": ("puedo", "puedes", "puede", "podemos", "podeis", "pueden"),
            "pret": ("pude", "pudiste", "pudo", "pudimos", "pudisteis", "pudieron"),
            "fut": ("podre", "podras", "podra", "podremos", "podreis", "podran"),
            "cond": ("podria", "podrias", "podria", "podriamos", "podriais", "podrian"),
            "subj": ("pueda", "puedas", "pueda", "podamos", "podais", "puedan"),
        },
    )
    verb(
        "querer",
        {
            "pres": ("quiero", "quieres", "quiere", "queremos", "quereis", "quieren"),
            "pret": ("quise", "quisiste", "quiso", "quisimos", "quisisteis", "quisieron"),
            "fut": ("querre", "querras", "querra", "querremos", "querreis", "querran"),
            "cond": ("querria", "querrias", "querria", "querriamos", "querriais", "querrian"),
            "subj": ("quiera", "quieras", "quiera", "queramos", "querais", "quieran"),
        },
    )
    verb(
        "saber",
        {
            "pres": ("se", "sabes", "sabe", "sabemos", "sabeis", "saben"),
            "pret": ("supe", "supiste", "supo", "supimos", "supisteis", "supieron"),
            "fut": ("sabre", "sabras", "sabra", "sabremos", "sabreis", "sabran"),
            "cond": ("sabria", "sabrias", "sabria", "sabriamos", "sabriais", "sabrian"),
            "subj": ("sepa", "sepas", "sepa", "sepamos", "sepais", "sepan"),
        },
    )
    verb(
        "hablar",
        {
            "pres": ("hablo", "hablas", "habla", "hablamos", "hablais", "hablan"),
            "pret": ("hable", "hablaste", "hablo", "hablamos", "hablasteis", "hablaron"),
            "fut": ("hablare", "hablaras", "hablara", "hablaremos", "hablareis", "hablaran"),
            "cond": ("hablaria", "hablarias", "hablaria", "hablariamos", "hablariais", "hablarian"),
            "subj": ("hable", "hables", "hable", "hablemos", "hableis", "hablen"),
        },
    )
    verb(
        "escribir",
        {
            "pres": ("escribo", "escribes", "escribe", "escribimos", "escribis", "escriben"),
            "pret": ("escribi", "escribiste", "escribio", "escribimos", "escribisteis", "escribieron"),
            "fut": ("escribire", "escribiras", "escribira", "escribiremos", "escribireis", "escribiran"),
            "cond": ("escribiria", "escribirias", "escribiria", "escribiriamos", "escribiriais", "escribirian"),
            "subj": ("escriba", "escribas", "escriba", "escribamos", "escribais", "escriban"),
        },
    )
    verb(
        "leer",
        {
            "pres": ("leo", "lees", "lee", "leemos", "leeis", "leen"),
            "pret": ("lei", "leiste", "leyo", "leimos", "leisteis", "leyeron"),
            "fut": ("leere", "leeras", "leera", "leeremos", "leereis", "leeran"),
            "cond": ("leeria", "leerias", "leeria", "leeriamos", "leeriais", "leerian"),
            "subj": ("lea", "leas", "lea", "leamos", "leais", "lean"),
        },
    )
    verb(
        "razonar",
        {
            "pres": ("razono", "razonas", "razona", "razonamos", "razonais", "razonan"),
            "pret": ("razone", "razonaste", "razono", "razonamos", "razonasteis", "razonaron"),
            "fut": ("razonare", "razonaras", "razonara", "razonaremos", "razonareis", "razonaran"),
            "cond": ("razonaria", "razonarias", "razonaria", "razonariamos", "razonariais", "razonarian"),
            "subj": ("razone", "razones", "razone", "razonemos", "razoneis", "razonen"),
        },
    )
    verb(
        "medir",
        {
            "pres": ("mido", "mides", "mide", "medimos", "medis", "miden"),
            "pret": ("medi", "mediste", "midio", "medimos", "medisteis", "midieron"),
            "fut": ("medire", "mediras", "medira", "mediremos", "medireis", "mediran"),
            "cond": ("mediria", "medirias", "mediria", "mediriamos", "mediriais", "medirian"),
            "subj": ("mida", "midas", "mida", "midamos", "midais", "midan"),
        },
    )
    verb(
        "arrancar",
        {
            "pres": ("arranco", "arrancas", "arranca", "arrancamos", "arrancais", "arrancan"),
            "pret": ("arranque", "arrancaste", "arranco", "arrancamos", "arrancasteis", "arrancaron"),
            "fut": ("arrancare", "arrancaras", "arrancara", "arrancaremos", "arrancareis", "arrancaran"),
            "cond": ("arrancaria", "arrancarias", "arrancaria", "arrancariamos", "arrancariais", "arrancarian"),
            "subj": ("arranque", "arranques", "arranque", "arranquemos", "arranqueis", "arranquen"),
        },
    )
    verb(
        "corregir",
        {
            "pres": ("corrijo", "corriges", "corrige", "corregimos", "corregis", "corrigen"),
            "pret": ("corregi", "corregiste", "corrigio", "corregimos", "corregisteis", "corrigieron"),
            "fut": ("corregire", "corregiras", "corregira", "corregiremos", "corregireis", "corregiran"),
            "cond": ("corregiria", "corregirias", "corregiria", "corregiriamos", "corregiriais", "corregirian"),
            "subj": ("corrija", "corrijas", "corrija", "corrijamos", "corrijais", "corrijan"),
        },
    )
    verb(
        "poner",
        {
            "pres": ("pongo", "pones", "pone", "ponemos", "poneis", "ponen"),
            "pret": ("puse", "pusiste", "puso", "pusimos", "pusisteis", "pusieron"),
            "fut": ("pondre", "pondras", "pondra", "pondremos", "pondreis", "pondran"),
            "cond": ("pondria", "pondrias", "pondria", "pondriamos", "pondriais", "pondrian"),
            "subj": ("ponga", "pongas", "ponga", "pongamos", "pongais", "pongan"),
        },
    )
    _add(Entry("pon", "poner", "V", "", "", 2, "pres"))
    verb(
        "escuchar",
        {
            "pres": ("escucho", "escuchas", "escucha", "escuchamos", "escuchais", "escuchan"),
            "pret": ("escuche", "escuchaste", "escucho", "escuchamos", "escuchasteis", "escucharon"),
            "fut": ("escuchare", "escucharas", "escuchara", "escucharemos", "escuchareis", "escucharan"),
            "cond": ("escucharia", "escucharias", "escucharia", "escuchariamos", "escuchariais", "escucharian"),
            "subj": ("escuche", "escuches", "escuche", "escuchemos", "escucheis", "escuchen"),
        },
    )
    verb(
        "detectar",
        {
            "pres": ("detecto", "detectas", "detecta", "detectamos", "detectais", "detectan"),
            "pret": ("detecte", "detectaste", "detecto", "detectamos", "detectasteis", "detectaron"),
            "fut": ("detectare", "detectaras", "detectara", "detectaremos", "detectareis", "detectaran"),
            "cond": ("detectaria", "detectarias", "detectaria", "detectariamos", "detectariais", "detectarian"),
            "subj": ("detecte", "detectes", "detecte", "detectemos", "detecteis", "detecten"),
        },
    )
    verb(
        "necesitar",
        {
            "pres": ("necesito", "necesitas", "necesita", "necesitamos", "necesitais", "necesitan"),
            "pret": ("necesite", "necesitaste", "necesito", "necesitamos", "necesitasteis", "necesitaron"),
            "fut": ("necesitare", "necesitaras", "necesitara", "necesitaremos", "necesitareis", "necesitaran"),
            "cond": ("necesitaria", "necesitarias", "necesitaria", "necesitariamos", "necesitariais", "necesitarian"),
            "subj": ("necesite", "necesites", "necesite", "necesitemos", "necesiteis", "necesiten"),
        },
    )


_seed()

# jerga / typos frecuentes (se aplican antes de la distancia)
TYPOS: Dict[str, str] = {
    "kien": "quien",
    "ke": "que",
    "q": "que",
    "xq": "porque",
    "tmb": "tambien",
    "tbn": "tambien",
    "qiero": "quiero",
    "kiero": "quiero",
    "nesesito": "necesito",
    "nesecito": "necesito",
    "esesito": "necesito",
    "escrivir": "escribir",
    "escriveme": "escribeme",
    "escrive": "escribe",
    "holaa": "hola",
    "ola": "hola",
    "oi": "hoy",
    "komo": "como",
    "stas": "estas",
    "tngo": "tengo",
    "mui": "muy",
    "xfa": "por favor",
    "xfavor": "por favor",
    "porfa": "por favor",
    "grasias": "gracias",
    "grax": "gracias",
    "aki": "aqui",
    "ahi": "ahi",
    "dnd": "donde",
    "kiero": "quiero",
    "puedeser": "puede",
    "naavi": "navi",
    "navii": "navi",
    "rxoss": "rxos",
    "gramatika": "gramatica",
    "ortografia": "ortografia",
    "ortografiaa": "ortografia",
    "berbo": "verbo",
    "tiempso": "tiempos",
    "artikulo": "articulo",
    "konexion": "conexion",
    "konexión": "conexion",
    "mascra": "mascara",
    "esquemaa": "esquema",
}


def damerau(a: str, b: str, limit: int = 2) -> int:
    if a == b:
        return 0
    la, lb = len(a), len(b)
    if abs(la - lb) > limit:
        return limit + 1
    prev = list(range(lb + 1))
    prev2 = [0] * (lb + 1)
    for i, ca in enumerate(a, 1):
        cur = [i] + [0] * lb
        row_min = i
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            if i > 1 and j > 1 and ca == b[j - 2] and a[i - 2] == cb:
                cur[j] = min(cur[j], prev2[j - 2] + 1)
            if cur[j] < row_min:
                row_min = cur[j]
        if row_min > limit:
            return limit + 1
        prev2, prev = prev, cur
    return prev[lb]


def _best_lex(token: str) -> Optional[str]:
    t = fold(token)
    if t in LEX:
        return LEX[t].form
    if t in TYPOS:
        return TYPOS[t]
    # 3 letras: solo TYPOS. Si no, "pon" vira a "son".
    # Distancia 2 y recortes (junta→una, learn→lean) inventan demasiado.
    if len(t) <= 3:
        return None
    hits: List[Tuple[int, str]] = []
    for key, ent in LEX.items():
        if len(key) != len(t):
            continue
        d = damerau(t, key, 1)
        if d == 1:
            hits.append((d, ent.form))
    if not hits:
        return None
    hits.sort()
    # único vecino al menor coste
    best = hits[0][0]
    same = [h for h in hits if h[0] == best]
    if len(same) == 1:
        return same[0][1]
    return None


@dataclass
class Fix:
    raw: str
    guess: str
    dist: int


@dataclass
class Corrected:
    raw: str
    text: str
    fixes: List[Fix] = field(default_factory=list)

    @property
    def dirty(self) -> bool:
        return bool(self.fixes)


def tokenize(text: str) -> List[str]:
    out: List[str] = []
    buf = ""
    for ch in text:
        if ch.isalnum() or ch in "áéíóúüñÁÉÍÓÚÜÑ":
            buf += ch
        else:
            if buf:
                out.append(buf)
                buf = ""
            if not ch.isspace():
                out.append(ch)
            else:
                out.append(" ")
    if buf:
        out.append(buf)
    # collapse spaces
    compact: List[str] = []
    for t in out:
        if t == " " and compact and compact[-1] == " ":
            continue
        compact.append(t)
    return compact


def correct_text(text: str) -> Corrected:
    parts = tokenize(text)
    out: List[str] = []
    fixes: List[Fix] = []
    for p in parts:
        if p == " " or len(p) == 1 and not p.isalnum():
            out.append(p)
            continue
        if p.isdigit():
            out.append(p)
            continue
        key = fold(p)
        if key in LEX:
            out.append(p)
            continue
        if key in TYPOS:
            guess = TYPOS[key]
            fixes.append(Fix(p, guess, 1))
            out.append(guess)
            continue
        guess = _best_lex(p)
        if guess and fold(guess) != key:
            d = damerau(key, fold(guess), 2)
            fixes.append(Fix(p, guess, d))
            out.append(guess)
        else:
            out.append(p)
    # rebuild, tidy spaces around punctuation
    s = "".join(out)
    s = " ".join(s.split())
    for a, b in (( " ,", ","), (" .", "."), (" ?", "?"), (" !", "!"), (" :", ":")):
        s = s.replace(a, b)
    return Corrected(raw=text, text=s, fixes=fixes)


def article(gender: str, number: str, definite: bool = True) -> str:
    if definite:
        if number == "pl":
            return "los" if gender == "m" else "las"
        return "el" if gender == "m" else "la"
    if number == "pl":
        return "unos" if gender == "m" else "unas"
    return "un" if gender == "m" else "una"


def agree_adj(lemma: str, gender: str, number: str) -> str:
    row = LEMMA_ADJ.get(fold(lemma))
    if not row:
        return lemma
    m_sg, f_sg, m_pl, f_pl = row
    if number == "pl":
        return m_pl if gender == "m" else f_pl
    return m_sg if gender == "m" else f_sg


def np(lemma: str, definite: bool = True, adjective: Optional[str] = None) -> str:
    e = LEMMA_NOUN.get(fold(lemma))
    if not e:
        return lemma
    art = article(e.gender, e.number, definite)
    words = [art, e.form]
    if adjective:
        words.append(agree_adj(adjective, e.gender, e.number))
    return " ".join(words)


PERSON = {
    "yo": 1,
    "tu": 2,
    "usted": 3,
    "el": 3,
    "ella": 3,
    "nosotros": 4,
    "vosotros": 5,
    "ellos": 6,
    "ellas": 6,
    "ustedes": 6,
}

TENSES = ("pres", "pret", "fut", "cond", "subj")
TENSE_ALIAS = {
    "pres": "pres",
    "presente": "pres",
    "pret": "pret",
    "preterito": "pret",
    "pasado": "pret",
    "fut": "fut",
    "futuro": "fut",
    "cond": "cond",
    "condicional": "cond",
    "subj": "subj",
    "subjuntivo": "subj",
}
TENSE_NAME = {
    "pres": "presente",
    "pret": "preterito",
    "fut": "futuro",
    "cond": "condicional",
    "subj": "subjuntivo",
}


def conjugate(lemma: str, tense: str, person: int) -> Optional[str]:
    table = VERBS.get(fold(lemma))
    if not table:
        return None
    t = TENSE_ALIAS.get(fold(tense), fold(tense))
    return table.get(t, {}).get(person)


def tense_table(lemma: str, tense: Optional[str] = None) -> str:
    table = VERBS.get(fold(lemma))
    if not table:
        return f"DESCONOCIDO. El verbo «{lemma}» no esta en el lexico cerrado."
    labels = ("yo", "tu", "el/ella", "nosotros", "vosotros", "ellos")
    tenses = [TENSE_ALIAS.get(fold(tense), fold(tense))] if tense else list(TENSES)
    lines = [f"G_lang · {lemma}"]
    for t in tenses:
        if t not in table:
            continue
        lines.append(f"[{TENSE_NAME.get(t, t)}]")
        for i, lab in enumerate(labels, 1):
            lines.append(f"  {lab:10} {table[t][i]}")
    return "\n".join(lines)


def rewrite_tense(text: str, tense: str) -> str:
    tcode = TENSE_ALIAS.get(fold(tense), fold(tense))
    parts = tokenize(text)
    out: List[str] = []
    for p in parts:
        e = LEX.get(fold(p))
        if e and e.pos == "V" and e.person:
            form = conjugate(e.lemma, tcode, e.person)
            out.append(form or p)
        else:
            out.append(p)
    s = "".join(out)
    return " ".join(s.split())


CONNECTORS = (
    "porque",
    "entonces",
    "aunque",
    "ademas",
    "sin embargo",
    "por tanto",
    "cuando",
)


def clause(
    subj: str,
    verb_lemma: str,
    obj: str = "",
    tense: str = "pres",
    person: int = 3,
    connector: str = "",
) -> str:
    v = conjugate(verb_lemma, tense, person) or verb_lemma
    bits = []
    if connector:
        bits.append(connector + ",")
    bits.append(subj)
    bits.append(v)
    if obj:
        bits.append(obj)
    s = " ".join(bits)
    return s[0].upper() + s[1:] + "."


def compose_human(kind: str, **kw) -> str:
    """Oraciones con artículo, verbo conjugado y conector. Plantilla, no loro."""
    if kind == "id":
        return (
            "Me llamo NAVI. "
            + clause("yo", "ser", "NAVI 6.6", "pres", 1)
            + " "
            + clause("yo", "razonar", "con esquema", "pres", 1, "ademas")
            + " "
            + clause(np("sistema"), "escribir", np("frase", True, "humano"), "pres", 3)
            + " Si una palabra esta mal escrita, la detecto y supongo la correccion."
        )
    if kind == "greet":
        return "Hola. Soy NAVI. " + clause("el canal", "estar", "abierto", "pres", 3)
    if kind == "can":
        return (
            clause("yo", "hablar", "con articulos, verbos y conectores", "pres", 1)
            + " "
            + clause("yo", "corregir", np("palabra", True, "malescrito"), "pres", 1, "ademas")
            + " "
            + clause("yo", "saber", "tiempos de un lexico cerrado", "pres", 1)
            + " No predice el siguiente token."
        )
    if kind == "fix":
        pairs = kw.get("fixes") or []
        bits = ["Detecte escritura incorrecta y supuse la correccion:"]
        for f in pairs:
            bits.append(f"«{f.raw}» → «{f.guess}»")
        return " ".join(bits) + "."
    if kind == "bye":
        return clause("yo", "ir", "al reposo", "pres", 1) + " Adios."
    return clause("yo", "escuchar", kw.get("obj") or "el hilo", "pres", 1)


def detect_tense_word(text: str) -> Optional[str]:
    t = fold(text)
    for k, v in (
        ("presente", "pres"),
        ("preterito", "pret"),
        ("pasado", "pret"),
        ("futuro", "fut"),
        ("condicional", "cond"),
        ("subjuntivo", "subj"),
    ):
        if k in t:
            return v
    return None


def lang_intent(text: str) -> str:
    t = fold(text)
    if any(k in t for k in ("conjuga", "conjugacion", "tiempos del verbo", "tiempo verbal")):
        return "conjuga"
    if t.startswith("corrige") or t.startswith("corrige:") or "ortografia" in t:
        return "corrige"
    if any(k in t for k in ("pon en ", "pasa a ", "en pasado", "en futuro", "en subjuntivo", "en condicional", "en presente")):
        return "rewrite"
    if any(k in t for k in ("articulo", "gramatica", "genero", "numero", "concordancia")):
        return "grammar"
    return "talk"


def extract_verb_lemma(text: str) -> Optional[str]:
    parts = tokenize(text)
    for p in parts:
        e = LEX.get(fold(p))
        if e and e.pos == "V":
            return e.lemma
    # last token after conjuga
    t = fold(text)
    for key in VERBS:
        if key in t:
            return key
    return None


def grammar_note() -> str:
    return (
        "G_lang · reglas\n"
        f"- Articulo + nombre: {np('mascara', True)} / {np('esquema', True)} / "
        f"{np('neurona', True, 'local')}.\n"
        f"- Adjetivo concuerda: {np('frase', True, 'humano')} / {np('paquete', True, 'entero')}.\n"
        "- Tiempos: presente, preterito, futuro, condicional, subjuntivo. "
        "Pide «conjuga escribir» o «pon en pasado: yo hablo».\n"
        "- Conectores: porque, entonces, aunque, ademas, sin embargo, por tanto.\n"
        "- Ortografia: si «kien» entra, supongo «quien» y lo digo.\n"
        "Lexico cerrado. Si no hay ficha: DESCONOCIDO. No soy un LLM."
    )


def render_lang(user: str, corr: Corrected) -> str:
    intent = lang_intent(corr.text)
    prefix = ""
    if corr.dirty:
        prefix = compose_human("fix", fixes=corr.fixes) + "\n"
    if intent == "conjuga":
        lemma = extract_verb_lemma(corr.text) or "hablar"
        tense = detect_tense_word(corr.text)
        return prefix + tense_table(lemma, tense)
    if intent == "corrige":
        if not corr.dirty:
            return prefix + "No detecte errores en el lexico. Si la palabra no existe aqui, no la invento."
        return prefix + f"Texto supuesto: {corr.text}"
    if intent == "rewrite":
        tense = detect_tense_word(corr.text) or "pret"
        # strip the command prefix
        body = corr.text
        for cut in ("pon en pasado", "pon en preterito", "pon en futuro", "pon en subjuntivo",
                    "pon en condicional", "pon en presente", "pasa a pasado", "pasa a futuro"):
            fl = fold(body)
            if fl.startswith(cut):
                body = body[len(cut):].lstrip(" :,-")
                break
        if ":" in body:
            body = body.split(":", 1)[1].strip()
        out = rewrite_tense(body or corr.text, tense)
        return prefix + f"G_lang · {TENSE_NAME.get(tense, tense)}\n{out}"
    if intent == "grammar":
        return prefix + grammar_note()
    return prefix


LEXICON_SIZE = len(LEX)
VERB_COUNT = len(VERBS)
