"""NAVI 6.6 — TUI ANSI (host). Double buffer, spinner, streaming, slash cmds."""

from __future__ import annotations

import os
import select
import shutil
import sys
import threading
import time
from typing import List, Optional, Tuple

from navi66_engine import NAVI66Engine, Turn66

# TrueColor: fondo oscuro, texto gris claro, acentos verde/azul eléctricos
BG = "\x1b[48;2;10;10;12m"
FG = "\x1b[38;2;232;232;234m"
DIM = "\x1b[38;2;136;136;144m"
ACC = "\x1b[38;2;200;200;208m"     # humo / plata
BLU = "\x1b[38;2;180;180;188m"
YEL = "\x1b[38;2;220;220;200m"
RED = "\x1b[38;2;255;90;80m"
USR = "\x1b[38;2;180;190;210m"
RST = "\x1b[0m"
BOLD = "\x1b[1m"
HIDE = "\x1b[?25l"
SHOW = "\x1b[?25h"
ALT = "\x1b[?1049h"
MAIN = "\x1b[?1049l"
CLEAR = "\x1b[2J\x1b[H"

SPIN = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
KW_PY = {"def", "class", "return", "import", "from", "if", "else", "for", "in", "None", "True", "False"}
KW_JS = {"function", "const", "let", "return", "import", "export", "if", "else", "async", "await"}
KW_RS = {"fn", "let", "mut", "return", "use", "pub", "struct", "impl", "if", "else", "match"}


class Block:
    def __init__(self, who: str, text: str, mask: str = "", ms: float = 0, streaming: bool = False):
        self.who = who
        self.text = text
        self.mask = mask
        self.ms = ms
        self.streaming = streaming
        self.shown = 0 if streaming else len(text)


def _size() -> Tuple[int, int]:
    s = shutil.get_terminal_size((80, 24))
    return max(60, s.columns), max(16, s.lines)


def _wrap(text: str, width: int) -> List[str]:
    lines: List[str] = []
    for raw in text.split("\n"):
        if not raw:
            lines.append("")
            continue
        while len(raw) > width:
            cut = raw.rfind(" ", 0, width)
            if cut < 8:
                cut = width
            lines.append(raw[:cut])
            raw = raw[cut:].lstrip()
        lines.append(raw)
    return lines


def _hl(line: str, lang: str) -> str:
    kws = KW_PY if lang == "python" else KW_JS if lang == "js" else KW_RS if lang == "rust" else set()
    if not kws:
        return YEL + line + FG
    out = []
    buf = ""
    i = 0
    while i < len(line):
        ch = line[i]
        if ch.isalnum() or ch == "_":
            buf += ch
            i += 1
            continue
        if buf:
            out.append((ACC if buf in kws else YEL) + buf + FG)
            buf = ""
        out.append(DIM + ch + FG if ch in "(){}[]:;," else ch)
        i += 1
    if buf:
        out.append((ACC if buf in kws else YEL) + buf + FG)
    return "".join(out)


def paint_block(b: Block, width: int) -> List[str]:
    inner = width - 4
    vis = b.text[: b.shown]
    title = "tú" if b.who == "user" else f"NAVI 7 · G_{b.mask or 'talk'}"
    if b.who != "user" and b.ms:
        title += f" · {b.ms:.1f} ms"
    color = USR if b.who == "user" else ACC
    bar = "─" * max(1, inner - len(title) - 1)
    out = [f"{color}╭─ {title} {bar}╮{FG}"]
    lang = ""
    in_code = False
    for line in _wrap(vis, inner):
        if line.startswith("```"):
            tag = line.strip("`").strip().lower()
            in_code = not in_code if line.strip() == "```" else True
            if tag in ("python", "py"):
                lang = "python"
            elif tag in ("js", "javascript"):
                lang = "js"
            elif tag in ("rs", "rust"):
                lang = "rust"
            elif line.strip() == "```":
                lang = ""
                in_code = False
            body = DIM + line[:inner].ljust(inner) + FG
        elif in_code:
            body = _hl(line[:inner].ljust(inner), lang)
        else:
            body = line[:inner].ljust(inner)
        out.append(f"{color}│{FG} {body} {color}│{FG}")
    out.append(f"{color}╰{'─' * (inner + 2)}╯{FG}")
    return out


class TUI:
    def __init__(self, eng: NAVI66Engine):
        self.eng = eng
        self.blocks: List[Block] = []
        self.input = ""
        self.status = "listo"
        self.spin_i = 0
        self.busy = False
        self.alive = True
        self.lock = threading.Lock()
        self.scroll = 0
        self.project = os.path.basename(os.getcwd()) or "rxos"
        self.tokens = 0

    def think(self, text: str) -> None:
        with self.lock:
            self.busy = True
            self.status = "pensando"
        try:
            turn = self.eng.think(text)
        except Exception as exc:  # noqa: BLE001
            turn = Turn66(user=text, reply=f"error interno: {exc}", mask="unknown", ms=0)
        with self.lock:
            self.busy = False
            self.status = "escribiendo"
            self.tokens += max(1, len(turn.reply) // 4)
            self.blocks.append(Block("navi", turn.reply, turn.mask, turn.ms, streaming=True))

    def render(self) -> None:
        cols, rows = _size()
        with self.lock:
            blocks = list(self.blocks)
            inp = self.input
            status = self.status
            busy = self.busy
            si = self.spin_i
            tokens = self.tokens
        # advance stream
        for b in blocks:
            if b.streaming and b.shown < len(b.text):
                b.shown = min(len(b.text), b.shown + 2)
                if b.shown >= len(b.text):
                    b.streaming = False
                    status = "listo"
        lines: List[str] = []
        lines.append(f"{ACC}{BOLD} NAVI 7.5{RST}{BG}{FG}  Smoke Aero · catalogo + harvest + memoria · no soy un LLM")
        lines.append(f"{DIM}{'─' * cols}{FG}")
        body_h = rows - 6
        painted: List[str] = []
        for b in blocks:
            painted.extend(paint_block(b, cols))
            painted.append("")
        view = painted[-body_h:] if len(painted) > body_h else painted + [""] * (body_h - len(painted))
        lines.extend(view[:body_h])
        spin = SPIN[si % len(SPIN)] if busy else "●"
        sc = YEL if busy else ACC
        lines.append(f"{DIM}{'─' * cols}{FG}")
        prompt = f"{BLU}> {FG}{inp}{ACC}▍{FG}"
        lines.append(prompt[: cols + 16])
        foot = (
            f"{sc}{spin}{FG} {status:<12} {DIM}|{FG} Proyecto: {self.project} "
            f"{DIM}|{FG} Rama: lab {DIM}|{FG} Tokens~ {tokens} "
            f"{DIM}|{FG} {BLU}/clear /file /exit /trace /stats{FG}"
        )
        lines.append(foot[: cols + 40])
        buf = BG + HIDE + "\x1b[H" + "\n".join(lines) + RST
        sys.stdout.write(buf)
        sys.stdout.flush()

    def run(self) -> None:
        sys.stdout.write(ALT + BG + CLEAR)
        sys.stdout.flush()
        self.blocks.append(
            Block(
                "navi",
                "Me llamo NAVI. Soy 7.5: catalogo, harvest en vivo y memoria. "
                "Preguntame como me llamo, busca en la red o pide un verso. "
                "No soy un LLM. Prueba: «que comunidades autonomas tiene Spain».",
                "talk",
                0,
                streaming=True,
            )
        )
        try:
            import termios
            import tty

            fd = sys.stdin.fileno()
            old = termios.tcgetattr(fd)
            tty.setcbreak(fd)
            try:
                while self.alive:
                    self.spin_i += 1
                    self.render()
                    r, _, _ = select.select([sys.stdin], [], [], 0.03)
                    if not r:
                        continue
                    ch = sys.stdin.read(1)
                    if ch in ("\x03", "\x04"):
                        break
                    if ch in ("\x7f", "\b"):
                        self.input = self.input[:-1]
                        continue
                    if ch == "\n":
                        line = self.input.strip()
                        self.input = ""
                        if not line:
                            continue
                        if line in ("/exit", "/quit"):
                            break
                        if line == "/clear":
                            self.blocks.clear()
                            continue
                        if line == "/stats":
                            import json

                            self.blocks.append(Block("navi", json.dumps(self.eng.metrics, indent=2), "rxos"))
                            continue
                        if line == "/trace":
                            tr = self.eng.last_trace.as_dict() if self.eng.last_trace else {"ok": False}
                            import json

                            self.blocks.append(Block("navi", json.dumps(tr, indent=2, ensure_ascii=False), "reason"))
                            continue
                        if line.startswith("/file "):
                            path = line[6:].strip()
                            try:
                                data = open(path, encoding="utf-8").read()[:4000]
                            except OSError as exc:
                                data = f"no pude leer {path}: {exc}"
                            self.blocks.append(Block("navi", data, "rxos"))
                            continue
                        self.blocks.append(Block("user", line, "in"))
                        threading.Thread(target=self.think, args=(line,), daemon=True).start()
                        continue
                    if ch.isprintable():
                        self.input += ch
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            sys.stdout.write(SHOW + MAIN + RST)
            sys.stdout.flush()
