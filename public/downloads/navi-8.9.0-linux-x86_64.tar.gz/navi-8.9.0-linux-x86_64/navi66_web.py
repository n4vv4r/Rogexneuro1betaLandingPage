"""NAVI 6.6 host: HTTP GET/POST + Google search (same contract as the kernel)."""

from __future__ import annotations

import html as htmlmod
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import List, Optional, Tuple

UA = "rxOS-curl/8.5 (NAVI-6.6 host)"


def url_encode(s: str) -> str:
    return urllib.parse.quote_plus(s or "")


def html_text(raw: str) -> str:
    s = re.sub(r"(?is)<script[^>]*>.*?</script>", " ", raw or "")
    s = re.sub(r"(?is)<style[^>]*>.*?</style>", " ", s)
    s = re.sub(r"(?s)<[^>]+>", " ", s)
    s = htmlmod.unescape(s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _open(url: str, data: Optional[bytes] = None, timeout: float = 8.0) -> Tuple[int, str, str]:
    req = urllib.request.Request(
        url,
        data=data,
        method="POST" if data is not None else "GET",
        headers={"User-Agent": UA, "Accept": "*/*"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read(48 * 1024)
            ctype = resp.headers.get("Content-Type", "")
            enc = "latin-1"
            if "charset=" in ctype.lower():
                enc = ctype.lower().split("charset=", 1)[1].split(";")[0].strip() or enc
            try:
                text = body.decode(enc, "replace")
            except LookupError:
                text = body.decode("latin-1", "replace")
            return int(getattr(resp, "status", 200) or 200), text, resp.geturl()
    except urllib.error.HTTPError as e:
        raw = e.read(48 * 1024) if e.fp else b""
        return int(e.code), raw.decode("latin-1", "replace"), url
    except Exception as e:
        return 0, str(e), url


def http_get(url: str) -> Tuple[int, str]:
    st, body, _ = _open(url)
    return st, body


def http_post(url: str, body: str, ctype: str = "application/x-www-form-urlencoded") -> Tuple[int, str]:
    data = (body or "").encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers={"User-Agent": UA, "Content-Type": ctype, "Accept": "*/*"},
    )
    try:
        with urllib.request.urlopen(req, timeout=8.0) as resp:
            raw = resp.read(48 * 1024)
            return int(getattr(resp, "status", 200) or 200), raw.decode("latin-1", "replace")
    except urllib.error.HTTPError as e:
        raw = e.read(48 * 1024) if e.fp else b""
        return int(e.code), raw.decode("latin-1", "replace")
    except Exception as e:
        return 0, str(e)


def google_search(query: str) -> Tuple[int, str]:
    """Search: DuckDuckGo + Wikipedia first. Google gbv=1 is a last resort."""
    titles: List[str] = []
    src = ""
    st = 0
    try:
        from navi75_harvest import ddg_instant, ddg_lite_titles, wiki_search

        inst = ddg_instant(query)
        if inst:
            st = 200
            src = "duckduckgo"
            if inst.get("abstract"):
                titles.append(inst["abstract"][:220])
            titles.extend(inst.get("related") or [])
        for t in ddg_lite_titles(query):
            if t not in titles:
                titles.append(t)
            if len(titles) >= 6:
                break
        if titles:
            st = 200
            src = src or "duckduckgo"
        if not titles:
            hits = wiki_search(query, "es") or wiki_search(query, "en")
            if hits:
                st = 200
                src = "wikipedia"
                titles.extend(hits[:6])
    except Exception:
        titles = []

    if not titles:
        q = url_encode(query)
        url = f"http://www.google.com/search?gbv=1&hl=es&num=8&q={q}"
        st, body = http_get(url)
        for m in re.finditer(r"(?is)<h3[^>]*>(.*?)</h3>", body):
            t = html_text(m.group(1)).strip()
            if len(t) >= 4:
                titles.append(t)
            if len(titles) >= 6:
                break
        src = "google"
        if not titles:
            lines = [f'G_news google "{query}" HTTP {st}  {len(body)} B']
            if st:
                plain = html_text(body)[:400]
                lines.append(plain or "(html sin titulos extraibles)")
            else:
                lines.append(body or "sin respuesta")
            return st, "\n".join(lines)

    lines = [f'busqueda "{query}" via {src} HTTP {st}']
    for i, t in enumerate(titles[:6], 1):
        lines.append(f"{i}) {t}")
    return st or 200, "\n".join(lines)


def looks_web(s: str) -> bool:
    t = (s or "").strip().lower()
    if not t:
        return False
    heads = (
        "/curl", "curl", "/search", "/google", "search", "google",
        "busca", "buscar", "buscame", "/fetch",
    )
    for h in heads:
        if t == h or t.startswith(h + " "):
            return True
    if "http://" in t or "https://" in t or "busca en google" in t:
        return True
    if t.startswith("que es ") or t.startswith("quien es ") or t.startswith("info sobre "):
        if any(k in t for k in ("navi", "rxos", "wsp", "mascara")):
            return False
        return True
    return False


def run_web(user: str) -> str:
    t = (user or "").strip()
    low = t.lower()
    for pref in (
        "/curl ", "curl ", "/search ", "/google ", "/fetch ",
        "search ", "google ", "busca ", "buscar ", "buscame ",
    ):
        if low.startswith(pref):
            t = t[len(pref):].strip()
            break
    if "http://" in t or "https://" in t:
        post = False
        body = ""
        words = t.split()
        if words and words[0].lower() == "post":
            post = True
            words = words[1:]
        url = ""
        rest: List[str] = []
        for w in words:
            if not url and w.startswith("http"):
                url = w
            elif url:
                rest.append(w)
        if not url:
            return "G_news: URL vacia."
        if post or rest:
            st, raw = http_post(url, " ".join(rest))
            verb = "POST"
        else:
            st, raw = http_get(url)
            verb = "GET"
        text = html_text(raw)[:420]
        return f"G_news {verb} HTTP {st}  {len(raw)} B\n{text}"
    if not t:
        return "G_news: dime la URL o la busqueda. /curl http://...  /search tema"
    _, ans = google_search(t)
    return ans
