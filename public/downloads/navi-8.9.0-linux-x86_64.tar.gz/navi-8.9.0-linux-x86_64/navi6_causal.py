"""
NAVI 6 — motor causal / contrafáctico sobre átomos WSP.
No es correlación: aristas dirigidas, do-calculus (mutilar padres) e
intervenciones. La “inteligencia” aquí es un DAG + mecanismos, no un LLM.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from navi5_engine import WSP_ATOMS, WSPFrame, ROGEXWSPCodec


@dataclass
class CausalEdge:
    cause: str
    effect: str
    strength: float
    mechanism: str
    domain: str = "general"


@dataclass
class CausalDAG:
    edges: List[CausalEdge] = field(default_factory=list)
    priors: Dict[str, float] = field(default_factory=dict)

    def add(self, cause: str, effect: str, strength: float, mechanism: str,
            domain: str = "general"):
        self.edges.append(CausalEdge(cause, effect, float(strength), mechanism, domain))
        self.priors.setdefault(cause, 0.35)
        self.priors.setdefault(effect, 0.35)

    def children(self, node: str) -> List[CausalEdge]:
        return [e for e in self.edges if e.cause == node]

    def parents(self, node: str) -> List[CausalEdge]:
        return [e for e in self.edges if e.effect == node]

    def intervene(self, node: str, value: float) -> Dict[str, float]:
        """do(node=value): corta padres de node y propaga."""
        state = dict(self.priors)
        state[node] = float(value)
        for _ in range(10):
            nxt = dict(state)
            nxt[node] = float(value)
            effects = {e.effect for e in self.edges if e.effect != node}
            for effect in effects:
                parents = [x for x in self.edges if x.effect == effect]
                if not parents:
                    continue
                acc = sum(state.get(x.cause, 0.3) * x.strength for x in parents)
                wsum = sum(abs(x.strength) for x in parents) or 1.0
                nxt[effect] = max(0.0, min(1.5, acc / wsum))
            state = nxt
        return state

    def counterfactual(self, node: str, value: float) -> Dict:
        base = dict(self.priors)
        alt = self.intervene(node, value)
        delta = {k: alt.get(k, 0.0) - base.get(k, 0.0) for k in set(base) | set(alt)}
        return {"node": node, "value": value, "state": alt, "delta": delta}

    def root_causes(self, symptom: str, k: int = 3) -> List[Tuple[str, float, str]]:
        hits = []
        for e in self.edges:
            if e.effect == symptom or symptom in e.effect or symptom in e.mechanism.lower():
                hits.append((e.cause, e.strength, e.mechanism))
        hits.sort(key=lambda x: -x[1])
        return hits[:k]

    def from_wsp(self, frame: WSPFrame) -> Optional[CausalEdge]:
        atoms = [WSP_ATOMS[a % len(WSP_ATOMS)] for a in frame.atom_tuple()]
        if "CAUSA" in atoms or "EFECTO" in atoms:
            cause = atoms[0]
            effect = atoms[2]
            self.add(cause, effect, 0.4, "wsp-induced", "wsp")
            return self.edges[-1]
        return None


def default_curriculum_dag() -> CausalDAG:
    """Conocimiento causal semilla (laboratorio). Se refuerza al entrenar."""
    g = CausalDAG()
    # Concurrencia / GPU
    g.add("cpu_alloc_queue", "spin_lock", 0.92, "cola síncrona más rápida que el ACK GPU", "concurrency")
    g.add("spin_lock", "ram_spike", 0.88, "tareas retenidas llenan el heap", "concurrency")
    g.add("spin_lock", "gpu_stall", 0.7, "la GPU espera confirmaciones que no llegan", "concurrency")
    g.add("thread_flood", "cpu_alloc_queue", 0.8, "más hilos que slots de envío", "concurrency")
    g.add("ring_buffer", "spin_lock", -0.75, "lock-free elimina la contención", "concurrency")
    g.add("shared_mem", "cache_incoherence", 0.65, "falsos compartidos entre núcleos", "concurrency")
    g.add("cache_incoherence", "bus_latency", 0.62, "snoop/invalidate en el bus", "concurrency")
    g.add("sample_down", "thread_flood", -0.45, "menos hilos, menos presión", "concurrency")
    # SNN / energía
    g.add("high_rate", "energy_uj", 0.7, "más spikes, más μJ", "snn")
    g.add("vth_up", "high_rate", -0.55, "umbral alto silencia", "snn")
    # WSP
    g.add("CAUSA", "EFECTO", 0.5, "átomo causal canónico", "wsp")
    g.add("PREGUNTAR", "RESPONDER", 0.45, "turno de diálogo", "wsp")
    return g


class WSPCausalCodec:
    def __init__(self):
        self.codec = ROGEXWSPCodec()

    def encode(self, text: str) -> WSPFrame:
        return self.codec.create_symbol(text.encode("utf-8", errors="ignore")).frame
