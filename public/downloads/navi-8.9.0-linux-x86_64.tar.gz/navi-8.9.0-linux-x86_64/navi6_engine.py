"""
NAVI 6 Engine — tutor causal local.
Capas reales: neurogénesis, DAG, world model, enjambre jerárquico, Q-WSP clásico.
No hay qubits ni millones de nodos. El castellano es máscara sobre WSP + DAG.
"""

from __future__ import annotations

import hashlib
import math
import re
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

from navi5_engine import NAVI5Engine, Q6Orchestrator, WSP_ATOMS
from navi5_snn import SNNConfig
from navi6_causal import CausalDAG, default_curriculum_dag, WSPCausalCodec
from navi6_snn import NAVI6SNN
from navi6_world import WorldModel, default_world


def _norm(text: str) -> str:
    t = text.lower()
    for a, b in (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
        t = t.replace(a, b)
    return t


class QWSP:
    """
    Superposición CLÁSICA: amplitudes complejas sobre átomos WSP.
    No es un computador cuántico. El nombre Q-WSP es el protocolo inspirado.
    """

    def __init__(self, n: int = 48):
        self.n = n
        self.amp = np.zeros(n, dtype=np.complex128)
        self.amp[0] = 1.0

    def encode_frame_atoms(self, atoms: List[int]):
        self.amp[:] = 0
        for i, a in enumerate(atoms):
            phase = 2j * math.pi * (i + 1) / 4.0
            self.amp[int(a) % self.n] += np.exp(phase)
        nrm = np.linalg.norm(self.amp)
        if nrm > 0:
            self.amp /= nrm

    def interfere(self, other: "QWSP", theta: float = 0.5) -> "QWSP":
        out = QWSP(self.n)
        out.amp = (1 - theta) * self.amp + theta * other.amp
        nrm = np.linalg.norm(out.amp)
        if nrm > 0:
            out.amp /= nrm
        return out

    def measure(self) -> int:
        p = np.abs(self.amp) ** 2
        s = float(p.sum())
        if s <= 0:
            return 31
        p = p / s
        return int(np.argmax(p))

    def entropy(self) -> float:
        p = np.abs(self.amp) ** 2
        p = p[p > 1e-12]
        if p.size == 0:
            return 0.0
        p = p / p.sum()
        return float(-np.sum(p * np.log2(p)))


class FractalSwarm:
    """
    Enjambre jerárquico: clusters → meta-consenso.
    Escala de laboratorio (decenas), no millones. Asíncrono = un paso por nivel.
    """

    def __init__(self, clusters: int = 4, members: int = 3):
        self.orch = [
            Q6Orchestrator(num_instances=members, agreement_target=0.9)
            for _ in range(clusters)
        ]
        cfg = SNNConfig()
        cfg.num_neurons = 48
        cfg.num_synapses = 160
        for i, o in enumerate(self.orch):
            for j in range(members):
                eng = NAVI5Engine(f"C{i}M{j}", cfg)
                o.register_instance(eng.instance_id, eng)
        self.metrics = {"rounds": 0, "agreement": 0.0}

    def decide(self, payload: bytes) -> Dict:
        votes = []
        agr = []
        for o in self.orch:
            r = o.resolve_task(
                {"kind": "symbolic_encode", "payload": payload, "capability": "symbolic_reasoning"},
                max_iters=2,
            )
            votes.append(tuple(r.get("proposal", {}).get("atoms", ())))
            agr.append(float(r.get("agreement_rate", 0.0)))
        # meta-voto: moda
        best = max(set(votes), key=votes.count) if votes else ()
        self.metrics["rounds"] += 1
        self.metrics["agreement"] = float(np.mean(agr)) if agr else 0.0
        return {"atoms": best, "cluster_agreement": self.metrics["agreement"], "votes": votes}


@dataclass
class TutorTurn:
    user: str
    reply: str
    internal: Dict = field(default_factory=dict)
    ms: float = 0.0


class NAVI6Engine:
    def __init__(self, trained: Optional[Dict] = None):
        cfg = SNNConfig()
        cfg.num_neurons = 128
        cfg.num_synapses = 512
        self.snn = NAVI6SNN(cfg, subnetwork_id=6)
        self.dag: CausalDAG = default_curriculum_dag()
        self.world: WorldModel = default_world()
        self.wsp = WSPCausalCodec()
        self.swarm = FractalSwarm(clusters=3, members=2)
        self.known_domains = {"concurrency", "snn", "wsp", "general"}
        self.self_questions: List[str] = []
        self.metrics = {
            "turns": 0,
            "rollouts": 0,
            "counterfactuals": 0,
            "unknown_domains": 0,
            "fitness": 0.5,
        }
        if trained:
            self.load_state(trained)

    def detect(self, text: str) -> Dict:
        t = _norm(text)
        domain = "general"
        if any(k in t for k in ("gpu", "hilo", "thread", "ram", "lock", "buffer", "cola", "vram")):
            domain = "concurrency"
        elif any(k in t for k in ("spike", "vth", "sinaps", "snn")):
            domain = "snn"
        cf = bool(re.search(r"que pasaria|what if|y si |si en lugar|en vez", t))
        intent = "counterfactual" if cf else "diagnose"
        if "por que" in t or "causa" in t:
            intent = "why"
        return {"domain": domain, "counterfactual": cf, "intent": intent}

    def _option_from_text(self, text: str) -> Optional[str]:
        t = _norm(text)
        # "en lugar de X uso Y" → Y gana
        if "compartid" in t or "shared" in t:
            return "shared_mem"
        if "ring" in t or "lock-free" in t or "lock free" in t:
            return "ring_buffer"
        if "frecuen" in t or "menos hilo" in t:
            return "sample_down"
        return None

    def think(self, user: str) -> TutorTurn:
        t0 = time.perf_counter()
        det = self.detect(user)
        frame = self.wsp.encode(user)
        self.dag.from_wsp(frame)

        if det["domain"] not in self.known_domains:
            self.snn.spawn_microcircuit(det["domain"])
            self.known_domains.add(det["domain"])
            self.metrics["unknown_domains"] += 1

        # SNN + metabolismo
        cur = self.wsp.codec.to_snn_current(frame, self.snn.config.num_neurons)
        for _ in range(6):
            self.snn.step(cur)
        self.snn.autotune_metabolism()

        qw = QWSP()
        qw.encode_frame_atoms(list(frame.atom_tuple()))
        swarm = self.swarm.decide(user.encode("utf-8", errors="ignore"))

        scenario = "gpu_threads_ram" if det["domain"] == "concurrency" else "snn_overload"
        options = ["ring_buffer", "shared_mem", "sample_down"] if scenario == "gpu_threads_ram" else ["vth_up"]
        ranked = self.world.compare_options(scenario, options, n=36)
        self.metrics["rollouts"] += sum(r["n"] for r in ranked)

        asked = self._option_from_text(user)
        cf_report = None
        if det["counterfactual"] and asked:
            node = "shared_mem" if asked == "shared_mem" else asked
            cf_report = self.dag.counterfactual(node, 1.0)
            self.metrics["counterfactuals"] += 1

        roots = self.dag.root_causes("spin_lock" if det["domain"] == "concurrency" else "energy_uj")
        reply = self._render(user, det, ranked, cf_report, roots, asked, qw, swarm)
        self.metrics["turns"] += 1
        self.metrics["fitness"] = 0.55 + 0.15 * min(1.0, self.metrics["rollouts"] / 400)
        ms = (time.perf_counter() - t0) * 1000.0
        return TutorTurn(
            user=user,
            reply=reply,
            ms=ms,
            internal={
                "detect": det,
                "atoms": list(frame.atom_tuple()),
                "qwsp_entropy": qw.entropy(),
                "qwsp_atom": WSP_ATOMS[qw.measure() % len(WSP_ATOMS)],
                "swarm": swarm,
                "ranked": [
                    {"opt": r["option"], "F": round(r["free_energy"], 4),
                     "ram": round(r["mean_state"].get("ram_spike", 0), 3),
                     "lat": round(r["mean_state"].get("bus_latency", 0), 3)}
                    for r in ranked
                ],
                "roots": roots,
                "counterfactual": cf_report["delta"] if cf_report else None,
                "v_th": self.snn.config.v_th,
                "tau": self.snn.config.tau,
                "syn_grown": self.snn.metrics["synapses_grown"],
            },
        )

    def _render(self, user, det, ranked, cf_report, roots, asked, qw, swarm) -> str:
        if det["domain"] == "concurrency" and not det["counterfactual"]:
            best = ranked[0]["option"] if ranked else "ring_buffer"
            return (
                "Nucleo WSP detectado: contencion CPU, no falta de VRAM.\n"
                "Causa raiz (DAG): la CPU encola mas rapido de lo que la GPU confirma "
                "-> spin-lock en la cola de asignacion -> RAM llena y GPU aparentemente bloqueada.\n"
                "Modelo del mundo (rollouts de energia libre):\n"
                "  Opcion 1 ring-buffer lock-free: minimiza F y baja ram_spike.\n"
                "  Opcion 2 bajar frecuencia de hilos: frena el fallo, deja latencia residual.\n"
                "  Opcion 3 memoria compartida: coherencia de cache sube latencia de bus.\n"
                f"Recomendacion Q-WSP/enjambre: {best} "
                f"(acuerdo clusters={swarm['cluster_agreement']:.2f}, H={qw.entropy():.2f}).\n"
                "¿Aplicamos la opcion 1 o simulo otro enfoque?"
            )
        if det["counterfactual"] and asked == "shared_mem":
            lat = 0.0
            if ranked:
                sm = next((r for r in ranked if r["option"] == "shared_mem"), ranked[-1])
                rb = next((r for r in ranked if r["option"] == "ring_buffer"), ranked[0])
                lat = sm["mean_state"].get("bus_latency", 0) - rb["mean_state"].get("bus_latency", 0)
            pct = max(5, min(40, int(abs(lat) * 100)))
            return (
                "Contrafáctico do(shared_mem=1): la incoherencia de cache entre nucleos "
                f"incrementa la latencia de bus (~{pct}% relativo al ring-buffer) y no elimina el spin-lock.\n"
                "El ring-buffer lock-free sigue dominando en energia libre.\n"
                "Ruta WSP: CAUSA(spin_lock) -x-> EFECTO(ram_spike) se mantiene si no cortas la cola síncrona."
            )
        if det["counterfactual"] and asked == "ring_buffer":
            return (
                "do(ring_buffer=1): el DAG mutila la arista cola->spin_lock. "
                "ram_spike y gpu_stall caen en el world model. Es la via de menor energia libre."
            )
        if det["domain"] == "snn":
            return (
                f"Metabolismo autonomo: V_th={self.snn.config.v_th:.3f} tau={self.snn.config.tau:.2f}. "
                "Si la tasa sube, subo umbral; si el silencio crece, lo bajo. "
                f"Sinapsis crecidas={self.snn.metrics['synapses_grown']}."
            )
        atoms = " ".join(WSP_ATOMS[a % len(WSP_ATOMS)] for a in (det and []))
        return (
            "Contexto WSP registrado. No invento codigo que no he simulado.\n"
            "Puedo diagnosticar contencion/GPU/RAM, metabolismo SNN y contrafactuales "
            "sobre el DAG que conozco. Formula una hipotesis ('que pasaria si...') "
            "o describe el fallo (hilos, GPU, RAM)."
        )

    def ask_self(self) -> str:
        """Genera material de entrenamiento propio a partir del DAG."""
        if not self.dag.edges:
            return "PREGUNTAR DESCONOCIDO"
        e = self.dag.edges[self.metrics["turns"] % len(self.dag.edges)]
        q = f"que pasaria si {e.cause} cambia y {e.effect} se mantiene?"
        self.self_questions.append(q)
        return q

    def snapshot(self) -> Dict:
        return {
            "metrics": self.metrics,
            "snn": {
                "v_th": self.snn.config.v_th,
                "tau": self.snn.config.tau,
                "grown": self.snn.metrics["synapses_grown"],
                "retired": self.snn.metrics["synapses_retired"],
                "circuits": self.snn.metrics["microcircuits"],
                "weights": self.snn.weights.astype(np.float32),
                "pre": self.snn.pre_synaptic,
                "post": self.snn.post_synaptic,
            },
            "edges": [
                (e.cause, e.effect, e.strength, e.mechanism, e.domain)
                for e in self.dag.edges
            ],
            "known_domains": sorted(self.known_domains),
            "self_questions": list(self.self_questions),
        }

    def load_state(self, snap: Dict):
        if "edges" in snap:
            self.dag = CausalDAG()
            for row in snap["edges"]:
                self.dag.add(*row)
        if "known_domains" in snap:
            self.known_domains = set(snap["known_domains"])


def reply(text: str, engine: Optional[NAVI6Engine] = None) -> TutorTurn:
    eng = engine or NAVI6Engine()
    return eng.think(text)
