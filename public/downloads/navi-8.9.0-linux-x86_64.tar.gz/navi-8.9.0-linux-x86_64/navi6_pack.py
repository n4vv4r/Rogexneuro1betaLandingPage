#!/usr/bin/env python3
"""Empaqueta NAVI6W01 — conocimiento causal + plantillas para el unikernel.

El kernel no corre Numba. Este blob es la parte PUBLICABLE del modelo
entrenado: DAG + escenarios + máscaras ASCII. Magic 8 B + header 64 B.
"""

from __future__ import annotations

import argparse
import json
import struct
import zlib
from pathlib import Path

MAGIC = b"NAVI6W01"
HDR = 64
VER = 1

# Plantillas cortas (ASCII) que el kernel puede emitir. Ids fijos.
TEMPLATES = [
    # 0 diagnose gpu
    "Causa raiz: cola CPU mas rapida que ACK GPU (spin-lock). No es falta de VRAM. "
    "O1 ring-buffer lock-free. O2 menos hilos (parches). O3 shared-mem sube latencia de bus.",
    # 1 cf shared
    "Contrafáctico shared-mem: incoherencia de cache sube latencia de bus. "
    "El ring-buffer sigue siendo la via de menor energia libre.",
    # 2 cf ring
    "do(ring_buffer): se corta cola->spin_lock. RAM y stall GPU bajan.",
    # 3 snn
    "Metabolismo autonomo NAVI-6.5: Vth/tau se autorregulan. No soy un LLM.",
    # 4 fallback
    "NAVI-6.5 RLC: PARSE-RETRIEVE-INFER-VERIFY-RENDER. "
    "Describe el fallo (hilos/GPU/RAM), un 'cuanto es', o un 'que pasaria si'.",
    # 5 prove
    "NAVI-6.5 en rxOS 8.5: 11 mascaras G_*, math entero, codigo con dry-run. "
    "Q-WSP=amplitudes no qubits. KCC: 0 instancias destruidas. Modelo preentrenado.",
    # 6 identity
    "NAVI 6.5. Transductor RLC local. Razono, hablo y emito codigo con esquema. No soy un LLM.",
]


def pack_payload(edges: list, v_th: float, tau: float) -> bytes:
    buf = bytearray()
    buf += struct.pack("<I", len(TEMPLATES))
    for t in TEMPLATES:
        raw = t.encode("ascii", errors="replace")[:240]
        buf += struct.pack("<H", len(raw)) + raw
    buf += struct.pack("<I", len(edges))
    for cause, effect, strength, _mech, domain in edges:
        # ids compactos: hash 4 B + q8 strength + domain tag
        ch = zlib.crc32(cause.encode()) & 0xFFFFFFFF
        eh = zlib.crc32(effect.encode()) & 0xFFFFFFFF
        q = int(max(-127, min(127, round(strength * 100))))
        dtag = {"concurrency": 1, "snn": 2, "wsp": 3}.get(domain, 0)
        tmpl = 0
        if "shared" in cause or "shared" in effect:
            tmpl = 1
        elif "ring" in cause:
            tmpl = 2
        elif domain == "snn":
            tmpl = 3
        buf += struct.pack("<IIbBB", ch, eh, q, dtag, tmpl)
    vq = int(max(1, min(255, round(v_th * 100))))
    tq = int(max(1, min(255, round(tau))))
    buf += struct.pack("<BB", vq, tq)
    return bytes(buf)


def header(payload: bytes) -> bytes:
    crc = zlib.crc32(payload) & 0xFFFFFFFF
    hdr = bytearray(HDR)
    hdr[0:8] = MAGIC
    struct.pack_into("<IIIIII", hdr, 8, VER, len(TEMPLATES), len(payload), crc, 0, 0)
    return bytes(hdr)


def write_bin(dest: Path, edges: list, v_th: float = 1.0, tau: float = 20.0) -> Path:
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    payload = pack_payload(edges, v_th, tau)
    dest.write_bytes(header(payload) + payload)
    return dest


def write_json_sidecar(dest: Path, snap: dict) -> Path:
    side = Path(dest).with_suffix(".json")
    clean = {k: v for k, v in snap.items() if k != "snn"}
    if "snn" in snap:
        clean["snn"] = {k: snap["snn"][k] for k in ("v_th", "tau", "grown", "retired", "circuits")}
    side.write_text(json.dumps(clean, indent=2, default=str))
    return side


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="NAVI_AI_SNN/l3/navi6_weights.bin")
    ap.add_argument("--stub", action="store_true")
    args = ap.parse_args()
    from navi6_causal import default_curriculum_dag
    dag = default_curriculum_dag()
    edges = [(e.cause, e.effect, e.strength, e.mechanism, e.domain) for e in dag.edges]
    p = write_bin(Path(args.out), edges)
    print(f"wrote {p} ({p.stat().st_size} B)")


if __name__ == "__main__":
    main()
