"""
NAVI 6 SNN — plasticidad topológica sobre NAVI 5.
Neurogénesis de SINAPSIS (no de instancias: KCC se mantiene).
Autoajuste metabólico de V_th y τ según carga y μJ/spike.
"""

from __future__ import annotations

from typing import Dict, Optional

import numpy as np

from navi5_snn import NAVI5SNN, SNNConfig


class NAVI6SNN(NAVI5SNN):
    """LIF+STDP con crecimiento/recorte de aristas y metabolismo autónomo."""

    def __init__(self, config: Optional[SNNConfig] = None, subnetwork_id: int = 0):
        super().__init__(config or SNNConfig(), subnetwork_id=subnetwork_id)
        self.metrics["synapses_grown"] = 0
        self.metrics["synapses_retired"] = 0
        self.metrics["microcircuits"] = 0
        self.metrics["autotune_steps"] = 0
        self.domain_circuits: Dict[str, np.ndarray] = {}

    def autotune_metabolism(self) -> Dict:
        """Autorregula V_th y τ. El humano ya no fija las constantes."""
        cfg = self.config
        rate = float(self.metrics.get("avg_firing_rate", 0.0))
        uj = float(self.metrics.get("energy_uj_per_spike", 1.0))
        target = cfg.target_firing_rate
        before = (cfg.v_th, cfg.tau)
        if rate > target * 2.2:
            cfg.v_th = min(1.85, cfg.v_th * 1.045)
            cfg.tau = max(8.0, cfg.tau * 0.97)
        elif rate < target * 0.25:
            cfg.v_th = max(0.45, cfg.v_th * 0.96)
            cfg.tau = min(42.0, cfg.tau * 1.025)
        if uj > cfg.energy_uj_per_spike * 1.15:
            cfg.v_th = min(1.85, cfg.v_th * 1.02)
        cfg.threshold = cfg.v_th
        self.metrics["autotune_steps"] += 1
        return {
            "v_th": cfg.v_th,
            "tau": cfg.tau,
            "rate": rate,
            "uj": uj,
            "changed": before != (cfg.v_th, cfg.tau),
        }

    def grow_synapse(self, pre: int, post: int, weight: float = 0.28) -> bool:
        n = self.config.num_neurons
        pre = int(pre) % n
        post = int(post) % n
        if pre == post:
            return False
        self.pre_synaptic = np.append(self.pre_synaptic, np.int32(pre))
        self.post_synaptic = np.append(self.post_synaptic, np.int32(post))
        self.weights = np.append(self.weights, np.float64(weight))
        self.config.num_synapses = int(len(self.weights))
        self.metrics["synapses_grown"] += 1
        return True

    def retire_weak_synapses(self, thresh: float = 0.03, keep_min: int = 16) -> int:
        """Retira sinapsis muertas. No toca instancias (KCC)."""
        if len(self.weights) <= keep_min:
            return 0
        mask = self.weights >= thresh
        if int(np.sum(mask)) < keep_min:
            order = np.argsort(-self.weights)
            mask = np.zeros_like(self.weights, dtype=bool)
            mask[order[:keep_min]] = True
        retired = int(np.sum(~mask))
        if retired == 0:
            return 0
        self.pre_synaptic = self.pre_synaptic[mask]
        self.post_synaptic = self.post_synaptic[mask]
        self.weights = self.weights[mask]
        self.config.num_synapses = int(len(self.weights))
        self.metrics["synapses_retired"] += retired
        return retired

    def spawn_microcircuit(self, domain: str, size: int = 24) -> Dict:
        """Subclúster especializado cuando el dominio es desconocido."""
        n = self.config.num_neurons
        rng = self.rng
        centers = rng.integers(0, n, size=max(4, size // 3))
        grown = 0
        idxs = []
        for a in centers:
            for _ in range(max(2, size // max(1, len(centers)))):
                b = int(rng.integers(0, n))
                if self.grow_synapse(int(a), b, weight=0.35):
                    grown += 1
                    idxs.append((int(a), b))
        self.domain_circuits[domain] = np.array(idxs, dtype=np.int32)
        self.metrics["microcircuits"] += 1
        return {"domain": domain, "grown": grown, "circuits": self.metrics["microcircuits"]}

    def step(self, external_input=None):
        metrics = super().step(external_input)
        if self.timestep % 12 == 0:
            self.autotune_metabolism()
        if self.timestep % 40 == 0:
            self.retire_weak_synapses()
        return metrics
