#!/usr/bin/env python3
"""
Entrena NAVI 5 (KCC) y destila NAVI 6 (causal + world + neurogénesis).
Escribe el modelo PUBLICABLE: navi6_weights.bin (ISO) + snapshot JSON.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from navi5_snn import SNNConfig
from navi6_engine import NAVI6Engine
from navi6_pack import write_bin, write_json_sidecar

CURRICULUM = [
    "estoy intentando optimizar un algoritmo de fisica en C++, pero cuando activo varios hilos la GPU se bloquea y la RAM se dispara. No se donde esta el cuello de botella.",
    "que pasaria si en lugar del ring buffer uso memoria compartida distribuida?",
    "que pasaria si uso un ring buffer lock-free?",
    "la tasa de spikes sube y el consumo por impulso crece",
    "por que la causa produce el efecto en WSP",
    "hilos GPU RAM lock cola asignacion",
]


def train_navi5_short(epochs: int, instances: int) -> dict:
    from run_peaceful_training import PeacefulTrainingSuite
    suite = PeacefulTrainingSuite(num_instances=instances, num_epochs=epochs)
    suite.config.snn_num_neurons = 64
    suite.config.snn_num_synapses = 220
    return suite.run(show_progress=False, skip_stress=True)


def train_navi6(rounds: int = 24) -> NAVI6Engine:
    eng = NAVI6Engine()
    # auto-curriculum: preguntas propias + casos etiquetados
    texts = list(CURRICULUM)
    for i in range(rounds):
        q = texts[i % len(texts)]
        if i % 5 == 4:
            q = eng.ask_self()
        turn = eng.think(q)
        # refuerzo: si diagnosticó concurrencia, subir arista spin_lock
        if turn.internal["detect"]["domain"] == "concurrency":
            eng.dag.add("thread_flood", "cpu_alloc_queue", 0.05, "train-reinforce", "concurrency")
        if i % 3 == 0:
            drive = eng.wsp.codec.to_snn_current(
                eng.wsp.encode(q), eng.snn.config.num_neurons
            )
            for _ in range(8):
                eng.snn.step(drive)
    return eng


def main():
    ap = argparse.ArgumentParser(description="Train NAVI 5 then NAVI 6")
    ap.add_argument("--epochs5", type=int, default=16)
    ap.add_argument("--instances5", type=int, default=3)
    ap.add_argument("--rounds6", type=int, default=20)
    ap.add_argument("--skip5", action="store_true")
    ap.add_argument("--out", default="NAVI_AI_SNN/l3/navi6_weights.bin")
    args = ap.parse_args()

    t0 = time.time()
    report5 = None
    if not args.skip5:
        print("[TRAIN] NAVI 5 peaceful…")
        report5 = train_navi5_short(args.epochs5, args.instances5)
        print("[TRAIN] NAVI 5 KCC", report5["ethics_compliance"]["kcc_compliant"],
              "destroyed", report5["ethics_compliance"]["instances_destroyed"])

    print("[TRAIN] NAVI 6 curriculum…")
    eng = train_navi6(args.rounds6)
    snap = eng.snapshot()
    out = Path(args.out)
    write_bin(out, snap["edges"], snap["snn"]["v_th"], snap["snn"]["tau"])
    write_json_sidecar(out, snap)
    # también copia canónica para el lab
    lab = Path("/tmp/navi6_model")
    lab.mkdir(parents=True, exist_ok=True)
    write_bin(lab / "navi6_weights.bin", snap["edges"], snap["snn"]["v_th"], snap["snn"]["tau"])
    write_json_sidecar(lab / "navi6_weights.bin", snap)
    (lab / "train_report.json").write_text(json.dumps({
        "seconds": round(time.time() - t0, 3),
        "navi5": None if not report5 else {
            "kcc": report5["ethics_compliance"]["kcc_compliant"],
            "destroyed": report5["ethics_compliance"]["instances_destroyed"],
            "epochs": report5["training_summary"]["total_epochs"],
        },
        "navi6": snap["metrics"],
        "snn": snap["snn"],
        "edges": len(snap["edges"]),
        "blob": str(out),
        "blob_bytes": out.stat().st_size,
    }, indent=2, default=str))

    # smoke del tutor
    a = eng.think(CURRICULUM[0])
    b = eng.think(CURRICULUM[1])
    print("[TRAIN] diagnose preview:\n", a.reply[:240], "…")
    print("[TRAIN] counterfactual preview:\n", b.reply[:240], "…")
    print(f"[TRAIN] wrote {out} ({out.stat().st_size} B) in {time.time()-t0:.2f}s")
    print("[TRAIN] fitness", snap["metrics"]["fitness"],
          "grown", snap["snn"]["grown"], "circuits", snap["snn"]["circuits"])


if __name__ == "__main__":
    main()
