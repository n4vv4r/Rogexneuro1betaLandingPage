"""
NAVI 6 — modelo del mundo + energía libre (clásico, discreto).
Cientos de micro-rollouts con ruido: no es un world-model de vídeo ni un LLM.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

import numpy as np


@dataclass
class Scenario:
    id: str
    domain: str
    state0: Dict[str, float]
    dynamics: List[Tuple[str, str, float]]  # src, dst, weight
    options: Dict[str, Dict[str, float]]


class WorldModel:
    def __init__(self, seed: int = 6):
        self.rng = np.random.default_rng(seed)
        self.scenarios: Dict[str, Scenario] = {}
        self.metrics = {"rollouts": 0, "free_energy": 0.0}

    def register(self, sc: Scenario):
        self.scenarios[sc.id] = sc

    def step_state(self, state: Dict[str, float], dyn: List[Tuple[str, str, float]],
                   noise: float = 0.04) -> Dict[str, float]:
        nxt = dict(state)
        for src, dst, w in dyn:
            nxt[dst] = nxt.get(dst, 0.0) + w * state.get(src, 0.0)
        for k in nxt:
            nxt[k] = float(np.clip(nxt[k] + self.rng.normal(0, noise), 0.0, 2.0))
        return nxt

    def rollout(self, scenario_id: str, option: str | None = None,
                steps: int = 8, n: int = 48) -> Dict:
        sc = self.scenarios[scenario_id]
        dyn = list(sc.dynamics)
        if option and option in sc.options:
            for k, dv in sc.options[option].items():
                dyn.append(("__opt__", k, dv))
        surprises = []
        finals = []
        for _ in range(n):
            st = dict(sc.state0)
            if option:
                st["__opt__"] = 1.0
            pred = dict(st)
            for _s in range(steps):
                st = self.step_state(st, dyn)
            # sorpresa: L2 entre predicho lineal y rollout ruidoso
            err = 0.0
            for k, v in st.items():
                err += (v - pred.get(k, 0.0)) ** 2
            surprises.append(err)
            finals.append(st)
        fe = float(np.mean(surprises) + 0.1 * np.var(surprises))
        mean_final = {
            k: float(np.mean([f.get(k, 0.0) for f in finals]))
            for k in finals[0]
        }
        self.metrics["rollouts"] += n
        self.metrics["free_energy"] = fe
        return {
            "scenario": scenario_id,
            "option": option,
            "n": n,
            "free_energy": fe,
            "mean_state": mean_final,
        }

    def compare_options(self, scenario_id: str, options: List[str], n: int = 40) -> List[Dict]:
        ranked = [self.rollout(scenario_id, opt, n=n) for opt in options]
        ranked.sort(key=lambda r: r["free_energy"])
        return ranked


def default_world() -> WorldModel:
    wm = WorldModel()
    wm.register(Scenario(
        id="gpu_threads_ram",
        domain="concurrency",
        state0={
            "thread_flood": 0.85,
            "cpu_alloc_queue": 0.8,
            "spin_lock": 0.7,
            "ram_spike": 0.75,
            "gpu_stall": 0.65,
            "bus_latency": 0.2,
            "cache_incoherence": 0.1,
        },
        dynamics=[
            ("thread_flood", "cpu_alloc_queue", 0.35),
            ("cpu_alloc_queue", "spin_lock", 0.45),
            ("spin_lock", "ram_spike", 0.4),
            ("spin_lock", "gpu_stall", 0.25),
        ],
        options={
            "ring_buffer": {
                "spin_lock": -0.7,
                "ram_spike": -0.65,
                "gpu_stall": -0.35,
            },
            "shared_mem": {
                "cache_incoherence": 0.55,
                "bus_latency": 0.4,
                "ram_spike": -0.15,
            },
            "sample_down": {
                "thread_flood": -0.4,
                "spin_lock": -0.2,
                "ram_spike": -0.15,
            },
        },
    ))
    wm.register(Scenario(
        id="snn_overload",
        domain="snn",
        state0={"high_rate": 0.7, "energy_uj": 0.8, "chaos": 0.3},
        dynamics=[("high_rate", "energy_uj", 0.4), ("high_rate", "chaos", 0.2)],
        options={"vth_up": {"high_rate": -0.45, "energy_uj": -0.3}},
    ))
    return wm
