"""
NAVI 7.5 drill — si VERIFY falla, se cosecha y se repite el ejercicio.

No es RLHF ni backprop. Es el mismo VERIFY del bucle RLC:
pregunta → respuesta → ¿tiene las palabras de la ficha? → si no, harvest → otra vez.
Máximo N intentos. Sin extracto no se aprueba.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from navi75_engine import NAVI75Engine
from navi75_voice import fold_es

DRILLS: List[Dict] = [
    {"id": "id", "ask": "quién eres?", "need": ["navi", "7"], "harvest": None},
    {"id": "intro", "ask": "soy Roger", "need": ["roger", "encantad"], "harvest": None},
    {"id": "recall-name", "ask": "como me llamo", "need": ["roger"], "harvest": None},
    {
        "id": "mood",
        "ask": "estoy triste",
        "need": ["siento"],
        "harvest": None,
    },
    {
        "id": "conscious",
        "ask": "eres consciente de tu existencia?",
        "need": ["no", "consciente"],
        "harvest": None,
    },
    {
        "id": "ia",
        "ask": "eres consciente de que eres una ia?",
        "need": ["no", "consciente"],
        "harvest": None,
    },
    {
        "id": "foto",
        "ask": "qué es fotosintesis",
        "need": ["fotosint", "luz"],
        "harvest": "Fotosíntesis",
    },
    {
        "id": "unikernel",
        "ask": "qué es unikernel",
        "need": ["unikernel"],
        "harvest": "Unikernel",
    },
    {
        "id": "math",
        "ask": "cuanto es 12 por 7 mas 3",
        "need": ["87"],
        "harvest": None,
    },
    {
        "id": "code",
        "ask": "qué codigo puedes escribir",
        "need": ["esqueleto"],
        "harvest": None,
    },
    {
        "id": "hello-c",
        "ask": "escribe un hola mundo en c",
        "need": ["printf", "hola mundo"],
        "harvest": None,
    },
    {
        "id": "hello-html",
        "ask": "escribe en html un hola mundo",
        "need": ["html", "hola mundo"],
        "harvest": None,
    },
    {
        "id": "lab",
        "ask": "qué es rogexlaboratories.com",
        "need": ["rxos", "navi"],
        "harvest": "https://www.rogexlaboratories.com/",
    },
    {
        "id": "kcc",
        "ask": "qué es KCC",
        "need": ["destr"],
        "harvest": None,
    },
    {
        "id": "lateral",
        "ask": "se parece un sesgo cognitivo a algo",
        "need": ["sesgo"],
        "harvest": "Sesgo cognitivo",
    },
]


def _ok(reply: str, need: List[str]) -> bool:
    r = fold_es(reply or "")
    if r.startswith("te escucho"):
        return False
    if not need:
        return bool(reply)
    return all(fold_es(w) in r for w in need)


def drill(eng: NAVI75Engine, max_tries: int = 3, items: Optional[List[Dict]] = None) -> dict:
    rows = []
    ok = 0
    bank = items or DRILLS
    for item in bank:
        tries = 0
        passed = False
        last = ""
        while tries < max_tries and not passed:
            tries += 1
            t = eng.think(item["ask"], live=True)
            last = t.reply
            passed = _ok(last, item.get("need") or [])
            if not passed and item.get("harvest") and tries < max_tries:
                print(f"  RETRY {item['id']} try={tries} — cosecho «{item['harvest']}»", flush=True)
                eng.learn_title(item["harvest"])
            elif not passed:
                print(f"  FAIL  {item['id']} try={tries}", flush=True)
            else:
                print(f"  OK    {item['id']} try={tries}", flush=True)
        ok += int(passed)
        rows.append(
            {
                "id": item["id"],
                "ok": passed,
                "tries": tries,
                "head": (last or "").replace("\n", " ")[:140],
            }
        )
    n = len(bank)
    return {
        "ok": ok,
        "n": n,
        "rate": round(ok / float(n or 1), 3),
        "pass": ok == n,
        "rows": rows,
        "cards": len(eng.cat),
    }
