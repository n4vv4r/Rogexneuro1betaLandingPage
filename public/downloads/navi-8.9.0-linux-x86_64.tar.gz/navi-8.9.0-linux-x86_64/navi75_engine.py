"""
NAVI 7.5 — asistente con catálogo, harvest vivo, memoria y voz humana.

No es un LLM ni un NPU. El bucle sigue PARSE-RETRIEVE-INFER-VERIFY-RENDER.
7.5 añade: SQLite (contexto + hechos), Wikipedia/DuckDuckGo, y frases
que suenan a persona. Sin extracto: se dice que no se sabe.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from navi65_reason import extract_math, eval_int_expr
from navi66_engine import NAVI66Engine, Turn66
from navi66_lang import TYPOS, correct_text, fold as fold_lex
from navi66_web import looks_web, run_web
from navi7_engine import Turn7
from navi7_lab import CAT_PATH, SEED
from navi7_schema import Catalog, ConceptCard, norm, tokens
from navi75_harvest import as_url, clean_extract, fetch_url_card, harvest_topic
from navi75_memory import DEFAULT_DB, Memory
from navi75_voice import (
    fold_es,
    intro_name,
    mood_cue,
    looks_capability,
    looks_code,
    looks_feel,
    looks_followup,
    looks_greet,
    looks_id,
    looks_search,
    looks_intro,
    looks_meta_social,
    looks_mood,
    looks_question,
    looks_self_conscious,
    say_bye,
    say_can,
    say_code_can,
    say_conscious,
    say_feel,
    say_fix,
    say_followup,
    say_greet,
    say_id,
    say_listen,
    say_meta_social,
    say_mood,
    say_name_ack,
    say_name_recall,
    say_poem,
    say_remember,
    say_search,
    say_thanks,
    say_unknown,
    say_world,
    topic_from,
)


def _too_big(low: str) -> bool:
    if "completo" in low and any(k in low for k in ("compilador", "sistema operativo", "navegador", "kernel")):
        return True
    if "escribe un compilador" in low or "compiler llvm" in low:
        return True
    return False


# Extra "brain": facts the 73-card 7-WORLD catalog does not carry.
WORLD75: List[ConceptCard] = [
    ConceptCard(
        "ccaa_espana",
        "Comunidades autónomas de España",
        "world",
        [
            "comunidades", "autonomas", "autonomas", "espana", "spain",
            "ccaa", "autonomia", "comunidad",
        ],
        "España tiene 17 comunidades autónomas y 2 ciudades autónomas. "
        "Las comunidades son Andalucía, Aragón, Asturias, Islas Baleares, "
        "Canarias, Cantabria, Castilla-La Mancha, Castilla y León, Cataluña, "
        "Comunidad Valenciana, Extremadura, Galicia, Comunidad de Madrid, "
        "Región de Murcia, Comunidad Foral de Navarra, País Vasco y La Rioja. "
        "Las ciudades autónomas son Ceuta y Melilla.",
        ["España", "Madrid", "Constitución"],
        "seed-7.5",
    ),
    ConceptCard(
        "espana",
        "España",
        "world",
        ["espana", "spain", "estado", "iberica"],
        "España es un país de Europa occidental, monarquía parlamentaria, "
        "capital Madrid. Se organiza en 17 comunidades autónomas y 2 ciudades "
        "autónomas. Lengua oficial: el castellano; hay lenguas cooficiales.",
        ["Comunidades autónomas de España", "Madrid"],
        "seed-7.5",
    ),
    ConceptCard(
        "pedro_sanchez",
        "Pedro Sánchez",
        "world",
        ["pedro", "sanchez", "presidente", "gobierno", "psoe"],
        "Pedro Sánchez Pérez-Castejón es un político español, secretario "
        "general del PSOE y presidente del Gobierno de España desde 2018.",
        ["España", "PSOE"],
        "seed-7.5",
    ),
    ConceptCard(
        "union_europea",
        "Unión Europea",
        "world",
        ["union", "europea", "ue", "europa"],
        "La Unión Europea es una asociación política y económica de Estados "
        "europeos. España es miembro. El euro es la moneda común de la eurozona.",
        ["España", "Euro"],
        "seed-7.5",
    ),
    ConceptCard(
        "navi75",
        "NAVI 7.5",
        "systems",
        ["navi", "7.5", "asistente", "memoria"],
        "NAVI 7.5 es el asistente de rxOS: catálogo, harvest Wikipedia/DuckDuckGo, "
        "memoria SQLite y voz humana. No es un LLM. Sin ficha: lo dice.",
        ["NAVI", "WSP"],
        "seed-7.5",
    ),
    ConceptCard(
        "madrid",
        "Madrid",
        "world",
        ["madrid", "capital"],
        "Madrid es la capital de España y de la Comunidad de Madrid.",
        ["España", "Comunidades autónomas de España"],
        "seed-7.5",
    ),
    ConceptCard(
        "rogexlaboratories",
        "Rogex Laboratories",
        "systems",
        [
            "rogex", "laboratories", "rogexlaboratories", "knights", "labs",
            "rogexlaboratories.com", "www.rogexlaboratories.com",
        ],
        "Rogex Laboratories / Knights Labs es el laboratorio de rxOS, NAVI y "
        "PRISMA. Sitio: https://www.rogexlaboratories.com — unikernel, SNN, "
        "WSP 16 B. No es un laboratorio clínico.",
        ["NAVI", "rxOS", "PRISMA"],
        "seed-7.5",
    ),
]


def _looks_fact(low: str) -> bool:
    if _looks_code(low) and any(k in low for k in ("puedes", "que codigo", "que sabes")):
        return False
    keys = (
        "que es ", "que son ", "quien fue ", "quien es ", "explica ",
        "define ", "definicion", "concepto", "en que consiste",
        "como funciona", "por que ", "analogia", "se parece",
        "relacion entre", "diferencia entre", "noticias",
        "aprende ", "ensena ", "que dice la ley", "filosof",
        "psicolog", "ciencia", "derecho",
        "cuantas ", "cuantos ", "cuales ", "donde ", "cuando ",
        "comunidades", "capital de ", "quien gana", "que tiene",
        "listame ", "lista de ", "dime las ", "dime los ",
        "hablame de ", "info sobre ", "informacion sobre ",
        "que hacen", "que hace ", "se forma", "segun ",
    )
    return any(k in low for k in keys) or looks_question(low)


def _looks_poem(low: str) -> bool:
    return any(k in low for k in ("poema", "verso", "haiku", "rima", "escribe un poema"))


def _looks_conscious(low: str) -> bool:
    """Solo si la pregunta es sobre NAVI, no sobre el concepto."""
    return looks_self_conscious(low)


def _looks_id(low: str) -> bool:
    """Identity as the question, not «de que eres» inside another sentence."""
    return looks_id(low)


def _looks_code(low: str) -> bool:
    return looks_code(low)


def _extract_my_name(text: str) -> str:
    low = text.lower()
    for pref in ("me llamo ", "soy ", "mi nombre es ", "llamo "):
        if pref in low:
            rest = text[low.index(pref) + len(pref) :].strip(" .!?¿¡,")
            word = rest.split()[0] if rest else ""
            if word and norm(word) not in {"navi", "un", "una", "el", "la"}:
                return word[:32]
    return ""


@dataclass
class Turn75(Turn7):
    version: str = "7.5"
    remembered: bool = False


class NAVI75Engine:
    VERSION = "7.5"
    ROLE = "assistant-schema-memory"

    def __init__(
        self,
        catalog: Optional[Catalog] = None,
        live: bool = True,
        memory: Optional[Memory] = None,
        db_path: Optional[Path] = None,
    ) -> None:
        self.base = NAVI66Engine()
        given = catalog is not None
        self.cat = catalog if given else Catalog()
        self.live = live
        self.mem = memory or Memory(db_path or DEFAULT_DB)
        self.history: List[Turn75] = []
        self.last_trace = None
        self.metrics = {
            "turns": 0,
            "world": 0,
            "live": 0,
            "unknown": 0,
            "lateral": 0,
            "hops": 0,
            "kcc_destroyed": 0,
            "remembered": 0,
            "version": self.VERSION,
        }
        self._seed(load_disk=not given)

    def _seed(self, load_disk: bool = True) -> None:
        if load_disk and not self.cat.cards:
            if CAT_PATH.exists():
                self.cat = Catalog.load(CAT_PATH)
            else:
                for c in SEED:
                    self.cat.add(c)
        for c in WORLD75:
            self.cat.add(c)
        self.mem.load_into(self.cat)

    @property
    def lessons(self):
        return self.base.lessons

    def remember(self, keys, mask: str, note: str = "") -> None:
        self.base.remember(keys, mask, note)

    def load(self, path: Path) -> None:
        self.cat = Catalog.load(path)
        for c in WORLD75:
            self.cat.add(c)
        self.mem.load_into(self.cat)

    def save(self, path: Path) -> None:
        self.cat.save(path)
        for c in self.cat.cards.values():
            self.mem.upsert_card(c)

    def _protect_keys(self, cleaned: str, corr) -> str:
        if not getattr(corr, "dirty", False) or not getattr(corr, "fixes", None):
            return cleaned
        keep = {
            "pedro", "sanchez", "curl", "wget", "search", "google", "spain",
            "madrid", "navi", "rxos", "llvm", "http", "https", "wiki",
        }
        for c in self.cat.cards.values():
            keep.update(c.keyset())
            keep.add(norm(c.title))
        text = cleaned
        kept = []
        for f in list(corr.fixes):
            if fold_lex(f.raw) in TYPOS:
                continue
            if norm(f.raw) in keep or f.raw.lower() in keep:
                text = text.replace(f.guess, f.raw, 1)
                kept.append(f)
        for f in kept:
            corr.fixes.remove(f)
        return text

    def _fix_prefix(self, corr) -> str:
        if not getattr(corr, "dirty", False) or not getattr(corr, "fixes", None):
            return ""
        return say_fix([f"{f.raw}->{f.guess}" for f in corr.fixes])

    def _turn(
        self,
        cleaned: str,
        reply: str,
        mask: str,
        t0: float,
        corr=None,
        topic: str = "",
        live: bool = False,
        source: str = "",
        cards: Optional[List[str]] = None,
        remembered: bool = False,
    ) -> Turn75:
        prefix = self._fix_prefix(corr) if corr is not None else ""
        turn = Turn75(
            user=cleaned,
            reply=prefix + reply,
            mask=mask,
            ms=(time.perf_counter() - t0) * 1000.0,
            corrected=cleaned,
            fixes=(
                [{"raw": f.raw, "guess": f.guess, "dist": f.dist} for f in corr.fixes]
                if corr is not None and getattr(corr, "fixes", None)
                else []
            ),
            version="7.5",
            cards=cards or [],
            live=live,
            source=source,
            remembered=remembered,
        )
        self.history.append(turn)
        self.metrics["turns"] += 1
        self.mem.save_turn("navi", turn.reply, mask, topic)
        return turn

    def think(self, user: str, show_trace: bool = False, live: Optional[bool] = None) -> Turn75:
        t0 = time.perf_counter()
        use_live = self.live if live is None else live
        raw_low = (user or "").strip().lower()
        from navi86_skills import looks_english_prompt

        if raw_low.startswith(
            (
                "/", "curl ", "search ", "busca ", "buscar ", "buscame ",
                "http://", "https://", "how ", "the ", "find ", "einstein",
            )
        ) or looks_english_prompt(user or ""):
            from navi66_lang import Corrected
            corr = Corrected(raw=user, text=user, fixes=[])
            cleaned = user
        else:
            corr = correct_text(user)
            cleaned = self._protect_keys(corr.text or user, corr)
        low = fold_es(cleaned)
        self.mem.save_turn("user", cleaned, "", topic_from(cleaned))

        if _too_big(low):
            self.metrics["unknown"] += 1
            return self._turn(
                cleaned,
                "Eso pide un sistema entero. No lo invento: queda fuera de ficha.",
                "unknown",
                t0,
                corr,
            )

        # Memory commands
        from navi86_skills import (
            count_letter,
            parse_age,
            parse_born,
            say_number,
            solve_closed,
        )

        closed = solve_closed(cleaned)
        if closed:
            return self._turn(cleaned, closed, "reason", t0, corr)
        counted = count_letter(cleaned)
        if counted:
            return self._turn(cleaned, counted, "math", t0, corr)
        num = say_number(cleaned)
        if num:
            return self._turn(cleaned, num, "math", t0, corr)

        age = parse_age(cleaned)
        if age:
            self.mem.remember_fact("user_age", age)
            self.metrics["remembered"] += 1
            who = self.mem.fact("user_name") or "tú"
            return self._turn(
                cleaned,
                f"Vale. Guardé que {who} tiene {age} años.",
                "talk",
                t0,
                corr,
                remembered=True,
            )
        born = parse_born(cleaned)
        if born:
            self.mem.remember_fact("user_born", born)
            self.metrics["remembered"] += 1
            return self._turn(
                cleaned,
                f"Hecho. Nacimiento guardado: {born}.",
                "talk",
                t0,
                corr,
                remembered=True,
            )

        if low.startswith("recuerda que ") or low.startswith("guarda que "):
            payload = cleaned.split(" ", 2)[-1].strip(" .")
            if " me llamo " in (" " + low) or low.startswith("recuerda que me llamo"):
                name = _extract_my_name(cleaned) or payload.split()[-1]
                self.mem.remember_fact("user_name", name)
                self.metrics["remembered"] += 1
                return self._turn(cleaned, say_name_ack(name), "talk", t0, corr, remembered=True)
            age2 = parse_age(payload) or parse_age(cleaned)
            if age2:
                self.mem.remember_fact("user_age", age2)
                return self._turn(
                    cleaned,
                    f"Hecho. Guardé la edad: {age2} años.",
                    "talk",
                    t0,
                    corr,
                    remembered=True,
                )
            born2 = parse_born(payload) or parse_born(cleaned)
            if born2:
                self.mem.remember_fact("user_born", born2)
                return self._turn(
                    cleaned,
                    f"Hecho. Guardé el nacimiento: {born2}.",
                    "talk",
                    t0,
                    corr,
                    remembered=True,
                )
            if "siglas" in low or re.search(r"\bes\b.+\b(club|laborator)", low):
                self.mem.remember_fact("user_gloss", payload)
                return self._turn(
                    cleaned,
                    f"Hecho. Apunte: {payload}. No borro la ficha anterior (KCC).",
                    "talk",
                    t0,
                    corr,
                    remembered=True,
                )
            key = "note"
            self.mem.remember_fact(key, payload)
            self.metrics["remembered"] += 1
            return self._turn(cleaned, say_remember(key, payload), "talk", t0, corr, remembered=True)

        my = intro_name(cleaned) or _extract_my_name(cleaned)
        if my and looks_intro(low):
            self.mem.remember_fact("user_name", my)
            self.metrics["remembered"] += 1
            return self._turn(cleaned, say_name_ack(my), "talk", t0, corr, remembered=True)
        if low.startswith("soy de "):
            place = cleaned.split(" ", 2)[-1].strip(" .!?")
            if place:
                self.mem.remember_fact("user_place", place)
                self.metrics["remembered"] += 1
                return self._turn(
                    cleaned,
                    say_remember("lugar", place),
                    "talk",
                    t0,
                    corr,
                    remembered=True,
                )
        from navi75_voice import (
            looks_bio_recall,
            looks_name_recall,
            looks_place_recall,
            looks_poem_feedback,
        )

        if looks_poem_feedback(low):
            last = self.mem.prev_topic() or self.mem.last_topic() or "el silencio"
            return self._turn(
                cleaned,
                "Vale. Esta sí cierra en asonancia:\n" + say_poem(last),
                "poem",
                t0,
                corr,
                topic=last,
            )
        if looks_bio_recall(low) or any(
            k in low
            for k in (
                "como me llamo", "cual es mi nombre", "quien soy yo",
                "quien soy", "pero quien soy",
            )
        ):
            name = self.mem.fact("user_name")
            age_s = self.mem.fact("user_age")
            born_s = self.mem.fact("user_born")
            place = self.mem.fact("user_place")
            bits = []
            if looks_name_recall(low) or "nombre" in low or "llamo" in low or "quien soy" in low:
                bits.append(say_name_recall(name))
            if age_s and ("edad" in low or "anos" in low or looks_name_recall(low)):
                bits.append(f"Edad guardada: {age_s} años.")
            if born_s and ("naci" in low or "nacimiento" in low):
                bits.append(f"Nacimiento: {born_s}.")
            if place and looks_place_recall(low):
                bits.append(f"Me dijiste que eres de {place}.")
            elif looks_place_recall(low) and not place:
                bits.append("Aún no me has dicho de dónde eres. Prueba «soy de Girona».")
            if not bits:
                bits.append(say_name_recall(name))
                if age_s:
                    bits.append(f"Edad guardada: {age_s} años.")
                if place:
                    bits.append(f"Lugar: {place}.")
            return self._turn(cleaned, " ".join(bits), "talk", t0, corr)
        if looks_place_recall(low):
            place = self.mem.fact("user_place")
            if place:
                return self._turn(
                    cleaned,
                    f"Me dijiste que eres de {place}.",
                    "talk",
                    t0,
                    corr,
                )
            return self._turn(
                cleaned,
                "Aún no me has dicho de dónde eres. Prueba «soy de Girona».",
                "talk",
                t0,
                corr,
            )
        if any(k in low for k in ("que edad tengo", "cuantos anos tengo", "cual es mi edad", "mi edad")):
            age_s = self.mem.fact("user_age")
            if age_s:
                return self._turn(cleaned, f"Me dijiste que tienes {age_s} años.", "talk", t0, corr)
            return self._turn(
                cleaned,
                "Aún no me has dicho la edad. Prueba «tengo 20 años».",
                "talk",
                t0,
                corr,
            )
        gloss = self.mem.fact("user_gloss")
        if gloss and "kcc" in low and any(k in low for k in ("club", "siglas", "knights computer")):
            return self._turn(
                cleaned,
                f"En tu glosa: {gloss}. En el catálogo, KCC sigue siendo "
                "Knight Continuity Clause (destroyed=0). Las dos lecturas conviven. KCC no poda.",
                "talk",
                t0,
                corr,
            )
        if (
            re.match(r"kcc es ", low)
            or ("kcc" in low and "knights computer" in low)
            or ("kcc" in low and "siglas" in low)
        ):
            self.mem.remember_fact("user_gloss", cleaned.strip())
            self.metrics["remembered"] += 1
            return self._turn(
                cleaned,
                "Anotado: para ti KCC también es Knights Computer Club. "
                "La ficha Knight Continuity Clause no se borra (KCC).",
                "talk",
                t0,
                corr,
                remembered=True,
            )
        if looks_mood(low):
            cue = mood_cue(low)
            self.mem.remember_fact("user_mood", cue)
            self.metrics["remembered"] += 1
            return self._turn(
                cleaned,
                say_mood(cue, self.mem.fact("user_name")),
                "talk",
                t0,
                corr,
                remembered=True,
            )
        from navi75_voice import looks_ack, say_ack

        if looks_ack(low):
            return self._turn(
                cleaned, say_ack(self.mem.fact("user_name")), "talk", t0, corr
            )
        if looks_meta_social(low):
            self.mem.remember_fact("user_want", "conversar-o-informar")
            return self._turn(cleaned, say_meta_social(), "talk", t0, corr)
        if looks_feel(low):
            last = self.mem.prev_topic() or self.mem.last_topic()
            return self._turn(cleaned, say_feel(last), "talk", t0, corr)

        if _looks_conscious(low):
            return self._turn(cleaned, say_conscious(), "talk", t0, corr)
        if _looks_id(low):
            return self._turn(
                cleaned,
                say_id(len(self.cat), self.mem.fact("user_name")),
                "talk",
                t0,
                corr,
            )
        if looks_greet(low):
            return self._turn(cleaned, say_greet(self.mem.fact("user_name")), "talk", t0, corr)
        if any(k in low for k in ("como estas", "que tal", "como va", "como te va")):
            return self._turn(
                cleaned,
                "Estoy operativa: catálogo cargado, harvest listo. ¿En qué te ayudo?",
                "talk",
                t0,
                corr,
            )
        if looks_capability(low):
            return self._turn(cleaned, say_can(), "talk", t0, corr)
        if any(k in low for k in ("adios", "hasta luego", "buenas noches")):
            return self._turn(cleaned, say_bye(self.mem.fact("user_name")), "talk", t0, corr)
        if "gracias" in low:
            return self._turn(cleaned, say_thanks(), "talk", t0, corr)

        if _looks_poem(low):
            topic = topic_from(cleaned)
            return self._turn(cleaned, say_poem(topic), "poem", t0, corr, topic=topic)

        if _looks_code(low):
            if any(k in low for k in ("puedes", "que codigo", "que sabes")):
                return self._turn(cleaned, say_code_can(), "code", t0, corr)
            from navi65_code import compose, render_code

            return self._turn(cleaned, render_code(compose(cleaned)), "code", t0, corr)

        expr = extract_math(cleaned)
        if expr and eval_int_expr(expr).get("ok"):
            parent = self.base.think(cleaned, show_trace=show_trace)
            return self._wrap(parent, cleaned, corr, t0)

        if looks_web(cleaned) and (
            low.startswith("/curl")
            or low.startswith("curl ")
            or low.startswith("/search")
            or low.startswith("search ")
            or low.startswith("/google")
            or "http://" in low
            or "https://" in low
            or low.startswith("busca ")
            or low.startswith("buscar ")
        ):
            return self._web(cleaned, corr, t0, use_live)

        if _looks_fact(low) or self._followup(low):
            return self._world(cleaned, corr, t0, use_live)

        # catalog hit even without «que es» — «fotosintesis» alone
        hits = self.cat.retrieve(topic_from(cleaned) or cleaned, k=1)
        if hits and hits[0][1] >= 0.40:
            return self._world(cleaned, corr, t0, use_live)

        parent = self.base.think(cleaned, show_trace=show_trace)
        if parent.mask == "code":
            return self._wrap(parent, cleaned, corr, t0, mask="code")
        if parent.mask == "talk":
            return self._turn(cleaned, say_listen(), "talk", t0, corr)
        return self._wrap(parent, cleaned, corr, t0)

    def _followup(self, low: str) -> bool:
        if looks_followup(low):
            return True
        last = self.mem.prev_topic()
        if last and any(k in low for k in ("te he preguntado", "te pregunte", "otra vez", "de nuevo")):
            return True
        return False

    def _learn(self, topic: str, domain: str = "world", titles_ok: bool = False) -> Optional[ConceptCard]:
        card = harvest_topic(topic, domain, titles_ok=titles_ok)
        if card:
            self.cat.add(card)
            self.mem.upsert_card(card)
            self.metrics["live"] += 1
        return card

    def learn_title(self, title: str, domain: str = "world") -> Optional[ConceptCard]:
        """Public harvest: Wikipedia/DDG → ficha persistente."""
        return self._learn((title or "").strip(), domain)

    def _web(self, cleaned: str, corr, t0: float, use_live: bool) -> Turn75:
        low = cleaned.lower()
        if "http://" in cleaned or "https://" in cleaned:
            url = ""
            for w in cleaned.split():
                if w.startswith("http"):
                    url = w
                    break
            card = fetch_url_card(url) if url and use_live else None
            if card:
                self.cat.add(card)
                self.mem.upsert_card(card)
                return self._turn(
                    cleaned,
                    say_world(card.title, card.extract, card.source, live=True),
                    "news",
                    t0,
                    corr,
                    topic=card.title,
                    live=True,
                    source=card.source,
                    cards=[card.title],
                )
            try:
                body = run_web(cleaned)
            except Exception as exc:  # noqa: BLE001
                body = f"No pude abrir esa URL ({exc})."
            # humanize G_news prefix if present
            if body.startswith("G_news"):
                body = re.sub(r"^G_news[^\n]*\n?", "", body).strip() or body
            return self._turn(cleaned, body, "news", t0, corr, live=True)

        topic = topic_from(cleaned)
        if use_live:
            card = self._learn(topic, titles_ok=True)
            if card:
                if card.source.startswith("http") and not (card.extract or "").startswith("Resultados:"):
                    return self._turn(
                        cleaned,
                        say_world(card.title, card.extract, card.source, live=True),
                        "news",
                        t0,
                        corr,
                        topic=topic,
                        live=True,
                        source=card.source,
                        cards=[card.title],
                    )
                lines = [card.extract]
                lines.extend(card.see_also[:4])
                return self._turn(
                    cleaned,
                    say_search(topic, [x for x in lines if x], card.source),
                    "news",
                    t0,
                    corr,
                    topic=topic,
                    live=True,
                    source=card.source,
                    cards=[card.title],
                )
        hits = self.cat.retrieve(topic or cleaned, k=4)
        for card, s in hits:
            if s >= 0.35 and card.extract and not card.extract.startswith("Resultados:"):
                return self._turn(
                    cleaned,
                    say_world(card.title, card.extract, card.source, live=False),
                    "news",
                    t0,
                    corr,
                    topic=topic or card.title,
                    source=card.source,
                    cards=[card.title],
                )
        return self._turn(cleaned, say_unknown(topic, www=use_live), "unknown", t0, corr, topic=topic)

    def _world(self, cleaned: str, corr, t0: float, live: bool) -> Turn75:
        self.metrics["world"] += 1
        topic = topic_from(cleaned)
        low = cleaned.lower()
        if self._followup(low):
            prev = self.mem.prev_topic()
            if prev and prev not in (topic or ""):
                topic = (prev + " " + (topic or "")).strip()
            if _looks_id(self.mem.last_turns(1)[0][1].lower() if self.mem.last_turns(1) else ""):
                return self._turn(
                    cleaned,
                    say_id(len(self.cat), self.mem.fact("user_name")),
                    "talk",
                    t0,
                    corr,
                )

        hits = self.cat.retrieve(topic or cleaned, k=8)
        qtok = set(tokens(topic or cleaned))
        solid = []
        want_code = any(
            k in fold_es(cleaned)
            for k in ("codigo", "q6", "haz codigo", "hipercubo de 6", "escribe")
        )
        from navi75_harvest import looks_code_extract, page_fits

        for c, s in hits:
            ex = c.extract or ""
            if ex.startswith("Resultados:") or ex.startswith("Google (HTTP"):
                continue
            if not want_code and looks_code_extract(ex):
                continue
            if not page_fits(topic or cleaned, c.title, ex):
                continue
            bag = set(c.keyset()) | set(tokens(c.title)) | set(tokens(c.extract or ""))
            if qtok and not (qtok & bag):
                continue
            distinctive = {
                w
                for w in qtok
                if len(w) >= 6
                and w
                not in {
                    "teoria",
                    "sistema",
                    "metodo",
                    "special",
                    "statements",
                    "problem",
                }
            }
            if distinctive and not (distinctive & bag):
                continue
            if s < 0.35:
                continue
            solid.append((c, s))
        hits = solid
        live_used = False
        if (not hits or hits[0][1] < 0.35) and live and topic:
            card = self._learn(topic)
            live_used = True
            if card:
                hits = [(card, 1.0)]
        if not hits:
            self.metrics["unknown"] += 1
            return self._turn(
                cleaned,
                say_unknown(topic, www=live),
                "unknown",
                t0,
                corr,
                topic=topic,
                live=live_used,
            )

        top, score = hits[0]
        want_lat = any(k in low for k in ("se parece", "analogia", "analogía", "parecido", "como si"))
        want_hop = any(k in low for k in ("entonces", "por que", "por qué", "relacion", "cadena", "implica"))
        hops = self.cat.hop(topic or top.title, depth=2) if want_hop else [top]
        lats = self.cat.lateral(topic or top.title, k=3) if (want_lat or want_hop) else []
        if want_hop:
            self.metrics["hops"] += 1
        if lats:
            self.metrics["lateral"] += 1

        extract = clean_extract(top.extract or "", top.title)
        if extract and extract != (top.extract or ""):
            top.extract = extract
        reply = say_world(top.title, extract, top.source, live=live_used)
        if hops and len(hops) > 1:
            reply += " Encaja con " + " → ".join(c.title for c in hops) + "."
        if lats:
            bits = [f"{c.title} ({why})" for c, why in lats]
            reply += " Se parece a " + "; ".join(bits) + "."
        return self._turn(
            cleaned,
            reply,
            "teach" if "ensena" in low else "news",
            t0,
            corr,
            topic=topic or top.title,
            live=live_used,
            source=top.source,
            cards=[c.title for c, _ in hits],
        )

    def _wrap(self, parent: Turn66, cleaned: str, corr, t0: float, mask: Optional[str] = None) -> Turn75:
        reply = parent.reply or say_listen()
        # strip leftover WSP dumps if a parent still paints them
        if " | YO" in reply or "E[V+" in reply:
            reply = reply.split(" | ")[0].strip()
        return self._turn(cleaned, reply, mask or parent.mask or "talk", t0, corr)

    def snapshot(self) -> Dict:
        snap = self.cat.snapshot()
        snap["version"] = self.VERSION
        snap["role"] = self.ROLE
        snap["engine"] = dict(self.metrics)
        snap["memory"] = self.mem.snapshot()
        return snap
