"""
NAVI 7.5 harvest — Wikipedia + DuckDuckGo + scrape.

Google gbv=1 está muerto (HTTP 0 / redirect HTTPS). Aquí no se inventa:
si la página no da extracto, no hay ficha.
"""

from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import List, Optional, Tuple

from navi66_web import html_text
from navi7_schema import ConceptCard, norm, tokens


# Palabras que aparecen en demasiadas fichas. No bastan solas para VERIFY.
_WEAK_FIT = {
    "viaje", "color", "tiempo", "humanidad", "dispara", "quedan",
    "cuantos", "cuantas", "hacer", "hace", "hizo", "sistema", "teoria",
    "metodo", "mundo", "historia", "anos", "sobre", "arbol", "resto",
    "pregunta", "enunciado", "clasico",
}


def looks_code_extract(extract: str) -> bool:
    """Esqueleto / dry-run. No sirve como definición de un concepto."""
    e = extract or ""
    return any(
        x in e
        for x in (
            "#define ",
            "int main(",
            "static unsigned",
            "--- dry-run ---",
            "fn main(",
            "printf(",
        )
    )


def page_fits(query: str, title: str, extract: str) -> bool:
    """VERIFY: el título/extracto tiene que hablar del tema pedido."""
    qtok = set(tokens(query))
    if not qtok:
        return True
    ttok = set(tokens(title))
    bag = ttok | set(tokens((extract or "")[:280]))
    qn = norm(query)
    tn = norm(title)
    qflat = qn.replace(" ", "")
    tflat = tn.replace(" ", "")
    # rogexlaboratories ≡ Rogex Laboratories
    if qflat and tflat and qflat == tflat:
        return True
    if any(len(w) >= 8 and w in qflat for w in ttok):
        return True
    # «cielo» no es «Cielo extraterrestre»
    if len(qtok) <= 2 and qtok <= ttok and qn != tn:
        extra = {w for w in ttok if w not in qtok and len(w) >= 6}
        if extra:
            return False
    dist = {w for w in qtok if len(w) >= 4}
    if not dist:
        return True
    rare = {w for w in dist if w not in _WEAK_FIT}
    # título sin ningún token del tema: Astroturismo no es «el cielo»
    if (rare or dist) and not ((rare or dist) & ttok) and not (qtok & ttok):
        # un token suelto («cielo») exige el título; dos o más pueden vivir en el extracto
        if len(qtok) <= 1 or not (rare and rare <= bag):
            return False
    hit = (rare or dist) & bag
    if rare:
        if len(rare) >= 2:
            title_hit = rare & ttok
            if len(rare & bag) >= 2 or title_hit:
                return True
        elif hit:
            return True
    elif dist & bag:
        return True
    if qn and (qn in tn or tn in qn):
        return True
    return False

UA = "rxOS-navi75/9.5 (world-lab; +https://www.rogexlaboratories.com)"


def _get(url: str, timeout: float = 10.0) -> Tuple[int, bytes, str]:
    req = urllib.request.Request(
        url,
        headers={"User-Agent": UA, "Accept": "application/json,text/html,*/*"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return int(getattr(resp, "status", 200) or 200), resp.read(96 * 1024), resp.geturl()
    except KeyboardInterrupt:
        raise
    except urllib.error.HTTPError as e:
        raw = e.read(96 * 1024) if e.fp else b""
        return int(e.code), raw, url
    except Exception:
        return 0, b"", url


_NOISE = (
    "login",
    "register",
    "donate",
    "guest",
    "node online",
    "syncing session",
    "javascript",
    "home |",
    "[x]",
    "este sitio requiere",
    "paste donate",
    "nav [",
)


def _is_chrome(s: str) -> bool:
    sl = (s or "").lower()
    if not sl.strip():
        return True
    if sl.strip() in ("login", "register", "home", "donate", "paste"):
        return True
    if "syncing session" in sl or "node online" in sl:
        return True
    hits = sum(1 for nse in _NOISE if nse in sl)
    if hits >= 2:
        return True
    if sl.count("login") + sl.count("register") >= 2 and len(s) < 160:
        return True
    nav = {
        "descargar", "register", "login", "home", "donate", "paste",
        ":::", "nav", "guest",
    }
    words = [w.strip(".:") for w in sl.split() if w.strip(".:")]
    if words and sum(1 for w in words if w in nav) / float(len(words)) >= 0.4:
        return True
    return False


def clean_extract(text: str, title: str = "", n: int = 520) -> str:
    """Quita chrome de navbar / SPA. No inventa frases."""
    t = re.sub(r"\s+", " ", text or "").strip()
    t = re.sub(r"[👤▾]+", " ", t)
    t = re.sub(r"[|•·]+", ". ", t)
    t = re.sub(r"\s+", " ", t).strip()
    parts = re.split(r"(?<=[.!?…])\s+", t) if t else []
    keep: List[str] = []
    blob = parts or ([t] if t else [])
    for s in blob:
        s = s.strip(" .")
        if _is_chrome(s):
            continue
        keep.append(s)
    body = " ".join(keep).strip()
    if not body:
        body = title or ""
    elif title:
        tn = title.lower()
        if tn and tn not in body.lower():
            body = f"{title}. {body}"
    if not body:
        return title or ""
    if len(body) <= n:
        return body
    cut = body[:n]
    return cut.rsplit(".", 1)[0] + "." if "." in cut else cut


def _cut(text: str, n: int = 520) -> str:
    t = (text or "").strip()
    if len(t) <= n:
        return t
    cut = t[:n]
    return cut.rsplit(".", 1)[0] + "." if "." in cut else cut


def wiki_summary(title: str, lang: str = "es") -> Optional[dict]:
    slug = urllib.parse.quote(title.replace(" ", "_"), safe="")
    url = f"https://{lang}.wikipedia.org/api/rest_v1/page/summary/{slug}"
    st, raw, final = _get(url)
    if st != 200 or not raw:
        return None
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except json.JSONDecodeError:
        return None
    extract = (data.get("extract") or "").strip()
    if not extract:
        return None
    return {
        "title": data.get("title") or title,
        "extract": extract,
        "url": data.get("content_urls", {}).get("desktop", {}).get("page") or final,
        "desc": data.get("description") or "",
        "lang": lang,
    }


def wiki_search(query: str, lang: str = "es") -> List[str]:
    q = urllib.parse.quote_plus(query)
    url = (
        f"https://{lang}.wikipedia.org/w/api.php?action=opensearch"
        f"&search={q}&limit=5&namespace=0&format=json"
    )
    st, raw, _ = _get(url)
    if st != 200 or not raw:
        return []
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except json.JSONDecodeError:
        return []
    titles = data[1] if isinstance(data, list) and len(data) > 1 else []
    return [str(t) for t in titles if t]


def _bare_title(title: str) -> str:
    t = (title or "").strip()
    low = t.lower()
    for a in ("el ", "la ", "los ", "las ", "un ", "una ", "the "):
        if low.startswith(a):
            t = t[len(a) :].strip()
            low = t.lower()
            break
    return t


def _official_redirect(want: str) -> bool:
    """La búsqueda abre exactamente el título pedido (aunque wiki redirija)."""
    hits = wiki_search(want, "es") or wiki_search(want, "en")
    if not hits:
        return False
    return norm(hits[0]) == norm(want)


def wiki_card(title: str, domain: str = "world", extra_keys: Optional[List[str]] = None) -> Optional[ConceptCard]:
    want = _bare_title(title) or title
    page = wiki_summary(want, "es") or wiki_summary(want, "en")
    if page and not page_fits(want, page.get("title") or "", page.get("extract") or ""):
        # Viaje astral → Experiencia extracorporal: es la ficha oficial, no un robo.
        if not _official_redirect(want):
            page = None
    if not page:
        hits = wiki_search(want, "es") or wiki_search(title, "es")
        hits = hits or wiki_search(want, "en") or wiki_search(title, "en")
        for hit in hits[:5]:
            cand = wiki_summary(hit, "es") or wiki_summary(hit, "en")
            if cand and (
                page_fits(want, cand.get("title") or "", cand.get("extract") or "")
                or norm(hit) == norm(want)
            ):
                page = cand
                break
    if not page:
        return None
    extract = page.get("extract") or ""
    if norm(page.get("title") or "") != norm(want):
        extract = f"{want} (en Wikipedia: {page.get('title')}). {extract}"
        page["extract"] = extract
    keys = tokens(page["title"]) + tokens(want)
    bag = set(keys) | set(tokens(extract))
    for tok in tokens(title):
        if tok in bag or tok in tokens(want):
            keys.append(tok)
    if extra_keys:
        keys.extend(extra_keys)
    see: List[str] = []
    for m in re.finditer(
        r"\b([A-ZÁÉÍÓÚÑ][\wÁÉÍÓÚÑáéíóúñ]{3,}(?:\s+[A-ZÁÉÍÓÚÑ][\wÁÉÍÓÚÑáéíóúñ]{3,})?)\b",
        page["extract"],
    ):
        name = m.group(1)
        if name.lower() != page["title"].lower() and name not in see:
            see.append(name)
        if len(see) >= 4:
            break
    return ConceptCard(
        id=norm(page["title"]).replace(" ", "_")[:56],
        title=page["title"],
        domain=domain,
        keys=keys,
        extract=_cut(page["extract"]),
        see_also=see,
        source=page["url"],
        fetched_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )


def ddg_instant(query: str) -> Optional[dict]:
    q = urllib.parse.quote_plus(query)
    url = f"https://api.duckduckgo.com/?q={q}&format=json&no_html=1&skip_disambig=1"
    st, raw, _ = _get(url)
    if st != 200 or not raw:
        return None
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except json.JSONDecodeError:
        return None
    abstract = (data.get("AbstractText") or data.get("Abstract") or "").strip()
    heading = (data.get("Heading") or "").strip()
    source = (data.get("AbstractURL") or data.get("AbstractSource") or "").strip()
    related: List[str] = []
    for item in data.get("RelatedTopics") or []:
        if isinstance(item, dict) and item.get("Text"):
            related.append(str(item["Text"]).split(" - ", 1)[0].strip())
        if len(related) >= 5:
            break
    if not abstract and not related:
        return None
    return {
        "heading": heading or query,
        "abstract": abstract,
        "source": source or "https://duckduckgo.com",
        "related": related,
    }


def ddg_lite_hits(query: str) -> List[Tuple[str, str]]:
    """Títulos + URLs de DDG lite (no es Wikipedia)."""
    q = urllib.parse.quote_plus(query)
    st, raw, _ = _get(f"https://lite.duckduckgo.com/lite/?q={q}")
    if st != 200 or not raw:
        return []
    html = raw.decode("utf-8", "replace")
    hits: List[Tuple[str, str]] = []
    for m in re.finditer(
        r'(?is)<a[^>]+href="([^"]+)"[^>]*class="[^"]*result-link[^"]*"[^>]*>(.*?)</a>',
        html,
    ):
        url, title = m.group(1), html_text(m.group(2)).strip()
        if "uddg=" in url:
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            url = (qs.get("uddg") or [url])[0]
        url = urllib.parse.unquote(url)
        if not url.startswith("http") or "duckduckgo.com" in url:
            continue
        if title and (title, url) not in hits:
            hits.append((title, url))
        if len(hits) >= 6:
            break
    if not hits:
        for m in re.finditer(r'(?is)href="(https?://[^"]+)"[^>]*>(.*?)</a>', html):
            url, title = m.group(1), html_text(m.group(2)).strip()
            if "duckduckgo" in url or len(title) < 8:
                continue
            hits.append((title, url))
            if len(hits) >= 6:
                break
    return hits


def ddg_lite_titles(query: str) -> List[str]:
    q = urllib.parse.quote_plus(query)
    st, raw, _ = _get(f"https://lite.duckduckgo.com/lite/?q={q}")
    if st != 200 or not raw:
        return []
    html = raw.decode("utf-8", "replace")
    titles: List[str] = []
    for m in re.finditer(r'(?is)<a[^>]+class="[^"]*result-link[^"]*"[^>]*>(.*?)</a>', html):
        t = html_text(m.group(1)).strip()
        if len(t) >= 4 and t not in titles:
            titles.append(t)
        if len(titles) >= 6:
            break
    if not titles:
        for m in re.finditer(r'(?is)<a[^>]+rel="nofollow"[^>]*>(.*?)</a>', html):
            t = html_text(m.group(1)).strip()
            if len(t) >= 8 and t.lower() not in ("duckduckgo", "settings") and t not in titles:
                titles.append(t)
            if len(titles) >= 6:
                break
    return titles


def ddg_card(query: str, domain: str = "world") -> Optional[ConceptCard]:
    inst = ddg_instant(query)
    titles = ddg_lite_titles(query)
    extract = ""
    see: List[str] = []
    src = "https://duckduckgo.com"
    title = query
    if inst:
        extract = inst["abstract"]
        title = inst["heading"] or query
        src = inst["source"] or src
        see = list(inst["related"][:4])
    if titles:
        see = (see + [t for t in titles if t not in see])[:6]
        if not extract:
            extract = "Resultados: " + " | ".join(titles[:5])
    if not extract:
        return None
    return ConceptCard(
        id="ddg_" + norm(query).replace(" ", "_")[:48],
        title=title[:80],
        domain=domain,
        keys=tokens(query) + tokens(title) + tokens(" ".join(see[:3])),
        extract=_cut(extract),
        see_also=see[:4],
        source=src,
        fetched_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )


def fetch_url_card(url: str, domain: str = "world") -> Optional[ConceptCard]:
    candidates = [url]
    if url.startswith("https://") and "://www." not in url:
        candidates.append(url.replace("https://", "https://www.", 1))
    if url.startswith("https://www."):
        candidates.append(url.replace("https://www.", "https://", 1))
    raw = b""
    final = url
    st = 0
    for cand in candidates:
        st, raw, final = _get(cand)
        if st == 200 and raw:
            break
    if st != 200 or not raw:
        return None
    html = raw.decode("utf-8", "replace")
    title = ""
    m = re.search(r"(?is)<title[^>]*>(.*?)</title>", html)
    if m:
        title = html_text(m.group(1)).strip()
    desc = ""
    for prop in ("og:description", "description", "twitter:description"):
        dm = re.search(
            rf'(?is)<meta[^>]+(?:name|property)=["\']{re.escape(prop)}["\'][^>]+content=["\']([^"\']+)',
            html,
        )
        if not dm:
            dm = re.search(
                rf'(?is)<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:name|property)=["\']{re.escape(prop)}["\']',
                html,
            )
        if dm:
            desc = html_text(dm.group(1)).strip()
            if desc:
                break
    text = html_text(html)
    if len(text) < 20 and not title and not desc:
        return None
    title = title or (text[:80].split(".")[0].strip() or final)
    body = desc or text or title
    extract = clean_extract(body, title)
    return ConceptCard(
        id="url_" + norm(final)[-48:].replace(" ", "_"),
        title=title[:80],
        domain=domain,
        keys=tokens(title) + tokens(final) + tokens(extract)[:12],
        extract=_cut(extract or title),
        source=final,
        fetched_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )


_HOST = re.compile(
    r"(?:https?://)?(?:www\.)?[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:/[^\s]*)?",
    re.I,
)


def as_url(topic: str) -> Optional[str]:
    """If the topic is a host or URL, return an https:// URL."""
    t = (topic or "").strip()
    if not t:
        return None
    if t.startswith("http://") or t.startswith("https://"):
        return t.split()[0]
    m = _HOST.search(t)
    if not m:
        return None
    raw = m.group(0)
    tlds = (
        ".com", ".org", ".net", ".io", ".es", ".dev", ".club", ".app",
        ".xyz", ".info", ".edu", ".me", ".gov", ".mil",
    )
    if any(s in raw.lower() for s in tlds):
        if not raw.lower().startswith("http"):
            raw = "https://" + raw
        return raw
    return None


_HINTS = (
    ("sudar", "Sudoración"),
    ("sudan", "Sudoración"),
    ("transpir", "Sudoración"),
    ("cuerdas", "Teoría de cuerdas"),
    ("teoria m", "Teoría M"),
    ("string theory", "String theory"),
    ("capitalismo", "Capitalismo"),
    ("neuromorf", "Neuromorphic computing"),
    ("neuromorph", "Neuromorphic computing"),
    ("viaje astral", "Viaje astral"),
    ("color es el cielo", "Dispersión de Rayleigh"),
    ("color del cielo", "Dispersión de Rayleigh"),
    ("el cielo", "Cielo"),
    ("hipercubo", "Hipercubo"),
    ("humanidad a jesus", "Crucifixión de Jesús"),
    ("le hizo la humanidad", "Crucifixión de Jesús"),
)


def harvest_topic(topic: str, domain: str = "world", titles_ok: bool = False) -> Optional[ConceptCard]:
    """URL propia → scrape (nunca DDG). Si no, wiki. DDG abstract sí; títulos solo si titles_ok."""
    t = (topic or "").strip()
    for pref in (
        "/search ", "/curl ", "search ", "curl ",
        "busca sobre ", "buscar sobre ", "buscame sobre ", "buscame ",
        "busca ", "buscar ",
    ):
        if t.lower().startswith(pref):
            t = t[len(pref):].strip()
    if not t:
        return None
    url = as_url(t)
    if url:
        return fetch_url_card(url, domain)
    low = t.lower()
    for needle, hint in _HINTS:
        if needle in low:
            card = wiki_card(hint, domain, extra_keys=tokens(t))
            if card:
                return card
    card = wiki_card(t, domain)
    if card:
        return card
    ddg = ddg_card(t, domain)
    if ddg and ddg.extract and not (ddg.extract or "").startswith("Resultados:"):
        return ddg
    # más red que Wikipedia: abrir el primer resultado DDG que verifique
    for title, href in ddg_lite_hits(t):
        if "wikipedia.org" in href:
            w = wiki_card(title, domain)
            if w:
                return w
            continue
        scraped = fetch_url_card(href, domain)
        if scraped and scraped.extract and page_fits(t, scraped.title, scraped.extract):
            return scraped
    if ddg and (ddg.extract or "").startswith("Resultados:"):
        for see in ddg.see_also:
            w = wiki_card(see, domain)
            if w:
                return w
        return ddg if titles_ok else None
    return ddg
