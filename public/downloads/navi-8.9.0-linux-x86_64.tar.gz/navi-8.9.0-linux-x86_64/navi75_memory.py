"""
NAVI 7.5 — memoria persistente (SQLite).

Tablas: cards (fichas), turns (conversación), facts (nombre, temas).
KCC: las fichas no se borran. Los turnos se recortan por antigüedad,
no se destruyen conceptos.
"""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from navi7_schema import ConceptCard, Catalog, norm, tokens


DEFAULT_DB = Path("lab/navi75/memory.db")


class Memory:
    """SQLite: contexto + hechos + fichas cosechadas."""

    def __init__(self, path: Optional[Path] = None) -> None:
        self.path = Path(path) if path else DEFAULT_DB
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.cx = sqlite3.connect(str(self.path))
        self.cx.row_factory = sqlite3.Row
        self._init()

    def _init(self) -> None:
        self.cx.executescript(
            """
            CREATE TABLE IF NOT EXISTS cards (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                domain TEXT,
                keys TEXT,
                extract TEXT,
                see_also TEXT,
                source TEXT,
                fetched_at TEXT,
                hits INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS turns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                role TEXT NOT NULL,
                text TEXT NOT NULL,
                mask TEXT,
                topic TEXT
            );
            CREATE TABLE IF NOT EXISTS facts (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated TEXT NOT NULL
            );
            """
        )
        self.cx.commit()

    def close(self) -> None:
        try:
            self.cx.close()
        except sqlite3.Error:
            pass

    def remember_fact(self, key: str, value: str) -> None:
        k = (key or "").strip().lower()
        v = (value or "").strip()
        if not k or not v:
            return
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.cx.execute(
            "INSERT INTO facts(key,value,updated) VALUES(?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated=excluded.updated",
            (k, v, now),
        )
        self.cx.commit()

    def fact(self, key: str) -> str:
        row = self.cx.execute(
            "SELECT value FROM facts WHERE key=?", ((key or "").strip().lower(),)
        ).fetchone()
        return (row["value"] if row else "") or ""

    def facts(self) -> Dict[str, str]:
        out: Dict[str, str] = {}
        for row in self.cx.execute("SELECT key, value FROM facts"):
            out[row["key"]] = row["value"]
        return out

    def save_turn(self, role: str, text: str, mask: str = "", topic: str = "") -> None:
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.cx.execute(
            "INSERT INTO turns(ts,role,text,mask,topic) VALUES(?,?,?,?,?)",
            (now, role, text or "", mask or "", topic or ""),
        )
        # keep last 400 turns (conversation, not concepts)
        self.cx.execute(
            "DELETE FROM turns WHERE id NOT IN (SELECT id FROM turns ORDER BY id DESC LIMIT 400)"
        )
        self.cx.commit()

    def last_turns(self, n: int = 6) -> List[Tuple[str, str, str]]:
        rows = self.cx.execute(
            "SELECT role, text, topic FROM turns ORDER BY id DESC LIMIT ?", (max(1, n),)
        ).fetchall()
        return [(r["role"], r["text"], r["topic"] or "") for r in reversed(rows)]

    def last_topic(self) -> str:
        row = self.cx.execute(
            "SELECT topic FROM turns WHERE topic != '' ORDER BY id DESC LIMIT 1"
        ).fetchone()
        return (row["topic"] if row else "") or ""

    def prev_topic(self) -> str:
        """Tema anterior al turno actual (el think() ya guardó el de ahora)."""
        rows = self.cx.execute(
            "SELECT topic FROM turns WHERE topic != '' ORDER BY id DESC LIMIT 6"
        ).fetchall()
        seen = []
        for row in rows:
            t = (row["topic"] or "").strip()
            if not t:
                continue
            if t not in seen:
                seen.append(t)
            if len(seen) >= 2:
                return seen[1]
        return ""

    def upsert_card(self, card: ConceptCard) -> None:
        cid = card.id or norm(card.title).replace(" ", "_")
        card.id = cid
        now = card.fetched_at or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.cx.execute(
            "INSERT INTO cards(id,title,domain,keys,extract,see_also,source,fetched_at,hits) "
            "VALUES(?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET "
            "extract=CASE WHEN length(excluded.extract) > length(cards.extract) "
            "THEN excluded.extract ELSE cards.extract END, "
            "keys=excluded.keys, see_also=excluded.see_also, "
            "source=CASE WHEN cards.source='seed' THEN excluded.source ELSE cards.source END, "
            "hits=cards.hits+1",
            (
                cid,
                card.title,
                card.domain,
                json.dumps(card.keys, ensure_ascii=False),
                card.extract,
                json.dumps(card.see_also, ensure_ascii=False),
                card.source,
                now,
                card.hits,
            ),
        )
        self.cx.commit()

    def load_into(self, cat: Catalog) -> int:
        n = 0
        for row in self.cx.execute("SELECT * FROM cards"):
            try:
                keys = json.loads(row["keys"] or "[]")
            except json.JSONDecodeError:
                keys = tokens(row["keys"] or "")
            try:
                see = json.loads(row["see_also"] or "[]")
            except json.JSONDecodeError:
                see = []
            cat.add(
                ConceptCard(
                    id=row["id"],
                    title=row["title"],
                    domain=row["domain"] or "world",
                    keys=list(keys),
                    extract=row["extract"] or "",
                    see_also=list(see),
                    source=row["source"] or "memory",
                    fetched_at=row["fetched_at"] or "",
                    hits=int(row["hits"] or 0),
                )
            )
            n += 1
        return n

    def snapshot(self) -> Dict:
        nc = self.cx.execute("SELECT COUNT(*) c FROM cards").fetchone()["c"]
        nt = self.cx.execute("SELECT COUNT(*) c FROM turns").fetchone()["c"]
        nf = self.cx.execute("SELECT COUNT(*) c FROM facts").fetchone()["c"]
        return {
            "path": str(self.path),
            "cards": int(nc),
            "turns": int(nt),
            "facts": int(nf),
            "user_name": self.fact("user_name"),
        }
