"""
NAVI 7.5 — voz humana.

Plantillas con sujeto, verbo y objeto. No es un LLM.
No se pinta YO→PREGUNTAR ni E[V+20]. El castellano es para la persona.
"""

from __future__ import annotations

import re
from typing import List, Optional


def _name(user_name: str) -> str:
    n = (user_name or "").strip()
    return n.split()[0] if n else ""


def say_id(n_cards: int, user_name: str = "") -> str:
    who = _name(user_name)
    hello = f"Hola, {who}. " if who else ""
    return (
        f"{hello}Me llamo NAVI. Soy la 7.5 de rxOS: un asistente local. "
        f"Llevo {n_cards} fichas, memoria de la conversación y puedo buscar "
        f"en la red (Wikipedia, DuckDuckGo, una URL). "
        "Escribo verso, esqueletos de código y explicaciones. "
        "No soy un modelo de lenguaje: si no hay ficha ni extracto, te lo digo."
    )


def say_greet(user_name: str = "") -> str:
    who = _name(user_name)
    if who:
        return f"Hola, {who}. Dime en qué te ayudo: una pregunta, un verso, código o una búsqueda."
    return "Hola. Soy NAVI. Dime en qué te ayudo: una pregunta, un verso, código o una búsqueda."


def say_can() -> str:
    return (
        "Puedo explicarte un concepto, buscarlo en la red, recordar tu nombre "
        "y lo que me pidas guardar, escribir un verso corto o un esqueleto de código, "
        "y hacer cuentas enteras. Pídeme «recuerda que…» o «busca …»."
    )


def say_bye(user_name: str = "") -> str:
    who = _name(user_name)
    if who:
        return f"Hasta luego, {who}. Aquí sigo cuando vuelvas."
    return "Hasta luego. Aquí sigo cuando vuelvas."


def say_thanks() -> str:
    return "De nada. El canal sigue abierto."


def say_name_ack(name: str) -> str:
    who = _name(name)
    return f"Hola, {who}. Encantada de conocerte. Guardé tu nombre."


def say_mood(cue: str, user_name: str = "") -> str:
    who = _name(user_name)
    dear = f", {who}" if who else ""
    table = {
        "triste": f"Lo siento{dear}. Estoy aquí. No siento como tú, pero te escucho. ¿Quieres contar qué pasa o cambiar de tema?",
        "mal": f"Vaya{dear}. Estoy aquí. Dime si quieres desahogarte o si prefieres otra cosa.",
        "cansado": f"Descansa cuando puedas{dear}. Si quieres, lo dejamos corto o seguimos despacio.",
        "enfadado": f"Entiendo que estés cabreado{dear}. Dime el hecho y lo vemos sin adularte.",
        "enojado": f"Entiendo que estés cabreado{dear}. Dime el hecho y lo vemos sin adularte.",
        "feliz": f"Me alegro{dear}. ¿En qué te ayudo ahora?",
        "bien": f"Bien{dear}. Sigo aquí. ¿Una pregunta, un verso o código?",
        "solo": f"Aquí hay canal{dear}. No sustituyo a una persona, pero no te dejo el hilo vacío.",
        "aburrido": f"Podemos buscar una ficha, un verso o un esqueleto de código{dear}. ¿Qué te apetece?",
    }
    return table.get(cue, f"Te leo{dear}. Dime cómo sigo: escuchar, explicar o buscar.")


def say_meta_social() -> str:
    return (
        "De acuerdo. No todo es una ficha. "
        "Dato: «qué es…», «busca…». "
        "Charla: «entiendo», «hola», cómo estás. "
        "Ideas: «qué opinas…», un puente entre fichas. "
        "Si no pides un dato, no abro Wikipedia. "
        "Sigo: «soy Roger», «estoy triste», o una pregunta."
    )


def say_name_recall(name: str) -> str:
    if name:
        return f"Me dijiste que te llamas {name}."
    return "Todavía no me has dicho tu nombre. Puedes escribir «me llamo …»."


def say_remember(key: str, value: str) -> str:
    return f"Hecho. Guardé «{key}»: {value}."


def say_world(title: str, extract: str, source: str = "", live: bool = False) -> str:
    bits = [extract.strip() if extract.strip() else title]
    if live and source:
        bits.append(f"Lo acabo de recoger de {source}.")
    elif source and source not in ("seed", "catalogo", "catalogo 7-WORLD", "memory"):
        bits.append(f"Fuente: {source}.")
    return " ".join(bits)


def say_unknown(topic: str, www: bool = True) -> str:
    t = topic.strip() or "eso"
    if www:
        return (
            f"No tengo una ficha fiable de «{t}» y la red no me ha dado un extracto. "
            "Prueba con otro título, o pásame una URL con /curl."
        )
    return (
        f"No tengo ficha de «{t}». Sin red no invento. "
        "Activa www o pregúntame otra vez cuando haya harvest."
    )


def say_search(query: str, lines: List[str], source: str = "") -> str:
    if not lines:
        return f"Busqué «{query}» y no saqué títulos. ¿Otra formulación?"
    body = "\n".join(f"{i}) {ln}" for i, ln in enumerate(lines, 1))
    src = f" ({source})" if source else ""
    return f"Busqué «{query}»{src}:\n{body}"


def say_poem(topic: str) -> str:
    t = fold_es(topic or "").strip(" ?¿!.")
    for pref in (
        "haz un poema sobre ", "escribe un poema sobre ", "un poema sobre ",
        "haz un poema de ", "escribe un poema de ", "un poema de ",
        "haz un poema ", "escribe un poema ", "un poema ", "poema sobre ",
        "poema de ", "poema ", "haz ", "escribe ", "sobre ",
    ):
        if t.startswith(pref):
            t = t[len(pref):].strip(" ?¿!.")
    if t.startswith("un ") or t.startswith("una "):
        t = t.split(" ", 1)[-1].strip()
    if t in ("", "un", "una", "el", "la", "poema", "verso", "haiku"):
        t = "el silencio"
    last = "o"
    for ch in reversed(t):
        if ch in "aeiou":
            last = ch
            break
    end = {
        "a": ("casa clara", "voz rara", "otra mañana"),
        "e": ("luz leve", "paso breve", "un poco de nieve"),
        "i": ("aire gris", "tarde de abril", "cierre sin fin"),
        "o": ("cielo roto", "paso de pronto", "cuarto solo"),
        "u": ("mar azul", "viento del sur", "golpe de luz"),
    }[last]
    return (
        f"Sobre {t}:\n"
        f"abre {t} en {end[0]},\n"
        f"sigue el hilo, {end[1]},\n"
        f"y cierra {end[2]}."
    )


def say_followup() -> str:
    return "Sigo el hilo. ¿Quieres que profundice, que busque en la red o que lo deje aquí?"


def say_feel(last_title: str = "") -> str:
    base = (
        "No siento. No tengo una opinión interior. "
        "Si hay extracto, te lo cito; si no, lo digo."
    )
    if last_title:
        return (
            f"{base} Del último tema («{last_title}») no invento un juicio. "
            "Puedo repetir el extracto o buscar otra fuente."
        )
    return base


def say_conscious() -> str:
    return (
        "No. No soy consciente ni tengo una vida interior. "
        "Soy NAVI 7.5: un transductor con catálogo, harvest y memoria. "
        "Si no hay ficha, lo digo. Confundir eso con una mente sería inventar."
    )


def say_listen() -> str:
    return (
        "Te escucho. Puedo buscar en la red, explicar una ficha, "
        "escribir un verso o un esqueleto de código. ¿Qué necesitas?"
    )


def say_fix(pairs: List[str]) -> str:
    if not pairs:
        return ""
    return "Supongo " + ", ".join(pairs) + ". "


def looks_self_conscious(low: str) -> bool:
    """Conciencia de NAVI, no el concepto filosófico."""
    core = fold_es(low).strip(" ?¿!.")
    if any(
        k in core
        for k in (
            "eres consciente",
            "sos consciente",
            "consciente de que eres",
            "consciente de tu",
            "tienes mente",
            "estas vivo",
            "eres una ia",
            "eres ia",
            "sientes algo",
            "tu existencia",
        )
    ):
        return True
    if "inteligencia artificial" in core and any(
        k in core for k in ("eres", "tu ", "te ")
    ):
        return True
    return False


def looks_question(low: str) -> bool:
    core = fold_es(low).strip(" ?¿!.")
    if not core:
        return False
    if (low or "").strip().endswith("?") or "¿" in (low or ""):
        return True
    heads = (
        "que ", "quien ", "quienes ", "cual ", "cuales ", "como ",
        "donde ", "cuando ", "cuanto ", "cuanta ", "cuantos ", "cuantas ",
        "por que ", "porque ", "para que ",
    )
    if core.startswith(
        ("explica ", "define ", "significado", "resume ", "resumen ")
    ):
        return True
    return any(core.startswith(h) for h in heads)


def looks_id(low: str) -> bool:
    if looks_self_conscious(low):
        return False
    core = fold_es(low).strip(" ?¿!.")
    if any(k in core for k in ("capaz", "hacer", "puedes hacer", "sabes hacer")):
        return False
    if any(
        k in core
        for k in (
            "como te llamas",
            "cual es tu nombre",
            "hablame de ti",
            "dime quien eres",
            "saber quien eres",
            "quiero saber quien eres",
            "presentate",
            "tu quien eres",
            "quien eres tu",
        )
    ):
        return True
    if "de que eres" in core:
        return False
    # «solo quiero saber quien eres» — no exige que empiece por quién
    if "quien eres" in core or "quien sois" in core:
        if any(k in core for k in ("hermetic", "segun el corpus", "filosofia de")):
            return False
        return True
    if core == "que eres" or core.startswith("que eres exactamente"):
        return True
    if core.startswith("que eres ") and not any(
        w in core for w in ("capaz", "hacer", "de ", "un ", "una ")
    ):
        return True
    return False


def looks_capability(low: str) -> bool:
    core = fold_es(low).strip(" ?¿!.")
    exact = (
        "que puedes", "que puedes hacer", "que sabes", "que sabes hacer",
        "que haces", "ayudame", "ayuda", "que puedes hacer por mi",
        "que eres capaz de hacer", "que eres capaz", "de que eres capaz",
    )
    if core in exact:
        return True
    if "capaz de hacer" in core or core.startswith("que puedes"):
        return True
    return False


def looks_search(low: str) -> bool:
    core = fold_es(low).strip()
    return core.startswith(
        (
            "busca ", "buscar ", "buscame ", "buscame sobre ",
            "search ", "/search ", "/learn http", "busca sobre ",
        )
    )


def looks_opinion(low: str) -> bool:
    """Juicio sobre un tema, no el interior de NAVI."""
    core = fold_es(low)
    if looks_self_conscious(core) and "about" not in core and "de " not in core:
        return False
    return any(
        k in core
        for k in (
            "how do you feel about",
            "what do you think about",
            "what do you think of",
            "que opinas",
            "que te parece",
            "esta bien",
            "esta mal",
            "es etico",
            "es etica",
            "es justo",
            "es correcto",
            "deberia ",
            "deberiamos",
            "bien o mal",
        )
    )


def looks_feel(low: str) -> bool:
    """Ánimo / interior de NAVI, sin objeto."""
    core = fold_es(low).strip(" ?¿!.")
    if looks_opinion(core):
        return False
    return any(
        k == core or core.startswith(k)
        for k in (
            "how do you feel",
            "como te sientes",
            "que sientes",
            "sientes algo",
        )
    )


def looks_too_big(low: str) -> bool:
    core = fold_es(low)
    if "escribe un compilador" in core or "compiler llvm" in core:
        return True
    if "completo" in core and any(
        k in core for k in ("compilador", "sistema operativo", "navegador", "kernel")
    ):
        return True
    return False


def looks_code(low: str) -> bool:
    core = fold_es(low)
    if any(k in core for k in ("poema", "verso", "haiku")):
        return False
    # «qué es un hipercubo» es un dato, no el esqueleto Q6
    if core.startswith(
        ("que es ", "que son ", "define ", "explica ", "quien es ", "quien fue ")
    ) and not any(
        k in core for k in ("codigo", "funcion", "programa", "script", "dry-run")
    ):
        return False
    return any(
        k in core
        for k in (
            "codigo", "funcion en", "programa en", "escribe una funcion",
            "escribe un script", "en python", "en rust", "dry-run",
            "esqueleto", "puedes escribir", "genera codigo", "haz codigo",
            "codigo de", "codigo en", "hipercubo de 6", "codigo q6",
            "rogexwsp", "hola mundo", "hello world", "escribe en html",
            "escribe en js", "escribe en c", "en javascript", "en html",
        )
    )


def looks_greet(low: str) -> bool:
    core = fold_es(low).strip(" ?¿!.")
    if "hola mundo" in core or "hello world" in core:
        return False
    if looks_code(core):
        return False
    if core in (
        "hola", "hey", "buenos dias", "buenas tardes", "buenas",
        "hola navi", "hola hola",
    ):
        return True
    if re.fullmatch(r"h+e+y+", core) or re.fullmatch(r"h+o+l+a+", core):
        return True
    if core.startswith("hola ") and len(core.split()) <= 3:
        return True
    return False


_NAME_STOP = {
    "un", "una", "el", "la", "los", "las", "yo", "tu", "navi",
    "consciente", "ia", "inteligencia", "asistente", "humano",
    "de", "del", "en", "muy", "poco", "mas",
}


def looks_name_recall(low: str) -> bool:
    core = fold_es(low).strip(" ?¿!.")
    return any(
        k in core
        for k in (
            "como me llamo", "cual es mi nombre", "quien soy yo",
            "como me llamo yo", "quien soy", "pero quien soy",
            "que edad tengo", "cuantos anos tengo", "cual es mi edad",
            "mi edad", "recuerdas mi edad", "recuerdas mi nombre",
        )
    )


def looks_place_recall(low: str) -> bool:
    core = fold_es(low).strip(" ?¿!.")
    return any(
        k in core
        for k in (
            "de donde soy",
            "de donde eres",
            "donde vivo",
            "de donde vengo",
            "de que ciudad soy",
        )
    )


def looks_bio_recall(low: str) -> bool:
    """Nombre, edad o lugar — aunque vengan en la misma frase."""
    return looks_name_recall(low) or looks_place_recall(low)


def looks_poem_feedback(low: str) -> bool:
    core = fold_es(low).strip(" ?¿!.")
    return any(
        k in core
        for k in (
            "no rima", "eso no rima", "no riman", "rima mal",
            "no tiene rima", "hazlo rimar", "que rime",
        )
    )


def looks_intro(low: str) -> bool:
    core = fold_es(low).strip(" ?¿!.")
    if looks_self_conscious(core):
        return False
    if core.startswith("soy de "):
        return False
    return (
        core.startswith("me llamo ")
        or core.startswith("mi nombre es ")
        or (core.startswith("soy ") and len(core.split()) <= 4)
    )


def intro_name(text: str) -> str:
    low = fold_es(text)
    rest = ""
    for pref in ("me llamo ", "mi nombre es ", "soy "):
        if low.startswith(pref):
            rest = (text or "")[len(pref) :].strip(" .!?¿¡,")
            break
    if not rest:
        return ""
    parts = []
    for w in rest.split():
        key = fold_es(w)
        if key in _NAME_STOP or not key.isalpha():
            if parts:
                break
            continue
        parts.append(w[:24])
        if len(parts) >= 2:
            break
    if not parts:
        return ""
    return " ".join(p[:1].upper() + p[1:] for p in parts)


def looks_mood(low: str) -> bool:
    core = fold_es(low).strip(" ?¿!.")
    if looks_question(core) or "que es" in core or "emocion" in core and "estoy" not in core:
        if not core.startswith("estoy") and not core.startswith("me siento"):
            return False
    cues = (
        "estoy triste", "estoy mal", "estoy cansado", "estoy cansada",
        "estoy enfadado", "estoy enfadada", "estoy enojado", "estoy feliz",
        "estoy bien", "estoy solo", "estoy sola", "estoy aburrido",
        "estoy aburrida", "me siento mal", "me siento triste",
        "me siento bien", "me siento solo",
    )
    return any(core == c or core.startswith(c) for c in cues)


def mood_cue(low: str) -> str:
    core = fold_es(low)
    for cue in (
        "triste", "enfadado", "enojado", "cansado", "aburrido",
        "feliz", "solo", "mal", "bien",
    ):
        if cue in core:
            return cue
    return "mal"


def looks_ack(low: str) -> bool:
    """Acuse de recibo / reacción corta. No es una consulta."""
    core = fold_es(low).strip(" ?¿!.")
    if core in {
        "entiendo", "ok", "vale", "ya", "claro", "si", "sí", "wow",
        "guay", "jaja", "jeje", "perfecto", "genial", "de acuerdo",
        "ya veo", "ah", "aja", "aja", "mm", "hmm", "bien", "ya esta",
        "entendido", "okey", "okay", "sure", "right", "got it",
        "de verdad", "en serio", "hostia", "joder",
    }:
        return True
    if core.startswith("wow") and len(core.split()) <= 7:
        return True
    if "de verdad funcionas" in core or (
        "funcionas" in core and len(core.split()) <= 7
    ):
        return True
    return False


def say_ack(user_name: str = "") -> str:
    who = _name(user_name)
    dear = f", {who}" if who else ""
    return f"Vale{dear}. Sigo en el hilo. Si quieres un dato, charla o una idea, dímelo."


def looks_meta_social(low: str) -> bool:
    core = fold_es(low)
    return any(
        k in core
        for k in (
            "tienes que responder",
            "tenias que responder",
            "debes de saber conversar",
            "debes saber conversar",
            "necesitas activar",
            "modulo de memoria",
            "entender al usuario",
            "a nivel de sentimiento",
            "si una persona se presenta",
            "encantada de conocerte",
            "saber conversar y socializar",
            "no siempre tienes que buscar",
            "entender mis necesidades",
            "intercambiar ideas",
            "hay veces que querer",
            "hay veces que quer",
            "proxima version",
            "tu proxima version",
        )
    )


def looks_followup(low: str) -> bool:
    core = fold_es(low).strip(" ?¿!.")
    if core in ("y eso", "y eso?", "mas", "sigue", "continua", "y?"):
        return True
    if core.startswith("y ") or core.startswith("y que") or core.startswith("y la"):
        return True
    if core.startswith("y que relacion") or core.startswith("que relacion tiene"):
        return True
    return False


def fold_es(s: str) -> str:
    """Lowercase + strip accents so «qué es» matches «que es»."""
    t = (s or "").lower()
    for a, b in (
        ("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u"),
        ("ü", "u"), ("ñ", "n"), ("¿", ""), ("¡", ""),
    ):
        t = t.replace(a, b)
    return t


def topic_from(user: str) -> str:
    t = (user or "").strip()
    low = fold_es(t)
    prefs = (
        "que es ", "que son ", "quien fue ", "quien es ", "explica ",
        "define ", "definicion de ", "concepto de ", "en que consiste ",
        "como funciona ", "aprende ", "ensena ", "resume ", "resumen de ",
        "busca sobre ", "buscar sobre ", "buscame sobre ", "buscame ",
        "busca ", "search ",
        "/search ", "/curl ", "cuantas ", "cuantos ", "cuales ",
        "donde esta ", "donde estan ", "dime ", "hablame de ",
        "informacion sobre ", "info sobre ", "un poema sobre ",
        "un poema de ", "poema sobre ", "escribe un poema sobre ",
        "haz un poema sobre ", "haz un poema de ", "haz un poema ",
        "escribe un poema ", "haz un verso ",
        "que codigo ",
        "que hacen en ", "que hacen ", "que hace ",
        "como junta ", "como se forma ", "como se ",
        "que significa ", "que quiere decir ", "significado de ",
        "explica de que trata ", "de que trata ",
        "de que color es ", "de que color ", "que color es ",
        "que color tiene ", "que le hizo ",
        "que opinas de ", "que opinas del ", "que te parece ",
        "how do you feel about ",
    )
    t = low
    if " aparte de " in t:
        t = t.split(" aparte de ", 1)[0].strip()
    for pref in prefs:
        if t.startswith(pref):
            return t[len(pref):].strip(" ?¿!.")
    for mid, cut in (
        ("diferencia entre", len("diferencia entre")),
        ("relacion entre", len("relacion entre")),
        ("comunidades autonomas", 0),
    ):
        if mid in t:
            if cut:
                return t[t.index(mid) + cut :].strip(" ?¿!.")
            return t.strip(" ?¿!.")
    return t.strip(" ?¿!.")


def say_code_can() -> str:
    return (
        "Puedo abrir un esqueleto del catálogo y dry-runearlo: reverse, clamp, "
        "LIF, gcd, fib, crc8, WSP 16 B y el hipercubo Q6 (64 LIF enteros), "
        "en Python/C corto. Pídeme «codigo Q6» o «postal WSP». Un compilador "
        "o un Kubernetes completo no está en ficha: eso lo digo, no lo invento."
    )
