"""
NAVI 7 — RLC 6.6 + catálogo mundial + harvest en vivo.

No es un LLM. No hay NPU Akida aquí (eso sigue PLAN en docs/NAVI7.md).
7-WORLD: fichas con fuente, razonamiento multi-salto, analogía lateral,
y GET a internet cuando el catálogo no tiene la ficha.

Si VERIFY no tiene extracto: DESCONOCIDO. No se rellena el hueco.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from navi65_reason import extract_math, eval_int_expr
from navi66_engine import NAVI66Engine, Turn66
from navi66_lang import correct_text
from navi7_harvest import fetch_url_card, google_card, wiki_card
from navi7_schema import Catalog, ConceptCard, norm, tokens


@dataclass
class Turn7(Turn66):
    version: str = "7"
    cards: List[str] = field(default_factory=list)
    hops: List[str] = field(default_factory=list)
    lateral: List[str] = field(default_factory=list)
    live: bool = False
    source: str = ""


def _looks_world(t: str) -> bool:
    keys = (
        "que es ", "que son ", "quien fue ", "quien es ", "explica ",
        "define ", "definicion", "concepto", "en que consiste",
        "como funciona", "por que ", "analogia", "se parece",
        "relacion entre", "diferencia entre", "noticias",
        "aprende ", "ensena ", "que dice la ley", "filosof",
        "psicolog", "ciencia", "derecho", "program",
        "cuantas ", "cuantos ", "cuales ", "comunidades",
        "capital de ", "donde esta", "hablame de ",
    )
    return any(k in t for k in keys)


def _topic(user: str) -> str:
    t = user.strip()
    low = t.lower()
    for pref in (
        "que es ", "que son ", "quien fue ", "quien es ", "explica ",
        "define ", "definicion de ", "concepto de ", "en que consiste ",
        "como funciona ", "aprende ", "ensena ", "busca ", "search ",
        "/search ", "/curl ",
    ):
        if low.startswith(pref):
            return t[len(pref):].strip(" ?¿!.")
    if "diferencia entre" in low:
        return t[low.index("diferencia entre") + len("diferencia entre"):].strip(" ?¿!.")
    if "relacion entre" in low:
        return t[low.index("relacion entre") + len("relacion entre"):].strip(" ?¿!.")
    return t.strip(" ?¿!.")


class NAVI7Engine:
    VERSION = "7"
    ROLE = "world-schema-rlc"

    def __init__(self, catalog: Optional[Catalog] = None, live: bool = True):
        self.base = NAVI66Engine()
        self.cat = catalog or Catalog()
        self.live = live
        self.history: List[Turn7] = []
        self.last_trace = None
        self.metrics = {
            "turns": 0,
            "world": 0,
            "live": 0,
            "unknown": 0,
            "lateral": 0,
            "hops": 0,
            "kcc_destroyed": 0,
        }

    @property
    def lessons(self):
        return self.base.lessons

    def remember(self, keys, mask: str, note: str = "") -> None:
        self.base.remember(keys, mask, note)

    def _protect_keys(self, cleaned: str, corr) -> str:
        """6.6 Damerau can turn 'sesgo'→'tengo' or 'LLVM'→'llm'. Undo if the raw token is a ficha."""
        if not corr.dirty or not corr.fixes:
            return cleaned
        keep = set()
        for c in self.cat.cards.values():
            keep.update(c.keyset())
            keep.add(norm(c.title))
        keep.update({"llvm", "sesgo", "adn", "kcc", "wsp", "snn", "lif", "rxos"})
        text = cleaned
        kept = []
        for f in list(corr.fixes):
            if norm(f.raw) in keep:
                text = text.replace(f.guess, f.raw, 1)
                kept.append(f)
        for f in kept:
            corr.fixes.remove(f)
        return text

    @staticmethod
    def _too_big(low: str) -> bool:
        if "completo" in low and any(k in low for k in ("compilador", "sistema operativo", "navegador", "kernel")):
            return True
        if "escribe un compilador" in low or "compiler llvm" in low:
            return True
        return False

    def load(self, path: Path) -> None:
        self.cat = Catalog.load(path)

    def save(self, path: Path) -> None:
        self.cat.save(path)

    def think(self, user: str, show_trace: bool = False, live: Optional[bool] = None) -> Turn7:
        t0 = time.perf_counter()
        use_live = self.live if live is None else live
        corr = correct_text(user)
        cleaned = self._protect_keys(corr.text or user, corr)
        low = cleaned.lower()

        # Out of catalog on purpose: "escribe un compilador LLVM completo"
        if self._too_big(low):
            self.metrics["turns"] += 1
            self.metrics["unknown"] += 1
            turn = Turn7(
                user=cleaned,
                reply="DESCONOCIDO. G_world: fuera de catalogo (pedir un sistema entero no cabe en una ficha).",
                mask="unknown",
                ms=(time.perf_counter() - t0) * 1000.0,
                corrected=cleaned,
                version="7",
            )
            self.history.append(turn)
            return turn

        # Math stays integer-only, never a web parrot.
        expr = extract_math(cleaned)
        if expr and eval_int_expr(expr).get("ok"):
            parent = self.base.think(cleaned, show_trace=show_trace)
            return self._wrap(parent, cleaned, corr, t0)

        # Identity / rxos / code catalog / explicit 6.6 web curl
        if any(k in low for k in (
            "quien eres", "que eres", "hablame de ti", "como te llamas",
            "cual es tu nombre", "tu nombre",
        )):
            return self._id(cleaned, corr, t0)
        if any(k in low for k in ("hola", "buenos dias", "buenas tardes", "hey")) and len(low) < 40:
            return self._id(cleaned, corr, t0)
        if low.startswith("/curl") or low.startswith("curl ") or low.startswith("http"):
            parent = self.base.think(cleaned, show_trace=show_trace)
            return self._wrap(parent, cleaned, corr, t0, mask="news", live=True)

        want_lat = any(k in low for k in ("se parece", "analogia", "analogía", "parecido", "como si"))
        want_hop = any(k in low for k in ("entonces", "por que", "por qué", "relacion", "cadena", "implica"))
        want_world = _looks_world(low) or want_lat or want_hop

        if want_world:
            turn = self._world(cleaned, corr, t0, use_live, want_lat, want_hop)
            self.history.append(turn)
            self.metrics["turns"] += 1
            return turn

        parent = self.base.think(cleaned, show_trace=show_trace)
        # If 6.6 said DESCONOCIDO, try the catalog / live once.
        if "DESCONOCIDO" in (parent.reply or "") and use_live:
            topic = _topic(cleaned)
            if topic and len(tokens(topic)) <= 8:
                turn = self._world(cleaned, corr, t0, True, False, False)
                self.history.append(turn)
                self.metrics["turns"] += 1
                return turn
        turn = self._wrap(parent, cleaned, corr, t0)
        self.history.append(turn)
        self.metrics["turns"] += 1
        return turn

    def _id(self, cleaned: str, corr, t0: float) -> Turn7:
        n = len(self.cat)
        doms = self.cat.domains()
        reply = (
            "Me llamo NAVI. Soy 7-WORLD: PARSE-RETRIEVE-INFER-VERIFY-RENDER "
            "de 6.6. No soy un LLM ni un NPU Akida (eso sigue PLAN). "
            f"Llevo {n} fichas de esquema "
            f"({', '.join(f'{k}:{v}' for k,v in sorted(doms.items())) or 'vacio'}). "
            "Si no hay ficha y el harvest falla, DESCONOCIDO. KCC: 0 fichas destruidas."
        )
        if corr.dirty:
            reply = "supongo " + ", ".join(f"{f.raw}->{f.guess}" for f in corr.fixes) + " | " + reply
        turn = Turn7(
            user=cleaned, reply=reply, mask="talk",
            ms=(time.perf_counter() - t0) * 1000.0,
            corrected=cleaned,
            fixes=[{"raw": f.raw, "guess": f.guess, "dist": f.dist} for f in corr.fixes],
            version="7",
        )
        self.history.append(turn)
        self.metrics["turns"] += 1
        return turn

    def _learn_live(self, topic: str, domain: str = "world") -> Optional[ConceptCard]:
        card = wiki_card(topic, domain)
        if not card:
            card = google_card(topic, domain)
        if card:
            self.cat.add(card)
            self.metrics["live"] += 1
        return card

    def _world(self, cleaned: str, corr, t0: float, live: bool, want_lat: bool, want_hop: bool) -> Turn7:
        self.metrics["world"] += 1
        topic = _topic(cleaned)
        hits = self.cat.retrieve(topic or cleaned, k=4)
        live_used = False
        if not hits and live and topic:
            card = self._learn_live(topic)
            live_used = True
            if card:
                hits = [(card, 1.0)]
        if not hits:
            self.metrics["unknown"] += 1
            reply = (
                f"DESCONOCIDO. G_world: sin ficha para «{topic}». "
                "No invento. Prueba /search o un titulo de Wikipedia."
            )
            return Turn7(
                user=cleaned, reply=reply, mask="unknown",
                ms=(time.perf_counter() - t0) * 1000.0,
                corrected=cleaned, live=live_used, version="7",
            )

        top, score = hits[0]
        hops = self.cat.hop(topic or top.title, depth=2) if want_hop else [top]
        if want_hop:
            self.metrics["hops"] += 1
        lats = self.cat.lateral(topic or top.title, k=3) if (want_lat or want_hop) else []
        if lats:
            self.metrics["lateral"] += 1

        lines = [f"G_world {top.domain} · {top.title} (score {score:.2f})"]
        lines.append(top.extract)
        if hops and len(hops) > 1:
            chain = " → ".join(c.title for c in hops)
            lines.append("HOP: " + chain)
            for c in hops[1:]:
                bit = c.extract.split(".")[0].strip()
                if bit:
                    lines.append(f"  {c.title}: {bit}.")
        if lats:
            lines.append("LATERAL:")
            for c, why in lats:
                lines.append(f"  {c.title} [{c.domain}] — {why}")
        src = top.source or "catalogo"
        lines.append(f"fuente: {src}")
        if live_used:
            lines.append("aprendido ahora (harvest en vivo).")

        # contrast
        if "diferencia entre" in cleaned.lower() and " y " in (topic or ""):
            parts = [p.strip() for p in re_split_vs(topic)]
            if len(parts) == 2:
                other = self.cat.retrieve(parts[1], k=1)
                if not other and live:
                    oc = self._learn_live(parts[1], top.domain)
                    if oc:
                        other = [(oc, 1.0)]
                if other:
                    lines.append(f"CONTRASTE {parts[0]} / {parts[1]}: {other[0][0].extract[:220]}")

        reply = "\n".join(lines)
        if corr.dirty:
            reply = "supongo " + ", ".join(f"{f.raw}->{f.guess}" for f in corr.fixes) + " |\n" + reply
        return Turn7(
            user=cleaned, reply=reply, mask="teach" if "ensena" in cleaned.lower() else "news",
            ms=(time.perf_counter() - t0) * 1000.0,
            corrected=cleaned,
            fixes=[{"raw": f.raw, "guess": f.guess, "dist": f.dist} for f in corr.fixes],
            version="7",
            cards=[c.title for c, _ in hits],
            hops=[c.title for c in hops],
            lateral=[c.title for c, _ in lats],
            live=live_used,
            source=src,
        )

    def _wrap(self, parent: Turn66, cleaned: str, corr, t0: float, mask: Optional[str] = None, live: bool = False) -> Turn7:
        return Turn7(
            user=cleaned,
            reply=parent.reply,
            mask=mask or parent.mask,
            ms=(time.perf_counter() - t0) * 1000.0,
            internal=dict(parent.internal or {}),
            corrected=cleaned,
            fixes=[{"raw": f.raw, "guess": f.guess, "dist": f.dist} for f in corr.fixes],
            version="7",
            live=live,
        )

    def ask_self(self) -> str:
        if not self.cat.cards:
            return "quien eres"
        # pick a mid card
        cards = list(self.cat.cards.values())
        c = cards[len(cards) // 2]
        return f"que es {c.title}"

    def snapshot(self) -> Dict:
        snap = self.cat.snapshot()
        snap["version"] = self.VERSION
        snap["role"] = self.ROLE
        snap["engine"] = dict(self.metrics)
        return snap


def re_split_vs(topic: str) -> List[str]:
    low = topic.lower()
    for sep in (" y ", " vs ", " versus ", "/"):
        if sep in low:
            i = low.index(sep)
            return [topic[:i].strip(), topic[i + len(sep):].strip()]
    return [topic]
