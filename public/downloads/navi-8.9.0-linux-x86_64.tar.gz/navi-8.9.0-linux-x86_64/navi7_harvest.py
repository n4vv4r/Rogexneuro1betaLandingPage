"""
NAVI 7 harvest — internet → fichas.

Host only. urllib sí habla HTTPS (el unikernel todavía no termina TLS).
Fuentes: Wikipedia REST (es, luego en), Google HTML gbv=1, RSS HTTP si hay.
No se inventa el extracto: si la página no da texto, la ficha no se crea.
"""

from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import List, Optional, Tuple

from navi66_web import google_search, html_text
from navi7_schema import ConceptCard, Catalog, norm, tokens

try:
    from navi75_harvest import ddg_card, wiki_card as wiki_card_75
except Exception:  # noqa: BLE001 — keep 7 standalone if 7.5 is missing
    ddg_card = None  # type: ignore
    wiki_card_75 = None  # type: ignore

UA = "rxOS-navi7-lab/8.5 (world-lab; +https://www.rogexlaboratories.com)"


def _get(url: str, timeout: float = 10.0) -> Tuple[int, bytes, str]:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json,text/html,*/*"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return int(getattr(resp, "status", 200) or 200), resp.read(80 * 1024), resp.geturl()
    except urllib.error.HTTPError as e:
        raw = e.read(80 * 1024) if e.fp else b""
        return int(e.code), raw, url
    except Exception:
        return 0, b"", url


def wiki_summary(title: str, lang: str = "es") -> Optional[dict]:
    slug = urllib.parse.quote(title.replace(" ", "_"), safe="")
    url = f"https://{lang}.wikipedia.org/api/rest_v1/page/summary/{slug}"
    st, raw, final = _get(url)
    if st != 200 or not raw:
        return None
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except json.JSONDecodeError:
        return None
    extract = (data.get("extract") or "").strip()
    if not extract:
        return None
    return {
        "title": data.get("title") or title,
        "extract": extract,
        "url": data.get("content_urls", {}).get("desktop", {}).get("page") or final,
        "desc": data.get("description") or "",
        "lang": lang,
    }


def wiki_card(title: str, domain: str, extra_keys: Optional[List[str]] = None) -> Optional[ConceptCard]:
    if wiki_card_75 is not None:
        card = wiki_card_75(title, domain, extra_keys)
        if card:
            return card
    page = wiki_summary(title, "es") or wiki_summary(title, "en")
    if not page:
        return None
    keys = tokens(page["title"]) + tokens(title)
    if extra_keys:
        keys.extend(extra_keys)
    # first sentence as the lead, keep ~400 chars
    extract = page["extract"]
    if len(extract) > 480:
        cut = extract[:480]
        extract = cut.rsplit(".", 1)[0] + "." if "." in cut else cut
    see = []
    # pull 2-3 capitalized phrases as weak neighbors
    for m in re.finditer(r"\b([A-ZÁÉÍÓÚÑ][\wÁÉÍÓÚÑáéíóúñ]{3,}(?:\s+[A-ZÁÉÍÓÚÑ][\wÁÉÍÓÚÑáéíóúñ]{3,})?)\b", page["extract"]):
        name = m.group(1)
        if name.lower() != page["title"].lower() and name not in see:
            see.append(name)
        if len(see) >= 4:
            break
    return ConceptCard(
        id=norm(page["title"]).replace(" ", "_"),
        title=page["title"],
        domain=domain,
        keys=keys,
        extract=extract,
        see_also=see,
        source=page["url"],
        fetched_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )


def google_card(query: str, domain: str = "world") -> Optional[ConceptCard]:
    if ddg_card is not None:
        card = ddg_card(query, domain)
        if card:
            return card
    st, body = google_search(query)
    if st != 200 or not body:
        return None
    lines = [ln.strip() for ln in body.splitlines() if ln.strip()]
    titles = [ln[3:].strip() for ln in lines if re.match(r"^\d\)\s", ln)]
    if not titles:
        return None
    extract = "Google (HTTP gbv=1): " + " | ".join(titles[:5])
    return ConceptCard(
        id="g_" + norm(query).replace(" ", "_")[:48],
        title=query,
        domain=domain,
        keys=tokens(query) + tokens(" ".join(titles[:3])),
        extract=extract[:480],
        see_also=titles[:4],
        source=f"http://www.google.com/search?gbv=1&q={urllib.parse.quote_plus(query)}",
        fetched_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )


def news_cards(query: str = "noticias tecnologia", n: int = 4) -> List[ConceptCard]:
    cards: List[ConceptCard] = []
    g = google_card(query, domain="news")
    if g:
        cards.append(g)
        for title in g.see_also[:n]:
            c = wiki_card(title, "news")
            if c:
                cards.append(c)
    return cards


def _wiki_card_fast(title: str, domain: str, extra_keys: Optional[List[str]] = None) -> Optional[ConceptCard]:
    """One or two REST calls. No opensearch fan-out, no DDG. For --train."""
    page = wiki_summary(title, "es") or wiki_summary(title, "en")
    if not page:
        return None
    keys = tokens(page["title"]) + tokens(title)
    if extra_keys:
        keys.extend(extra_keys)
    extract = page["extract"]
    if len(extract) > 480:
        cut = extract[:480]
        extract = cut.rsplit(".", 1)[0] + "." if "." in cut else cut
    return ConceptCard(
        id=norm(page["title"]).replace(" ", "_"),
        title=page["title"],
        domain=domain,
        keys=keys,
        extract=extract,
        source=page["url"],
        fetched_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )


def harvest_titles(
    cat: Catalog,
    items: List[Tuple[str, str, List[str]]],
    pause: float = 0.0,
    skip_existing: bool = True,
    progress: bool = True,
) -> dict:
    """items = (wiki_title, domain, extra_keys)."""
    ok = miss = skipped = 0
    nitems = len(items)
    for i, (title, domain, extra) in enumerate(items, 1):
        if skip_existing and cat.by_title(title):
            skipped += 1
            if progress:
                print(f"  [{i}/{nitems}] skip {title}", flush=True)
            continue
        card = _wiki_card_fast(title, domain, extra)
        if card:
            cat.add(card)
            ok += 1
            flag = "ok"
        else:
            miss += 1
            flag = "miss"
        if progress:
            print(f"  [{i}/{nitems}] {flag} {title}", flush=True)
        if pause:
            time.sleep(pause)
    return {"ok": ok, "miss": miss, "skipped": skipped, "n": len(cat)}


def fetch_url_card(url: str, domain: str = "world") -> Optional[ConceptCard]:
    st, raw, final = _get(url)
    if st != 200 or not raw:
        return None
    text = html_text(raw.decode("utf-8", "replace"))
    if len(text) < 40:
        return None
    title = text[:80].split(".")[0].strip() or final
    return ConceptCard(
        id="url_" + norm(final)[-40:].replace(" ", "_"),
        title=title[:80],
        domain=domain,
        keys=tokens(text)[:16],
        extract=text[:480],
        source=final,
        fetched_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )
