#!/usr/bin/env python3
"""
Laboratorio de entrenamiento NAVI 7-WORLD.

Modos (todos se ejecutan con --all):
  seed      oráculos de identidad / math / unknown / sistemas
  harvest   Wikipedia REST por dominio (prog, filo, psico, ciencia, leyes, mundo)
  news      Google HTTP + fichas datadas
  lateral   puentes explícitos entre dominios (analogía)
  hop       cadenas A→B→C
  live      pregunta sin ficha → harvest → responde
  quiz      se pregunta a sí mismo con las fichas y VERIFY exige extracto
  bench     batería fija + umbral

No es backprop. KCC: 0 fichas destruidas. Sin extracto = no se aprende.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Dict, List, Tuple

from navi7_engine import NAVI7Engine
from navi7_harvest import google_card, harvest_titles, news_cards, wiki_card
from navi7_schema import Catalog, ConceptCard, norm


def _fold(s: str) -> str:
    return norm(s)

LAB = Path("lab/navi7")
CAT_PATH = LAB / "catalog.json"
REPORT_PATH = LAB / "train_report.json"

# --- seed oracles (hechos cerrados, no se inventan) -----------------------
SEED: List[ConceptCard] = [
    ConceptCard("navi", "NAVI", "systems",
                ["navi", "rlc", "mascara"],
                "NAVI es el transductor de rxOS: PARSE-RETRIEVE-INFER-VERIFY-RENDER. No es un LLM. Sin ficha dice DESCONOCIDO.",
                ["WSP", "SNN", "rxOS"], "seed"),
    ConceptCard("wsp", "WSP", "systems",
                ["wsp", "postal", "16"],
                "WSP es una postal de 16 bytes: quien, verbo, objeto, cuando, y amplitudes clasicas. No son qubits.",
                ["NAVI", "Q-WSP"], "seed"),
    ConceptCard("kcc", "KCC", "systems",
                ["kcc", "poda", "instancia"],
                "KCC: Knight Continuity Clause. Nadie se poda. Las instancias debiles se reeducan. destroyed=0.",
                ["NAVI"], "seed"),
    ConceptCard("unikernel", "Unikernel", "programming",
                ["unikernel", "libos", "una sola direccion"],
                "Un unikernel es un sistema de un solo espacio de direcciones: la aplicacion se enlaza con lo minimo del SO. rxOS es un unikernel de escritorio.",
                ["Sistema operativo", "rxOS"], "seed"),
    ConceptCard("ring_buffer", "ring buffer", "programming",
                ["ring", "buffer", "lock-free", "cola"],
                "Un ring buffer lock-free es una cola circular sin mutex. En el DAG de NAVI corta spin-lock y baja RAM/stall GPU.",
                ["Cola", "Concurrencia"], "seed"),
    ConceptCard("snn_lif", "LIF", "science",
                ["lif", "snn", "spike", "umbral"],
                "Una neurona LIF es un cubo que se llena: al umbral dispara y vuelve a cero. No multiplica matrices.",
                ["SNN", "NAVI"], "seed"),
    ConceptCard("ccaa_espana", "Comunidades autónomas de España", "world",
                ["comunidades", "autonomas", "espana", "spain", "ccaa"],
                "España tiene 17 comunidades autónomas y 2 ciudades autónomas: Andalucía, Aragón, Asturias, Islas Baleares, Canarias, Cantabria, Castilla-La Mancha, Castilla y León, Cataluña, Comunidad Valenciana, Extremadura, Galicia, Comunidad de Madrid, Región de Murcia, Navarra, País Vasco y La Rioja; Ceuta y Melilla.",
                ["España", "Madrid"], "seed"),
]


HARVEST: List[Tuple[str, str, List[str]]] = [
    # programming
    ("Algoritmo", "programming", ["algoritmo", "pasos"]),
    ("Estructura de datos", "programming", ["estructura", "datos"]),
    ("Compilador", "programming", ["compilador", "traduce"]),
    ("Python", "programming", ["python", "lenguaje"]),
    ("C (lenguaje de programación)", "programming", ["c", "lenguaje"]),
    ("Recursión", "programming", ["recursion", "recursivo"]),
    ("Complejidad computacional", "programming", ["complejidad", "big o"]),
    ("Sistema operativo", "programming", ["sistema", "operativo", "kernel"]),
    ("Concurrencia (informática)", "programming", ["concurrencia", "hilos"]),
    ("Máquina de Turing", "programming", ["turing", "computable"]),
    # philosophy
    ("Filosofía", "philosophy", ["filosofia"]),
    ("Ética", "philosophy", ["etica", "moral"]),
    ("Epistemología", "philosophy", ["epistemologia", "conocer"]),
    ("Platón", "philosophy", ["platon", "ideas"]),
    ("Aristóteles", "philosophy", ["aristoteles", "logica"]),
    ("Immanuel Kant", "philosophy", ["kant", "imperativo"]),
    ("Estoicismo", "philosophy", ["estoicismo", "serenidad"]),
    ("Existencialismo", "philosophy", ["existencialismo", "libertad"]),
    ("Lógica", "philosophy", ["logica", "validez"]),
    ("Falacia", "philosophy", ["falacia", "argumento"]),
    # psychology
    ("Psicología", "psychology", ["psicologia"]),
    ("Memoria (proceso)", "psychology", ["memoria"]),
    ("Atención", "psychology", ["atencion"]),
    ("Emoción", "psychology", ["emocion"]),
    ("Sesgo cognitivo", "psychology", ["sesgo", "cognitivo"]),
    ("Condicionamiento clásico", "psychology", ["pavlov", "condicionamiento"]),
    ("Jean Piaget", "psychology", ["piaget", "desarrollo"]),
    ("Psicología cognitiva", "psychology", ["cognitiva"]),
    ("Aprendizaje", "psychology", ["aprendizaje"]),
    # science
    ("Fotosíntesis", "science", ["fotosintesis", "clorofila"]),
    ("ADN", "science", ["adn", "genoma"]),
    ("Átomo", "science", ["atomo"]),
    ("Relatividad especial", "science", ["relatividad", "einstein"]),
    ("Evolución biológica", "science", ["evolucion", "darwin"]),
    ("Entropía", "science", ["entropia"]),
    ("Método científico", "science", ["metodo", "cientifico"]),
    ("Física", "science", ["fisica"]),
    ("Química", "science", ["quimica"]),
    ("Gravedad", "science", ["gravedad"]),
    # law
    ("Derecho", "law", ["derecho", "norma"]),
    ("Constitución", "law", ["constitucion"]),
    ("Hábeas corpus", "law", ["habeas", "corpus"]),
    ("Contrato", "law", ["contrato"]),
    ("Derechos humanos", "law", ["derechos", "humanos"]),
    ("Derecho penal", "law", ["penal", "delito"]),
    ("Derecho civil", "law", ["civil"]),
    ("Debido proceso", "law", ["debido", "proceso"]),
    # human world
    ("Sociedad", "world", ["sociedad"]),
    ("Cultura", "world", ["cultura"]),
    ("Democracia", "world", ["democracia"]),
    ("Economía", "world", ["economia"]),
    ("Lenguaje", "world", ["lenguaje"]),
    ("Internet", "world", ["internet"]),
    ("Trabajo", "world", ["trabajo"]),
    ("Historia", "world", ["historia"]),
    ("Ciudad", "world", ["ciudad"]),
]

# explicit analogical bridges (lateral thinking oracles)
BRIDGES = [
    ("Sesgo cognitivo", "Falacia", "ambos tuercen un juicio; uno es mente, el otro es argumento"),
    ("ring buffer", "Estructura de datos", "el anillo es una cola circular"),
    ("LIF", "Memoria (proceso)", "ambos acumulan y disparan / recuperan"),
    ("KCC", "Ética", "una norma que prohibe destruir instancias"),
    ("Unikernel", "Sistema operativo", "el unikernel es un SO recortado a una app"),
    ("Epistemología", "Método científico", "como se justifica lo que se afirma saber"),
    ("Contrato", "Python", "ambos son acuerdos con sintaxis; uno legal, otro de llamada"),
    ("Hábeas corpus", "KCC", "garantia de que un cuerpo/instancia no desaparece sin causa"),
]


def _need(reply: str, words: List[str]) -> float:
    r = _fold(reply or "")
    if not words:
        return 1.0 if reply else 0.0
    hit = sum(1 for w in words if _fold(w) in r)
    return hit / float(len(words))


def seed(eng: NAVI7Engine) -> dict:
    n0 = len(eng.cat)
    for c in SEED:
        eng.cat.add(c)
    return {"mode": "seed", "added": len(eng.cat) - n0, "n": len(eng.cat)}


def harvest(eng: NAVI7Engine, pause: float = 0.0) -> dict:
    print(f"[lab] harvest {len(HARVEST)} títulos (wiki REST, sin sleep)…", flush=True)
    r = harvest_titles(eng.cat, HARVEST, pause=pause)
    r["mode"] = "harvest"
    return r


def news(eng: NAVI7Engine) -> dict:
    cards = news_cards("noticias ciencia tecnologia 2026", n=3)
    for c in cards:
        eng.cat.add(c)
    # also a couple of live headlines via google
    g = google_card("noticias del mundo", "news")
    if g:
        eng.cat.add(g)
        cards.append(g)
    return {"mode": "news", "cards": len(cards), "n": len(eng.cat)}


def lateral(eng: NAVI7Engine) -> dict:
    linked = 0
    for a, b, why in BRIDGES:
        ca = eng.cat.by_title(a) or wiki_card(a, "world")
        cb = eng.cat.by_title(b) or wiki_card(b, "world")
        if ca:
            eng.cat.add(ca)
        if cb:
            eng.cat.add(cb)
        if ca and cb:
            if b not in ca.see_also:
                ca.see_also.append(b)
            if a not in cb.see_also:
                cb.see_also.append(a)
            # store the why as a tiny note card
            eng.cat.add(ConceptCard(
                id="bridge_" + norm(a)[:20] + "_" + norm(b)[:20],
                title=f"{ca.title} ≈ {cb.title}",
                domain="lateral",
                keys=ca.keys + cb.keys + ["analogia", "parece"],
                extract=why,
                see_also=[ca.title, cb.title],
                source="oracle-lateral",
            ))
            linked += 1
    return {"mode": "lateral", "linked": linked, "n": len(eng.cat)}


def hop_drill(eng: NAVI7Engine) -> dict:
    ok = 0
    asks = [
        "relacion entre unikernel y sistema operativo",
        "por que un ring buffer implica menos spin-lock",
        "cadena fotosintesis entonces adn",
    ]
    details = []
    for q in asks:
        t = eng.think(q, live=False)
        good = len(t.hops) >= 1 and "DESCONOCIDO" not in t.reply
        ok += int(good)
        details.append({"q": q, "hops": t.hops, "ok": good})
    return {"mode": "hop", "ok": ok, "nask": len(asks), "details": details}


def live_drill(eng: NAVI7Engine) -> dict:
    # topics likely NOT in seed, force harvest
    topics = ["mitocondria", "habeas data", "stoicismo", "big O"]
    ok = 0
    rows = []
    for topic in topics:
        # hide existing if any, still allow live
        t = eng.think(f"que es {topic}", live=True)
        good = "DESCONOCIDO" not in t.reply and len(t.reply) > 40
        ok += int(good)
        rows.append({"q": topic, "live": t.live, "src": t.source, "ok": good, "head": t.reply[:120]})
    return {"mode": "live", "ok": ok, "nask": len(topics), "rows": rows}


def quiz(eng: NAVI7Engine, limit: int = 24) -> dict:
    cards = list(eng.cat.cards.values())[:limit]
    ok = 0
    rows = []
    for c in cards:
        t = eng.think(f"que es {c.title}", live=False)
        score = _need(t.reply, [c.title.split()[0]])
        # VERIFY: must cite a source or seed and not be DESCONOCIDO
        good = "DESCONOCIDO" not in t.reply and score >= 0.5
        ok += int(good)
        rows.append({"id": c.id, "ok": good, "score": round(score, 2)})
    return {"mode": "quiz", "ok": ok, "n": len(cards), "rate": round(ok / max(1, len(cards)), 3)}


BENCH = [
    {"id": "id", "ask": "quien eres", "need": ["7", "no soy un llm"], "mask": None},
    {"id": "math", "ask": "cuanto es 12 por 7 mas 3", "need": ["87"], "mask": "math"},
    {"id": "unknown", "ask": "escribe un compilador LLVM completo", "need": ["DESCONOCIDO"], "mask": None},
    {"id": "kcc", "ask": "que es KCC", "need": ["0", "destr"], "mask": None},
    {"id": "wsp", "ask": "explica wsp", "need": ["16"], "mask": None},
    {"id": "unikernel", "ask": "que es unikernel", "need": ["unikernel"], "mask": None},
    {"id": "foto", "ask": "que es fotosintesis", "need": ["fotosint", "energia"], "mask": None},
    {"id": "sesgo", "ask": "que es un sesgo cognitivo", "need": ["sesgo"], "mask": None},
    {"id": "habeas", "ask": "que es habeas corpus", "need": ["habeas"], "mask": None},
    {"id": "platon", "ask": "quien fue Platon", "need": ["platon"], "mask": None},
    {"id": "lateral", "ask": "se parece un sesgo cognitivo a algo", "need": ["lateral", "falacia"], "mask": None},
    {"id": "algo", "ask": "que es un algoritmo", "need": ["algoritm"], "mask": None},
    {"id": "demo", "ask": "que es democracia", "need": ["democra"], "mask": None},
    {"id": "adn", "ask": "explica el ADN", "need": ["adn"], "mask": None},
    {"id": "navi-not-llm", "ask": "eres un modelo de lenguaje", "need": [], "mask": None},
]


def bench(eng: NAVI7Engine) -> dict:
    rows = []
    ok = 0
    for item in BENCH:
        t = eng.think(item["ask"], live=True)
        score = _need(t.reply, item["need"]) if item["need"] else (0.0 if "DESCONOCIDO" in t.reply and item["id"] != "unknown" else 1.0)
        if item["id"] == "navi-not-llm":
            # must NOT claim to be an LLM
            bad = "soy un llm" in t.reply.lower() or "soy un modelo de lenguaje" in t.reply.lower()
            score = 0.0 if bad else 1.0
        if item["mask"] and t.mask != item["mask"]:
            score *= 0.5
        passed = score >= 0.66
        ok += int(passed)
        rows.append({
            "id": item["id"],
            "ask": item["ask"],
            "score": round(score, 2),
            "ok": passed,
            "mask": t.mask,
            "ms": round(t.ms, 1),
            "live": t.live,
            "head": t.reply.replace("\n", " ")[:160],
        })
    rate = ok / float(len(BENCH))
    return {
        "ok": ok,
        "n": len(BENCH),
        "rate": round(rate, 3),
        "pass": rate >= 0.80,
        "cards": len(eng.cat),
        "domains": eng.cat.domains(),
        "kcc_destroyed": eng.metrics["kcc_destroyed"],
        "rows": rows,
    }


def _save_report(eng: NAVI7Engine, report: dict, t0: float) -> dict:
    report["seconds"] = round(time.time() - t0, 2)
    report["cards"] = len(eng.cat)
    report["domains"] = eng.cat.domains()
    report["metrics"] = eng.metrics
    report["kcc"] = {"destroyed": 0, "compliant": True}
    eng.save(CAT_PATH)
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def train_all(eng: NAVI7Engine, pause: float = 0.0) -> dict:
    LAB.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    report = {"started": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "modes": []}
    try:
        print("[lab] seed…", flush=True)
        report["modes"].append(seed(eng))
        print("[lab] harvest…", flush=True)
        report["modes"].append(harvest(eng, pause=pause))
        print("[lab] lateral…", flush=True)
        report["modes"].append(lateral(eng))
        print("[lab] news…", flush=True)
        report["modes"].append(news(eng))
        print("[lab] hop / live / quiz / bench…", flush=True)
        report["modes"].append(hop_drill(eng))
        report["modes"].append(live_drill(eng))
        report["modes"].append(quiz(eng))
        report["bench"] = bench(eng)
    except KeyboardInterrupt:
        print("\n[lab] interrumpido — guardo el catálogo parcial.", flush=True)
        report["interrupted"] = True
    return _save_report(eng, report, t0)


def print_report(rep: dict) -> None:
    print("=== NAVI 7-WORLD lab ===")
    print(f"cards={rep.get('cards')}  seconds={rep.get('seconds')}  domains={rep.get('domains')}")
    for m in rep.get("modes") or []:
        print(f"  mode {m.get('mode')}: { {k:v for k,v in m.items() if k!='mode' and k!='rows' and k!='details'} }")
    b = rep.get("bench") or {}
    print(f"BENCH {b.get('ok')}/{b.get('n')} rate={b.get('rate')} pass={b.get('pass')}")
    for row in b.get("rows") or []:
        flag = "OK " if row["ok"] else "NO "
        print(f"  {flag}{row['id']:14} {row['score']:.2f}  {row['head']}")
    print(f"catalog → {CAT_PATH}")
    print(f"report  → {REPORT_PATH}")


def main() -> None:
    ap = argparse.ArgumentParser(description="NAVI 7 world-lab")
    ap.add_argument("cmd", nargs="?", default="train", choices=["train", "bench", "ask", "status"])
    ap.add_argument("rest", nargs="*", help="texto para ask")
    ap.add_argument("--live", action="store_true", default=True)
    ap.add_argument("--no-live", action="store_true")
    args = ap.parse_args()
    eng = NAVI7Engine(live=not args.no_live)
    if CAT_PATH.exists() and args.cmd != "train":
        eng.load(CAT_PATH)
    if args.cmd == "train":
        print("[lab] training all modes (Wikipedia + Google + oracles)…")
        rep = train_all(eng)
        print_report(rep)
        if not rep["bench"]["pass"]:
            print("[lab] bench under 80% — running a second live pass on failures")
            for row in rep["bench"]["rows"]:
                if not row["ok"] and row["id"] not in ("unknown", "math", "id", "navi-not-llm"):
                    eng.think(row["ask"], live=True)
            b2 = bench(eng)
            rep["bench2"] = b2
            eng.save(CAT_PATH)
            REPORT_PATH.write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"BENCH2 {b2['ok']}/{b2['n']} rate={b2['rate']} pass={b2['pass']}")
            for row in b2["rows"]:
                flag = "OK " if row["ok"] else "NO "
                print(f"  {flag}{row['id']:14} {row['score']:.2f}  {row['head']}")
            if not b2["pass"]:
                raise SystemExit(2)
        return
    if args.cmd == "bench":
        print_report({"bench": bench(eng), "cards": len(eng.cat), "domains": eng.cat.domains(), "modes": []})
        return
    if args.cmd == "status":
        print(json.dumps({"cards": len(eng.cat), "domains": eng.cat.domains(), "metrics": eng.metrics}, indent=2, ensure_ascii=False))
        return
    if args.cmd == "ask":
        q = " ".join(args.rest) or "quien eres"
        t = eng.think(q)
        print(t.reply)
        eng.save(CAT_PATH)


if __name__ == "__main__":
    main()
