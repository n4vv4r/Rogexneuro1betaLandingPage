"""
NAVI 7 — catálogo de fichas (no es un LLM, no hay backprop).

Una ficha = concepto + claves + extracto + fuente + vecinos.
RETRIEVE busca fichas. LATERAL busca analogías. HOP sigue see_also.
VERIFY exige extracto y fuente. Sin ficha: DESCONOCIDO (o harvest).
KCC: el catálogo solo crece o se refuerza. Nunca se borra una ficha.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple


def norm(text: str) -> str:
    t = (text or "").lower()
    for a, b in (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u"), ("ñ", "n")):
        t = t.replace(a, b)
    t = re.sub(r"[^a-z0-9]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


_STOP = {
    "el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "al",
    "y", "o", "u", "en", "con", "por", "para", "que", "es", "son", "se", "su",
    "sus", "lo", "le", "les", "como", "mas", "pero", "si", "no", "a", "the",
    "of", "and", "or", "in", "to", "on", "for", "is", "are", "a", "an",
}


def tokens(text: str) -> List[str]:
    return [w for w in norm(text).split() if w not in _STOP and len(w) > 2]


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / float(len(sa | sb))


@dataclass
class ConceptCard:
    id: str
    title: str
    domain: str
    keys: List[str]
    extract: str
    see_also: List[str] = field(default_factory=list)
    source: str = "seed"
    fetched_at: str = ""
    hits: int = 0
    score: int = 0

    def keyset(self) -> List[str]:
        bag = list(self.keys) + tokens(self.title) + tokens(self.extract)[:12]
        out, seen = [], set()
        for k in bag:
            nk = norm(k)
            if nk and nk not in seen:
                seen.add(nk)
                out.append(nk)
        return out


class Catalog:
    """Fichas persistentes. Crecer, no podar."""

    def __init__(self) -> None:
        self.cards: Dict[str, ConceptCard] = {}
        self.metrics = {
            "added": 0,
            "reinforced": 0,
            "hits": 0,
            "misses": 0,
            "destroyed": 0,  # KCC: must stay 0
        }

    def __len__(self) -> int:
        return len(self.cards)

    def add(self, card: ConceptCard) -> str:
        cid = card.id or norm(card.title).replace(" ", "_")
        card.id = cid
        if not card.fetched_at:
            card.fetched_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        old = self.cards.get(cid)
        if old:
            # reinforce: keep the cleaner extract (chrome corto gana a navbar largo)
            if card.extract:
                old_n = sum(
                    1
                    for n in ("login", "register", "node online", "syncing session")
                    if n in (old.extract or "").lower()
                )
                new_n = sum(
                    1
                    for n in ("login", "register", "node online", "syncing session")
                    if n in (card.extract or "").lower()
                )
                if new_n < old_n or (
                    card.extract not in old.extract and len(card.extract) > len(old.extract)
                ):
                    old.extract = card.extract
            for k in card.keys:
                if k not in old.keys:
                    old.keys.append(k)
            for n in card.see_also:
                if n not in old.see_also:
                    old.see_also.append(n)
            if card.source and old.source == "seed":
                old.source = card.source
            old.score += 1
            self.metrics["reinforced"] += 1
            return cid
        self.cards[cid] = card
        self.metrics["added"] += 1
        return cid

    def reinforce(self, title: str) -> bool:
        """+1 al score si la ficha existe. KCC: no se borra."""
        c = self.by_title(title)
        if not c:
            hits = self.retrieve(title, k=1)
            if not hits or hits[0][1] < 0.40:
                return False
            c = hits[0][0]
        c.score += 1
        c.hits += 1
        self.metrics["reinforced"] += 1
        return True

    def get(self, cid: str) -> Optional[ConceptCard]:
        return self.cards.get(cid)

    def by_title(self, title: str) -> Optional[ConceptCard]:
        n = norm(title)
        for c in self.cards.values():
            if norm(c.title) == n or n in c.keyset():
                return c
        return None

    def retrieve(self, query: str, k: int = 5) -> List[Tuple[ConceptCard, float]]:
        qtok = tokens(query)
        qn = norm(query)
        scored: List[Tuple[ConceptCard, float]] = []
        for c in self.cards.values():
            ks = c.keyset()
            s = jaccard(qtok, ks)
            tn = norm(c.title)
            tflat = tn.replace(" ", "")
            qflat = qn.replace(" ", "")
            if qn and (qn == tn or qn in tn or tn in qn):
                s += 0.70
            elif qflat and tflat and (qflat == tflat or tflat in qflat or qflat in tflat):
                s += 0.62
            elif qn and qn in " ".join(ks):
                s += 0.45
            if any(
                qk in tn
                or qk in tflat
                or qk in norm(c.extract or "")
                or qk in norm(c.source or "")
                for qk in qtok
            ):
                s += 0.15
            if any(qk in ks or qk.replace(" ", "") in tflat for qk in qtok):
                s += 0.20
            # ensayos: ficha que ya pasó VERIFY se recupera antes
            if s > 0:
                s += min(0.28, 0.035 * max(0, int(getattr(c, "score", 0) or 0)))
                scored.append((c, s))
        scored.sort(key=lambda x: x[1], reverse=True)
        if scored:
            self.metrics["hits"] += 1
            scored[0][0].hits += 1
        else:
            self.metrics["misses"] += 1
        return scored[:k]

    def lateral(self, query: str, k: int = 4) -> List[Tuple[ConceptCard, str]]:
        """Analogías: misma forma, otro dominio, o vecinos explícitos."""
        hits = self.retrieve(query, k=3)
        if not hits:
            return []
        seed = hits[0][0]
        seed_tok = set(seed.keyset())
        out: List[Tuple[ConceptCard, str]] = []
        for c in self.cards.values():
            if c.id == seed.id:
                continue
            why = ""
            if any(norm(n) == norm(c.title) or norm(n) in c.keyset() for n in seed.see_also):
                why = f"see_also de {seed.title}"
            elif c.domain != seed.domain and jaccard(seed_tok, c.keyset()) >= 0.12:
                why = f"misma forma, dominio {c.domain} (era {seed.domain})"
            elif jaccard(seed_tok, c.keyset()) >= 0.22:
                why = "solapamiento de claves"
            if why:
                out.append((c, why))
        out.sort(key=lambda x: jaccard(seed_tok, x[0].keyset()), reverse=True)
        return out[:k]

    def hop(self, query: str, depth: int = 2) -> List[ConceptCard]:
        hits = self.retrieve(query, k=1)
        if not hits:
            return []
        chain = [hits[0][0]]
        seen = {chain[0].id}
        for _ in range(max(0, depth)):
            nxt = None
            for name in chain[-1].see_also:
                cand = self.by_title(name)
                if cand and cand.id not in seen:
                    nxt = cand
                    break
            if not nxt:
                lat = self.lateral(chain[-1].title, k=1)
                if lat and lat[0][0].id not in seen:
                    nxt = lat[0][0]
            if not nxt:
                break
            chain.append(nxt)
            seen.add(nxt.id)
        return chain

    def domains(self) -> Dict[str, int]:
        d: Dict[str, int] = {}
        for c in self.cards.values():
            d[c.domain] = d.get(c.domain, 0) + 1
        return d

    def snapshot(self) -> Dict:
        return {
            "n": len(self.cards),
            "domains": self.domains(),
            "metrics": dict(self.metrics),
            "cards": [asdict(c) for c in self.cards.values()],
        }

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.snapshot(), ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "Catalog":
        cat = cls()
        if not path.exists():
            return cat
        data = json.loads(path.read_text(encoding="utf-8"))
        for raw in data.get("cards") or []:
            cat.cards[raw["id"]] = ConceptCard(**{
                k: raw[k] for k in ConceptCard.__dataclass_fields__ if k in raw
            })
        cat.metrics.update(data.get("metrics") or {})
        cat.metrics["destroyed"] = 0
        return cat
