#!/usr/bin/env python3
"""NAVI 7 — host TUI Smoke Aero (ANSI). Usa el motor 7-WORLD entrenado."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from navi66_tui import TUI  # noqa: E402
from navi7_lab import CAT_PATH  # noqa: E402
from navi75_engine import NAVI75Engine  # noqa: E402


def main() -> int:
    eng = NAVI75Engine(live=True)
    if CAT_PATH.exists():
        eng.load(CAT_PATH)
    TUI(eng).run()  # type: ignore[arg-type]
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
