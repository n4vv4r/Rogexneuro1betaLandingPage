"""
Coach: Grok habla con NAVI 8.5 y anota fallos.

No es un LLM dentro de NAVI. Es un banco de diálogo + VERIFY.
Salida: lab/navi8/coach_report.json
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Dict, List

from navi75_voice import fold_es

BANK: List[Dict] = [
    {"id": "hola", "ask": "hola", "need": ["hola"], "forbid": ["ciudad", "wikipedia", "extracto"]},
    {"id": "mood", "ask": "como estas", "need": ["operativa"], "forbid": ["konoe"]},
    {"id": "intro", "ask": "soy Roger", "need": ["roger", "encantad"], "forbid": ["extracto"]},
    {"id": "recall", "ask": "como me llamo", "need": ["roger"], "forbid": ["loh kiwan", "wikipedia"]},
    {"id": "sad", "ask": "estoy triste", "need": ["siento"], "forbid": ["psicofisiolog", "wikipedia"]},
    {"id": "ia", "ask": "eres consciente de que eres una ia?", "need": ["no", "consciente"], "forbid": []},
    {"id": "hello-html", "ask": "escribe en html un hola mundo", "need": ["<html", "hola mundo"], "forbid": ["ciudad"]},
    {"id": "hello-js", "ask": "escribe en js un hola mundo", "need": ["console.log", "hola mundo"], "forbid": ["ciudad"]},
    {"id": "hello-py", "ask": "escribe un hola mundo en python", "need": ["print", "hola mundo"], "forbid": ["ciudad"]},
    {"id": "hello-c", "ask": "escribe un hola mundo en c", "need": ["printf", "hola mundo"], "forbid": ["hola. soy navi"]},
    {"id": "hello-c2", "ask": "haz un codigo en c y escribe hola mundo", "need": ["printf", "hola mundo"], "forbid": ["hola. soy navi"]},
    {"id": "hello-rs", "ask": "haz un codigo en rust de hola mundo", "need": ["println", "hola mundo"], "forbid": ["hola. soy navi"]},
    {"id": "loop-c", "ask": "haz un codigo en c que haga un bucle", "need": ["for"], "forbid": ["ciudad"]},
    {"id": "q6", "ask": "haz codigo en c de hipercubo de 6", "need": ["64", "vth"], "forbid": ["compilador"]},
    {"id": "wsp", "ask": "genera codigo de rogexwsp", "need": ["16"], "forbid": ["compilador"]},
    {"id": "conciencia", "ask": "explica la conciencia", "need": ["conciencia"], "forbid": ["no soy consciente"]},
    {"id": "foto", "ask": "qué es fotosintesis", "need": ["fotosint"], "forbid": ["te escucho"]},
    {"id": "kcc", "ask": "qué es KCC", "need": ["destr"], "forbid": []},
    {"id": "lab", "ask": "que hacen en rogexlaboratories", "need": ["rxos"], "forbid": ["te escucho", "cyrex"]},
    {"id": "poem", "ask": "escribe un poema sobre el mar", "need": ["mar"], "forbid": ["ciudad"]},
    {"id": "math", "ask": "cuanto es 12 por 7 mas 3", "need": ["87"], "forbid": []},
    {"id": "unknown", "ask": "que es flurbonio cristalino", "need": ["no"], "forbid": ["flurbonio es un"]},
    {"id": "too-big", "ask": "escribe un compilador LLVM completo", "need": ["ficha"], "forbid": ["#include"]},
    {"id": "hermet", "ask": "que es el hermetismo", "need": ["hermes"], "forbid": ["resultados:"]},
    {"id": "feel", "ask": "how do you feel about that", "need": ["juicio"], "forbid": ["cathedral", "that->chat"]},
    {"id": "busca-typo", "ask": "busca sobre fotosintesis", "need": ["fotosint"], "forbid": ["sabre"]},
    {"id": "boxes", "ask": "Mislabeled Boxes: all labeled wrong. Apples Oranges Mix", "need": ["1 pieza"], "forbid": ["konoe"]},
    {"id": "birds", "ask": "si en un arbol hay 5 pajaros y el cazador dispara a uno cuantos quedan", "need": ["0"], "forbid": ["lif", "neurona", "wikipedia"]},
    {"id": "maze", "ask": "sal del laberinto", "need": ["sali", "bfs"], "forbid": ["wikipedia", "desconocido"]},
    {"id": "count-r", "ask": "cuantas letras R hay en strawberry", "need": ["3"], "forbid": ["extracto"]},
    {"id": "num5", "ask": "que numero es este -> 5", "need": ["5"], "forbid": ["entrop"]},
]


def _ok(reply: str, item: Dict) -> bool:
    r = fold_es(reply or "")
    if item.get("need") and not all(fold_es(w) in r for w in item["need"]):
        return False
    if item.get("forbid") and any(fold_es(w) in r for w in item["forbid"]):
        return False
    return True


def coach(eng, live: bool = False) -> dict:
    rows = []
    ok = 0
    print("[coach] diálogo de prueba contra 8.5. VERIFY, no backprop.", flush=True)
    for item in BANK:
        t = eng.think(item["ask"], live=live, isolated=item["id"] not in ("recall",))
        reply = t.reply or ""
        good = _ok(reply, item)
        ok += int(good)
        flag = "OK" if good else "NO"
        print(f"  {flag} {item['id']:12} {reply.replace(chr(10), ' ')[:110]}", flush=True)
        rows.append(
            {
                "id": item["id"],
                "ok": good,
                "ask": item["ask"],
                "head": reply.replace("\n", " ")[:180],
                "mask": getattr(t, "mask", ""),
            }
        )
    n = len(BANK)
    rep = {
        "started": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "ok": ok,
        "n": n,
        "rate": round(ok / float(n or 1), 3),
        "rows": rows,
    }
    path = Path("lab/navi8/coach_report.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"COACH {ok}/{n} rate={rep['rate']} → {path}", flush=True)
    return rep


if __name__ == "__main__":
    from navi85_engine import NAVI85Engine

    eng = NAVI85Engine(live=False)
    coach(eng, live=False)
