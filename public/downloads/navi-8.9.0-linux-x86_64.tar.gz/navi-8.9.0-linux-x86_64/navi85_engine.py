"""
NAVI 8.5 — 8 + Markov/Monte Carlo sobre fichas.

Predicción = simular N caminos (catálogo, tema anterior, harvest)
y quedarse con el que VERIFY acepta. Sin extracto: UNKNOWN.
No es un transformer. STDP / e-prop / tensores siguen PLAN (Q6/Akida).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from navi8_engine import NAVI8Engine, Turn8, _solid_hit, _weak
from navi75_harvest import harvest_topic, page_fits
from navi75_voice import fold_es, topic_from
from navi8_reason import classify, clean_extract, is_junk_extract, synthesize
from navi85_markov import (
    ANSWER,
    HARVEST,
    PLAN,
    RETRIEVE,
    UNKNOWN,
    VERIFY,
    Path,
    peaked,
    pick_path,
    verify_score,
)


@dataclass
class Turn85(Turn8):
    version: str = "8.5"
    entropy: float = 0.0
    states: Optional[List[str]] = None


class NAVI85Engine(NAVI8Engine):
    VERSION = "8.5"
    ROLE = "assistant-markov-mc"

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.metrics["version"] = "8.5"
        self.metrics["rollouts"] = 0
        self.metrics["absorb_unknown"] = 0
        self.metrics["absorb_answer"] = 0
        self._repeats = 0
        self._last_state = ""

    def _rollouts(self, topics: List[str], use_live: bool) -> List[Path]:
        """N caminatas: retrieve por tema, tema+previo ya viene en topics."""
        paths: List[Path] = []
        self.metrics["rollouts"] += 1
        for topic in topics or []:
            hits = self.cat.retrieve(topic, k=6)
            scores = [s for _c, s in hits]
            state0 = RETRIEVE
            for card, s in hits[:3]:
                if s < 0.35 or not _solid_hit(card, topic):
                    continue
                extract = clean_extract(card.extract or "", card.title)
                sc = verify_score(topic, card.title, extract)
                if sc < 0.40:
                    continue
                paths.append(
                    Path(
                        states=[state0, VERIFY, ANSWER],
                        topic=topic,
                        title=card.title,
                        extract=extract,
                        source=card.source or "",
                        score=sc + min(0.15, s * 0.05),
                    )
                )
                if peaked(scores):
                    break
            if not any(p.topic == topic for p in paths):
                # alta entropía: no fiarse del top; mirar ctx y harvest
                pages = self.ctx.find_pages(topic)
                if pages:
                    _s, url, title, extract = pages[0]
                    extract = clean_extract(extract, title)
                    if extract and not is_junk_extract(extract) and page_fits(topic, title, extract):
                        sc = verify_score(topic, title, extract)
                        paths.append(
                            Path(
                                states=[state0, HARVEST, VERIFY, ANSWER],
                                topic=topic,
                                title=title,
                                extract=extract,
                                source=url,
                                score=sc,
                            )
                        )
                if use_live:
                    card = harvest_topic(topic)
                    if (
                        card
                        and card.extract
                        and not is_junk_extract(card.extract)
                        and page_fits(topic, card.title, card.extract)
                    ):
                        extract = clean_extract(card.extract, card.title)
                        sc = verify_score(topic, card.title, extract)
                        paths.append(
                            Path(
                                states=[state0, HARVEST, VERIFY, ANSWER if sc >= 0.4 else UNKNOWN],
                                topic=topic,
                                title=card.title,
                                extract=extract,
                                source=card.source or "",
                                score=sc,
                                learned=True,
                            )
                        )
        return paths

    def think(self, user: str, live: Optional[bool] = None, isolated: bool = False) -> Turn85:
        use_live = self.live if live is None else live
        last = ""
        if not isolated:
            try:
                last = self.base.mem.last_topic()
            except Exception:
                last = ""
        kind, topics = classify(user, last_topic=last)
        try:
            self.base.mem.save_turn(
                "user",
                user,
                kind,
                (topics[0] if topics else "") or topic_from(user),
            )
        except Exception:
            pass

        from navi65_reason import extract_math, eval_int_expr

        if extract_math(user) and eval_int_expr(extract_math(user) or "").get("ok"):
            kind = "math"

        # Calibration: talk / skill no despliegan el árbol
        if kind in (
            "trivial",
            "social",
            "identity",
            "self_conscious",
            "capability",
            "code",
            "math",
            "too_big",
            "puzzle",
            "opinion",
        ):
            t = super().think(user, live=False, isolated=isolated)
            out = Turn85(
                user=t.user,
                reply=t.reply.replace("Soy la 8 de rxOS", "Soy la 8.5 de rxOS").replace(
                    "NAVI 8:", "NAVI 8.5:"
                ),
                mask=t.mask,
                ms=t.ms,
                version="8.5",
                cards=t.cards,
                live=False,
                source=t.source,
                used_ctx=t.used_ctx,
                learned=False,
                plan=t.plan,
                entropy=0.0,
                states=[kind, ANSWER],
            )
            return out

        if kind == "search":
            t = super().think(user, live=use_live, isolated=isolated)
            return Turn85(
                user=t.user,
                reply=t.reply,
                mask=t.mask or "news",
                ms=t.ms,
                version="8.5",
                cards=t.cards,
                live=t.live,
                source=t.source,
                used_ctx=t.used_ctx,
                learned=t.live,
                plan=t.plan,
                entropy=0.0,
                states=["search", ANSWER if not _weak(t.reply) else UNKNOWN],
            )

        if kind == "compound":
            t = super().think(user, live=use_live, isolated=isolated)
            return Turn85(
                user=t.user,
                reply=t.reply,
                mask=t.mask,
                ms=t.ms,
                version="8.5",
                cards=t.cards,
                live=t.live,
                source=t.source,
                used_ctx=t.used_ctx,
                learned=t.learned,
                plan=t.plan or topics,
                entropy=0.0,
                states=[PLAN, VERIFY, ANSWER if not _weak(t.reply) else UNKNOWN],
            )

        topic = (topics[0] if topics else "") or topic_from(user)
        hits = self.cat.retrieve(topic, k=6) if topic else []
        ent = 0.0
        if hits:
            from navi85_markov import shannon

            ent = shannon([s for _c, s in hits])

        paths = self._rollouts(topics or [topic], use_live)
        repeats = self._repeats + 1 if self._last_state == RETRIEVE else 0
        best = pick_path(paths, repeats=repeats)
        self._last_state = RETRIEVE
        self._repeats = repeats

        if best and best.score >= 0.40:
            if best.learned:
                from navi7_schema import ConceptCard
                from navi7_schema import tokens as tok

                card = ConceptCard(
                    id="",
                    title=best.title,
                    domain="world",
                    keys=tok(best.title) + tok(best.topic),
                    extract=best.extract,
                    source=best.source,
                )
                self._remember_card(card)
                self.metrics["self_learn"] += 1
            self.metrics["absorb_answer"] += 1
            self.metrics["turns"] += 1
            self.ctx.log_lesson(user, topic, True, 1)
            reply = synthesize(user, [(best.title, best.extract, best.source)]) or best.extract
            return Turn85(
                user=user,
                reply=reply,
                mask="news",
                ms=0.0,
                version="8.5",
                cards=[best.title],
                live=best.learned,
                source=best.source,
                used_ctx=False,
                learned=best.learned,
                plan=topics,
                entropy=ent,
                states=best.states,
            )

        # MC no verificó: cae a 8 (catálogo / harvest). UNKNOWN solo si 8 también falla.
        t8 = super().think(user, live=use_live, isolated=isolated)
        if t8.reply and not _weak(t8.reply):
            self.metrics["absorb_answer"] += 1
            self.metrics["turns"] += 1
            return Turn85(
                user=t8.user,
                reply=t8.reply,
                mask=t8.mask,
                ms=t8.ms,
                version="8.5",
                cards=t8.cards,
                live=t8.live,
                source=t8.source,
                used_ctx=t8.used_ctx,
                learned=t8.learned,
                plan=t8.plan or topics,
                entropy=ent,
                states=[RETRIEVE, VERIFY, ANSWER],
            )

        self.metrics["absorb_unknown"] += 1
        self.metrics["turns"] += 1
        self.ctx.log_lesson(user, topic, False, 1)
        return Turn85(
            user=user,
            reply=(
                f"No tengo un extracto que verifique «{topic}». "
                "No invento. Pásame un título o una URL con /learn."
            ),
            mask="unknown",
            ms=0.0,
            version="8.5",
            cards=[],
            live=False,
            source="",
            used_ctx=False,
            learned=False,
            plan=topics,
            entropy=ent,
            states=[RETRIEVE, VERIFY, UNKNOWN],
        )
