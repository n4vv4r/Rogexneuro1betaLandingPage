"""
NAVI 8.5 — espacio de estados Markov + rollouts Monte Carlo.

No es un LLM. No hay backprop ni e-prop aquí.
Cada paso del bucle RLC es un estado S_t. Se simulan N trayectorias
(retrieve / harvest / last-topic) y se elige la de mayor VERIFY.

Estados absorbentes: ANSWER (extracto verifica) y UNKNOWN (no inventar).
Damping: si el mismo estado se repite sin ficha nueva → UNKNOWN.
Entropía de Shannon sobre los scores de retrieve: alta → harvest o
plan; baja y VERIFY → respuesta directa.

k-Markov: el vector de estado incluye el tema anterior (follow-up).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

from navi75_harvest import page_fits
from navi7_schema import tokens
from navi8_reason import is_junk_extract

# estados del razonamiento (no tokens)
PREMISE = "premise"
RETRIEVE = "retrieve"
HARVEST = "harvest"
PLAN = "plan"
VERIFY = "verify"
SYNTH = "synth"
ANSWER = "answer"
UNKNOWN = "unknown"

ABSORBING = {ANSWER, UNKNOWN}
DAMPING = 0.85


@dataclass
class Path:
    states: List[str] = field(default_factory=list)
    topic: str = ""
    title: str = ""
    extract: str = ""
    source: str = ""
    score: float = 0.0
    learned: bool = False


def shannon(scores: Sequence[float]) -> float:
    vals = [max(0.0, float(s)) for s in scores]
    tot = sum(vals)
    if tot <= 0:
        return 1.0
    h = 0.0
    for v in vals:
        p = v / tot
        if p > 0:
            h -= p * math.log(p + 1e-12, 2)
    return h


def peaked(scores: Sequence[float], max_h: float = 1.6) -> bool:
    if not scores:
        return False
    top = max(scores)
    if top >= 0.70:
        return True
    if top < 0.35:
        return False
    return shannon(scores) <= max_h


def verify_score(topic: str, title: str, extract: str) -> float:
    if not extract or is_junk_extract(extract):
        return 0.0
    if not page_fits(topic, title, extract):
        return 0.0
    bag = set(tokens(extract + " " + title))
    need = [w for w in tokens(topic) if len(w) >= 4]
    if not need:
        return 0.55
    hit = sum(1 for w in need if w in bag)
    return 0.35 + 0.65 * (hit / float(len(need)))


def pick_path(paths: List[Path], repeats: int = 0) -> Optional[Path]:
    """Elige la trayectoria de mayor VERIFY. Damping si hay bucle."""
    ranked = [p for p in paths if p.score >= 0.40]
    ranked.sort(key=lambda p: p.score, reverse=True)
    if not ranked:
        return None
    best = ranked[0]
    if repeats >= 3:
        return None
    # damping: si hay un segundo camino casi igual, no oscilar
    if len(ranked) > 1 and abs(ranked[0].score - ranked[1].score) < 0.02:
        if (1.0 - DAMPING) > 0 and ranked[1].source.startswith("http"):
            return ranked[0]
    return best
