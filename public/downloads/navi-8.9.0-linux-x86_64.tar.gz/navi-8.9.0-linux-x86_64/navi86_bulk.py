"""
Cosecha masiva: más fichas = más palabras verificadas.

No es preentrenar un LLM. Cada título → extracto Wikipedia + fuente.
KCC: no se borra. Ctrl+C guarda.
~120 palabras/ficha ⇒ 10_000 fichas ≈ 1 millón de palabras.
"""

from __future__ import annotations

import json
import time
import urllib.parse
from pathlib import Path
from typing import Iterable, List, Set

from navi75_harvest import _get, harvest_topic, wiki_card

REPORT = Path("lab/navi8/bulk_report.json")

CATEGORIES = (
    "Informática",
    "Inteligencia_artificial",
    "Filosofía",
    "Ética",
    "Física",
    "Matemáticas",
    "Neurociencia",
    "Psicología",
    "Biología",
    "Derecho",
    "Química",
    "Astronomía",
    "Lingüística",
    "Historia_de_la_ciencia",
    "Geografía",
    "Medicina",
    "Economía",
    "Música",
    "Cine",
    "Literatura",
    "Religión",
    "Arquitectura",
    "Electrónica",
    "Programación",
    "Criptografía",
    "Teoría_de_grafos",
    "Lógica",
    "Metafísica",
)

VITAL = (
    "Computación neuromórfica",
    "Red neuronal de impulsos",
    "Potencial de acción",
    "Sinapsis",
    "Hipocampo",
    "Corteza cerebral",
    "Teoría de cuerdas",
    "Teoría M",
    "Mecánica cuántica",
    "Entropía de la información",
    "Cadena de Márkov",
    "Método de Montecarlo",
    "Aprendizaje automático",
    "Red neuronal artificial",
    "Retropropagación",
    "Capitalismo",
    "Socialismo",
    "Estoicismo",
    "Utilitarismo",
    "Deontología",
    "Hermetismo",
    "Gnosticismo",
    "Consciencia",
    "Qualia",
    "Libre albedrío",
    "Navaja de Ockham",
    "Falacia",
    "Sesgo cognitivo",
    "Arquitectura de von Neumann",
    "Arquitectura Harvard",
    "Unikernel",
    "Sistema operativo",
    "Compilador",
)


def random_titles(n: int = 40, lang: str = "es") -> List[str]:
    """Artículos al azar. El catálogo de 800 no los tiene todos."""
    out: List[str] = []
    left = max(1, n)
    while left > 0:
        batch = min(20, left)
        url = (
            f"https://{lang}.wikipedia.org/w/api.php?action=query"
            f"&list=random&rnnamespace=0&rnlimit={batch}&format=json"
        )
        st, raw, _ = _get(url)
        if st != 200 or not raw:
            break
        try:
            data = json.loads(raw.decode("utf-8", "replace"))
        except json.JSONDecodeError:
            break
        got = 0
        for row in (data.get("query") or {}).get("random") or []:
            t = row.get("title") or ""
            if t and ":" not in t:
                out.append(t)
                got += 1
        if not got:
            break
        left -= got
    return out


def category_titles(cat: str, limit: int = 80, lang: str = "es") -> List[str]:
    titles: List[str] = []
    cont = ""
    while len(titles) < limit:
        q = (
            f"https://{lang}.wikipedia.org/w/api.php?action=query"
            "&list=categorymembers&cmnamespace=0&cmlimit=50&format=json"
            f"&cmtitle={urllib.parse.quote(('Category:' if lang == 'en' else 'Categoría:') + cat)}"
        )
        if cont:
            q += "&cmcontinue=" + urllib.parse.quote(cont)
        st, raw, _ = _get(q)
        if st != 200 or not raw:
            break
        try:
            data = json.loads(raw.decode("utf-8", "replace"))
        except json.JSONDecodeError:
            break
        for row in (data.get("query") or {}).get("categorymembers") or []:
            t = row.get("title") or ""
            if t and ":" not in t:
                titles.append(t)
            if len(titles) >= limit:
                break
        cont = ((data.get("continue") or {}).get("cmcontinue")) or ""
        if not cont:
            break
    return titles


def word_count(eng) -> int:
    n = 0
    for c in eng.cat.cards.values():
        n += len((c.extract or "").split())
    return n


def _known(eng) -> Set[str]:
    have: Set[str] = set()
    for c in eng.cat.cards.values():
        have.add((c.title or "").lower())
        have.add((c.id or "").lower())
        have.add(norm_title(c.title or ""))
    return have


def norm_title(t: str) -> str:
    return " ".join((t or "").lower().split())


def bulk(eng, n: int = 200, live: bool = True) -> dict:
    n = max(1, int(n))
    Path("lab/navi8").mkdir(parents=True, exist_ok=True)
    have = _known(eng)
    pool: List[str] = list(VITAL)
    print(f"[bulk] objetivo {n} fichas *nuevas* (no refuerzos).", flush=True)
    if live:
        for cat in CATEGORIES:
            try:
                extra = category_titles(cat, limit=80)
            except KeyboardInterrupt:
                extra = []
                break
            print(f"  cat {cat}: {len(extra)} títulos", flush=True)
            pool.extend(extra)
        try:
            rnd = random_titles(max(n * 3, 60), "es") + random_titles(max(n, 20), "en")
            print(f"  random: {len(rnd)} títulos", flush=True)
            pool.extend(rnd)
        except KeyboardInterrupt:
            pass
    seen = set()
    todo = []
    for t in pool:
        k = norm_title(t)
        if not k or k in seen or k in have:
            continue
        seen.add(k)
        todo.append(t)
    added = 0
    miss = 0
    reinforced = 0
    words0 = word_count(eng)
    cards0 = len(eng.cat)
    t0 = time.time()
    try:
        i = 0
        while added < n and live:
            if i >= len(todo):
                extra = random_titles(40, "es")
                fresh = [t for t in extra if norm_title(t) not in seen and norm_title(t) not in have]
                if not fresh:
                    print("  pool seco, paro.", flush=True)
                    break
                for t in fresh:
                    seen.add(norm_title(t))
                    todo.append(t)
            title = todo[i]
            i += 1
            card = wiki_card(title) or harvest_topic(title)
            if not card or not card.extract:
                miss += 1
                continue
            cid = (card.id or "").lower()
            if cid in eng.cat.cards or norm_title(card.title) in have:
                reinforced += 1
                continue
            eng.cat.add(card)
            have.add(norm_title(card.title))
            have.add(cid)
            if hasattr(eng, "ctx"):
                eng.ctx.put_page(card.source or title, card.title, card.extract)
            added += 1
            print(f"  [{added}/{n}] + {card.title}", flush=True)
            if added % 20 == 0:
                eng.save()
    except KeyboardInterrupt:
        print("\n[bulk] cortado — guardo.", flush=True)
    eng.save()
    words1 = word_count(eng)
    rep = {
        "added": added,
        "miss": miss,
        "reinforced": reinforced,
        "cards": len(eng.cat),
        "cards0": cards0,
        "words": words1,
        "words_delta": words1 - words0,
        "seconds": round(time.time() - t0, 2),
        "note": "solo cuentan fichas con id nuevo. 10k ≈ 1M palabras.",
    }
    REPORT.write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        f"[bulk] +{added} nuevas  (refuerzo {reinforced}, miss {miss})  "
        f"palabras≈{words1} (Δ{words1 - words0})  cards={cards0}→{len(eng.cat)}  → {REPORT}",
        flush=True,
    )
    return rep
