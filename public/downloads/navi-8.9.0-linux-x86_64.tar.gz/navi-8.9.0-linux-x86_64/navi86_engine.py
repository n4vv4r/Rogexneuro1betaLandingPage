"""
NAVI 8.6 — 8.5 + juicio ético/filosófico + harvest web amplio.

Opinar = APPLY de fichas (ética, KCC, método). No es un LLM.
Más red: Wikipedia + abstract DDG + scrape del primer resultado.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from navi75_harvest import harvest_topic, page_fits
from navi75_voice import fold_es, looks_opinion, topic_from
from navi8_reason import classify, is_junk_extract
from navi85_engine import NAVI85Engine, Turn85
from navi86_reason import form_opinion, pick_principles


@dataclass
class Turn86(Turn85):
    version: str = "8.6"
    judged: bool = False


class NAVI86Engine(NAVI85Engine):
    VERSION = "8.6"
    ROLE = "assistant-reasoned-judgment"

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.metrics["version"] = "8.6"
        self.metrics["opinions"] = 0

    def _topic_fact(self, topic: str, use_live: bool):
        if not topic:
            return "", "", ""
        from navi75_harvest import looks_code_extract

        hits = self.cat.retrieve(topic, k=4)
        need = {w for w in fold_es(topic).split() if len(w) >= 6}
        want_code = any(
            k in fold_es(topic)
            for k in ("codigo", "q6", "haz codigo", "hipercubo de 6", "escribe")
        )
        for card, s in hits:
            if s < 0.28 or not card.extract or is_junk_extract(card.extract):
                continue
            if not want_code and looks_code_extract(card.extract):
                continue
            if not page_fits(topic, card.title, card.extract):
                continue
            blob = fold_es((card.title or "") + " " + (card.extract or ""))
            if need and not any(w in blob for w in need):
                continue
            return card.title, card.extract, card.source or ""
        pages = self.ctx.find_pages(topic)
        if pages:
            _s, url, title, extract = pages[0]
            if extract and not is_junk_extract(extract):
                return title or topic, extract, url
        if use_live:
            card = harvest_topic(topic)
            if card and card.extract and not is_junk_extract(card.extract):
                self._remember_card(card)
                self.metrics["self_learn"] += 1
                return card.title, card.extract, card.source or ""
        return "", "", ""

    def think(self, user: str, live: Optional[bool] = None, isolated: bool = False) -> Turn86:
        use_live = self.live if live is None else live
        last = ""
        if not isolated:
            try:
                last = self.base.mem.last_topic()
            except Exception:
                last = ""
        from navi86_skills import count_letter, parse_age, parse_born, say_number, solve_closed

        closed = solve_closed(user)
        if closed:
            return Turn86(
                user=user,
                reply=closed,
                mask="reason",
                ms=0.0,
                version="8.6",
                cards=[],
                live=False,
                source="oracle-puzzle",
                used_ctx=False,
                learned=False,
                plan=None,
                entropy=0.0,
                states=["puzzle", "answer"],
                judged=False,
            )
        counted = count_letter(user)
        if counted:
            return Turn86(
                user=user,
                reply=counted,
                mask="math",
                ms=0.0,
                version="8.6",
                cards=[],
                live=False,
                source="count",
                used_ctx=False,
                learned=False,
                plan=None,
                entropy=0.0,
                states=["count", "answer"],
                judged=False,
            )
        numbered = say_number(user)
        if numbered:
            return Turn86(
                user=user,
                reply=numbered,
                mask="math",
                ms=0.0,
                version="8.6",
                cards=[],
                live=False,
                source="count",
                used_ctx=False,
                learned=False,
                plan=None,
                entropy=0.0,
                states=["count", "answer"],
                judged=False,
            )

        age = parse_age(user)
        if age:
            self.base.mem.remember_fact("user_age", age)
            who = self.base.mem.fact("user_name") or "tú"
            return Turn86(
                user=user,
                reply=f"Vale. Guardé que {who} tiene {age} años.",
                mask="talk",
                ms=0.0,
                version="8.6",
                cards=[],
                live=False,
                source="memory",
                used_ctx=False,
                learned=False,
                plan=None,
                entropy=0.0,
                states=["social", "answer"],
                judged=False,
            )
        born = parse_born(user)
        if born:
            self.base.mem.remember_fact("user_born", born)
            return Turn86(
                user=user,
                reply=f"Hecho. Nacimiento guardado: {born}.",
                mask="talk",
                ms=0.0,
                version="8.6",
                cards=[],
                live=False,
                source="memory",
                used_ctx=False,
                learned=False,
                plan=None,
                entropy=0.0,
                states=["social", "answer"],
                judged=False,
            )

        low = fold_es(user)
        if looks_opinion(low):
            topic = topic_from(user) or last
            if "about that" in low:
                rest = low.split("about that", 1)[-1].strip(" ?¿!.")
                topic = rest or last or topic
            elif fold_es(topic) in ("that", "eso", "ello", "this", "que te parece"):
                topic = last or topic
            title, extract, source = self._topic_fact(topic, use_live)
            principles = pick_principles(self.cat)
            reply = form_opinion(topic, title, extract, source, principles)
            self.metrics["opinions"] += 1
            self.metrics["turns"] += 1
            try:
                self.base.mem.save_turn("user", user, "opinion", topic)
                self.ctx.log_lesson(user, topic, True, 1)
            except Exception:
                pass
            return Turn86(
                user=user,
                reply=reply,
                mask="teach",
                ms=0.0,
                version="8.6",
                cards=[title] + [p[0] for p in principles],
                live=bool(source.startswith("http")) if source else False,
                source=source,
                used_ctx=False,
                learned=False,
                plan=[topic] if topic else None,
                entropy=0.0,
                states=["opinion", "verify", "answer"],
                judged=True,
            )

        t = super().think(user, live=use_live, isolated=isolated)
        reply = (t.reply or "").replace("8.5 de rxOS", "8.6 de rxOS")
        reply = reply.replace("NAVI 8.5", "NAVI 8.6")
        return Turn86(
            user=t.user,
            reply=reply,
            mask=t.mask,
            ms=t.ms,
            version="8.6",
            cards=t.cards,
            live=t.live,
            source=t.source,
            used_ctx=t.used_ctx,
            learned=t.learned,
            plan=t.plan,
            entropy=getattr(t, "entropy", 0.0),
            states=getattr(t, "states", None),
            judged=False,
        )
