"""
NAVI 8.6 — juicio razonado (no sentimiento fingido).

Opinión = aplicar fichas de ética/filosofía/KCC a un hecho con fuente.
Si no hay puente en ficha, se exponen ambos y no se fabrica el veredicto.
«Inventar» aquí es inferir desde extractos, no rellenar huecos.
"""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

from navi75_voice import fold_es, topic_from
from navi8_reason import is_junk_extract

PRINCIPLES = (
    "KCC",
    "Ética",
    "Etica",
    "Derechos humanos",
    "Método científico",
    "Metodo cientifico",
    "Epistemología",
    "Epistemologia",
    "Falacia",
    "Hábeas corpus",
    "Habeas corpus",
)


def pick_principles(cat, k: int = 3) -> List[Tuple[str, str, str]]:
    out: List[Tuple[str, str, str]] = []
    seen = set()
    for title in PRINCIPLES:
        card = cat.by_title(title)
        if not card or not card.extract or is_junk_extract(card.extract):
            hits = cat.retrieve(title, k=1)
            card = hits[0][0] if hits and hits[0][1] >= 0.4 else None
        if not card or card.id in seen:
            continue
        seen.add(card.id)
        out.append((card.title, card.extract, card.source or ""))
        if len(out) >= k:
            break
    return out


def apply_rule(topic: str, fact: str, principles: Sequence[Tuple[str, str, str]]) -> Optional[str]:
    """Una sola inferencia cerrada. Sin ficha que la sostenga: None."""
    bag = fold_es(topic + " " + fact)
    texts = [(t, fold_es(e)) for t, e, _s in principles]
    if any("kcc" in fold_es(t) or "destr" in e for t, e in texts):
        if any(w in bag for w in ("poda", "destru", "borrar instancia", "prune")):
            return (
                "Aplicación: KCC prohíbe podar instancias; reeducar, no destruir. "
                "destroyed=0."
            )
    if any(w in bag for w in ("uap", "ovni", "disclosure", "extrater", "senado")):
        return (
            "Aplicación: el método científico (ficha) exige evidencia reproducible. "
            "Un foro, un artículo o un movimiento de disclosure no basta para "
            "afirmar un hecho extraordinario. Tampoco basta para negarlo: "
            "se suspende el juicio fáctico."
        )
    if any("derechos" in fold_es(t) or "habeas" in fold_es(t) for t, e in texts):
        if any(w in bag for w in ("deten", "carcel", "prision", "sequestro")):
            return (
                "Aplicación: habeas corpus / derechos humanos exigen presentar "
                "a la persona detenida. Retener sin causa es contrario a esas fichas."
            )
    if any(w in bag for w in ("mentir", "engano", "inventar", "sin extracto", "sin ficha")):
        return (
            "Aplicación: VERIFY y la ética del catálogo: afirmar un hecho "
            "sin extracto es mentir. Eso está mal en este sistema."
        )
    return None


def form_opinion(
    topic: str,
    fact_title: str,
    fact_extract: str,
    fact_source: str,
    principles: Sequence[Tuple[str, str, str]],
) -> str:
    bits = [
        "Juicio razonado. No es un sentimiento ni una vida interior.",
    ]
    if fact_extract and not is_junk_extract(fact_extract):
        src = f" ({fact_source})" if fact_source else ""
        bits.append(f"Hecho: {fact_title}{src}: {fact_extract}")
    else:
        bits.append(f"Hecho: no hay extracto verificado de «{topic}».")
    if principles:
        t, e, s = principles[0]
        src = f" ({s})" if s else ""
        bits.append(f"Principio: {t}{src}: {e}")
    applied = apply_rule(topic, fact_extract or "", principles)
    if applied:
        bits.append(applied)
    else:
        bits.append(
            "Aplicación: en las fichas no hay un veredicto que una este hecho "
            "con esos principios. No invento el fallo. Sí puedo citar ambos."
        )
    bits.append("Si traes otra fuente (/learn URL), el juicio se puede rehacer.")
    return " ".join(bits)
