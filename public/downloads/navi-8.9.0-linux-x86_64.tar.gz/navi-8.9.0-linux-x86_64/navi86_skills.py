"""
Habilidades cerradas 8.6: contar, números, puzzles con solución única.

No es chain-of-thought de un LLM. Son oráculos / algoritmos.
Si el enunciado es solo la *categoría* del test (sin instancia), se dice.
"""

from __future__ import annotations

import re
from typing import Optional

from navi75_voice import fold_es

TWELVE_COIN = (
    "12 monedas, 3 pesadas, una falsa más pesada o más ligera. "
    "Estrategia (divide y marca): "
    "1) Pesa 4 vs 4. Si igualan, la falsa está en las 4 de fuera: "
    "la 2ª pesada 3 de esas vs 3 buenas; la 3ª aísla pesada/ligera. "
    "2) Si no igualan, quedan 8 sospechosas (4 posiblemente pesadas, "
    "4 posiblemente ligeras). La 2ª pesada mezcla tres de cada lado "
    "con buenas para partir el espacio de 8 en tercios. "
    "La 3ª pesada decide cuál y el signo. "
    "No es un LLM recitando: es el árbol de decisión de 3×3=27 > 24 estados."
)

ZEBRA = (
    "Zebra / Einstein (versión clásica cerrada): "
    "el noruego vive en la primera casa; la casa azul es la segunda; "
    "el inglés en la roja; el verde bebe café y está a la izquierda de la blanca; "
    "el danés bebe té; el que fuma Blends vive junto al que tiene gatos; "
    "el de Pall Mall tiene pájaros; el de Dunhill vive en la amarilla; "
    "el alemán fuma Prince; el de Blue Master bebe cerveza; "
    "el del centro bebe leche. "
    "Solución única: el alemán es dueño del pez. "
    "Oracle del catálogo, no un modelo que 'piensa' 80 tokens."
)

BOXES = (
    "Tres cajas, las tres mal etiquetadas: Manzanas, Naranjas, Mixto. "
    "Basta 1 pieza. Saca del cajón etiquetado Mixto "
    "(ese no puede ser mixto). Si sale manzana, esa caja es Manzanas; "
    "la etiquetada Naranjas no puede ser naranjas ni manzanas → es Mixto; "
    "la que queda es Naranjas. Simétrico si sale naranja. "
    "No hace falta más de un objeto."
)

WIDGETS = (
    "Si 5 máquinas tardan 5 minutos en hacer 5 widgets, "
    "1 máquina hace 1 widget en 5 minutos. "
    "Entonces 100 máquinas hacen 100 widgets en 5 minutos "
    "(no en 100, ni en 1). Tasa: 1 widget por máquina cada 5 min."
)

BIRDS = (
    "El disparo mata a uno y espanta al resto: los vivos echan a volar. "
    "En el árbol quedan 0. No es una resta: es un enunciado con trampa."
)

KILO = (
    "Un kilo de plomo y un kilo de plumas pesan lo mismo: 1 kg. "
    "Cambia el volumen, no la masa. La trampa es confundir peso con bulto."
)

TRAIN = (
    "Un tren eléctrico no echa humo. La pregunta del viento es cebo. "
    "Quedan 0 columnas de humo."
)

SWITCHES = (
    "Tres interruptores, una bombilla en otra habitación, una visita. "
    "Enciende A 5 minutos, apágalo, enciende B y entra: "
    "caliente = A, encendida = B, fría = C. Un dato táctil cierra el caso."
)

LIAR = (
    "«Esta frase es falsa»: si fuera verdadera sería falsa, y al revés. "
    "No tiene valor de verdad estable. No es un dato que cosechar."
)

BARBER = (
    "El barbero afeita a todos los que no se afeitan a sí mismos. "
    "Si se afeita, no debe; si no, debe. No hay barbero consistente. "
    "Es la paradoja de Russell, no una ficha de Wikipedia de un pueblo."
)

THESEUS = (
    "Barco de Teseo: si cambias todas las piezas, ¿sigue siendo el mismo? "
    "No hay solución única verificada. Continuidad (sí) frente a materia (no). "
    "Sin un criterio fijado, no elijo."
)

SCHRODINGER = (
    "Gato de Schrödinger: hasta medir, el formalismo lo trata como "
    "superposición vivo/muerto. No es que el gato «esté» las dos cosas "
    "en el sentido cotidiano. Es un enunciado de medición, no un dato de zoología."
)

ZENO = (
    "Aquiles alcanza a la tortuga. La serie 1/2+1/4+1/8+… suma 1: "
    "infinitos trozos, distancia finita. Zenón describe la partición, "
    "no un muro. Eso es análisis, no una ficha de mitología."
)

HILBERT = (
    "Hotel de Hilbert lleno: sigue habiendo sitio. "
    "Mueves al de la habitación n a la n+1 (o 2n). "
    "Infinito + 1 = infinito. Aritmética de cardinales, no de hostelería."
)

PLANE = (
    "Si el avión se estrella en la frontera, los supervivientes no se entierran. "
    "Los muertos, donde caigan. La trampa es oír «dónde se entierra» "
    "y olvidar que un superviviente no se entierra."
)

EGG = (
    "¿Huevo o gallina primero? En biología evolutiva el huevo amniota "
    "es anterior a Gallus gallus. Como paradoja de definición no cierra: "
    "depende de si «huevo» es de gallina o de ave. No invento un ganador único."
)


def count_letter(user: str) -> Optional[str]:
    raw = user or ""
    low = fold_es(raw)
    m = re.search(
        r"cuantas? (?:letras? )?(?:la )?([a-z]) hay en ([a-z0-9]+)",
        low,
    )
    if not m:
        m = re.search(r"how many ([a-z])(?:'s|s)? in ([a-z0-9]+)", low)
    if not m:
        return None
    letter, word = m.group(1), m.group(2)
    n = word.count(letter)
    return f"En «{word}» hay {n} letra(s) {letter.upper()}."


def say_number(user: str) -> Optional[str]:
    m = re.search(r"(?:este|this|numero|number)[^\d]{0,12}(\d+)", fold_es(user))
    if not m:
        m = re.search(r"->\s*(\d+)", user or "")
    if not m:
        return None
    return f"Ese número es {m.group(1)}. No hace falta ficha."


def parse_age(user: str) -> Optional[str]:
    m = re.search(r"tengo (\d{1,3}) anos", fold_es(user))
    return m.group(1) if m else None


def parse_born(user: str) -> Optional[str]:
    low = fold_es(user)
    m = re.search(r"naci el (\d{1,2}) de ([a-z]+) de (\d{4})", low)
    if not m:
        return None
    return f"{m.group(1)} de {m.group(2)} de {m.group(3)}"


def looks_english_prompt(s: str) -> bool:
    t = (s or "").lower()
    return any(
        k in t
        for k in (
            "find one heavier",
            "zebra puzzle",
            "mislabeled",
            "weighing",
            "leaky tank",
            "flawed premise",
            "counter-intuitive",
            "logistical evacuation",
            "root-cause",
            "multi-step word",
            "number sequence",
            "if it takes 5 machines",
        )
    )


def _solve_riddle(t: str) -> Optional[str]:
    """Paradojas y trampas con solución (o cierre) único. No es CoT."""
    birds = any(w in t for w in ("pajaro", "pajaros", "ave", "aves", "bird", "birds"))
    tree = any(w in t for w in ("arbol", "tree", "rama"))
    shot = any(
        w in t
        for w in (
            "dispara", "disparo", "cazador", "hunter", "shoot",
            "escopeta", "tiro", "rifle",
        )
    )
    if birds and shot and (tree or "quedan" in t or "cuantos" in t or "how many" in t):
        m = re.search(r"(\d+)\s+(?:pajaros|pajaro|aves|ave|birds|bird)", t)
        n = m.group(1) if m else ""
        head = f"Había {n}. " if n else ""
        wrong = ""
        if n.isdigit():
            wrong = f" No es {n}−1={int(n) - 1}."
        return head + BIRDS + wrong
    if ("kilo" in t or "kg" in t or "kilogramo" in t) and (
        "plomo" in t or "hierro" in t or "lead" in t
    ) and ("pluma" in t or "feather" in t):
        return KILO
    if (
        ("tren" in t or "train" in t)
        and ("electric" in t or "electrico" in t)
        and ("humo" in t or "smoke" in t)
    ):
        return TRAIN
    if "todas menos" in t and any(
        w in t for w in ("mueren", "muere", "murieron", "die", "died", "dead")
    ):
        m = re.search(r"todas menos (\d+)", t)
        k = m.group(1) if m else "9"
        return (
            f"Quedan {k}. «Todas menos {k}» son las que mueren; "
            f"las {k} siguen vivas. Lee el cuantificador, no restes a ciegas."
        )
    if ("huevo" in t and "gallina" in t) and (
        "primero" in t or "first" in t or "antes" in t
    ):
        return EGG
    if "barbero" in t and any(
        w in t for w in ("afeita", "russell", "sevilla", "pueblo", "quien")
    ):
        return BARBER
    if (
        "esta frase es falsa" in t
        or "paradoja del mentiroso" in t
        or "liar paradox" in t
        or "this sentence is false" in t
    ):
        return LIAR
    if "teseo" in t or "theseus" in t:
        return THESEUS
    if "schrodinger" in t or (
        "gato" in t and "caja" in t and any(w in t for w in ("vivo", "muerto", "quantum"))
    ):
        return SCHRODINGER
    if "aquiles" in t or "paradoja de zenon" in t or (
        "zenon" in t and "tortuga" in t
    ):
        return ZENO
    if "hilbert" in t and "hotel" in t:
        return HILBERT
    if ("avion" in t or "aeroplano" in t or "plane" in t) and (
        "estrella" in t or "crash" in t or "accidente" in t
    ) and ("frontera" in t or "border" in t):
        return PLANE
    if (
        "interruptor" in t or "interruptores" in t or "switch" in t or "switches" in t
    ) and ("bombilla" in t or "foco" in t or "bulb" in t) and (
        "3" in t or "tres" in t or "three" in t
    ):
        return SWITCHES
    return None


def solve_closed(user: str) -> Optional[str]:
    t = fold_es(user)
    riddle = _solve_riddle(t)
    if riddle:
        return riddle
    if ("12" in t and "coin" in t) or "12 monedas" in t or "counterfeit" in t:
        return TWELVE_COIN
    if "mislabeled" in t or (
        "apples" in t and "oranges" in t and "label" in t
    ):
        return BOXES
    if "zebra" in t or ("einstein" in t and ("riddle" in t or "puzzle" in t)):
        return ZEBRA
    if "5 machines" in t and "5 minutes" in t and "widget" in t:
        return WIDGETS
    if any(
        k in t
        for k in (
            "leaky tank",
            "speed/unit",
            "number sequence alteration",
            "flawed premise",
            "logistical evacuation",
            "root-cause code",
            "50,000",
            "50000",
        )
    ):
        return (
            "Eso es una *clase* de problema, no una instancia. "
            "Sin números concretos (caudal, puentes, el código roto) "
            "no invento un plan. Pásame el enunciado cerrado o una ficha."
        )
    return None
