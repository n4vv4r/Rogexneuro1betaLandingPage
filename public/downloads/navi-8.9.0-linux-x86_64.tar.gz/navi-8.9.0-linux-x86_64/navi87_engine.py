"""
NAVI 8.7 — 8.6 + presupuesto de pensamiento (inference-time).

Más --think N = más ramas (retrieve, harvest, closed, opinión).
Premio = VERIFY. Autocorrección = podar rama muerta y probar otra.
No es o1 de OpenAI.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from navi75_voice import fold_es, topic_from
from navi86_engine import NAVI86Engine, Turn86
from navi86_skills import count_letter, parse_age, parse_born, say_number, solve_closed
from navi87_search import Node, bump_policy, order_strats, outcome_ok


@dataclass
class Turn87(Turn86):
    version: str = "8.7"
    budget: int = 1
    trace: Optional[List[str]] = None


class NAVI87Engine(NAVI86Engine):
    VERSION = "8.7"
    ROLE = "assistant-inference-search"

    def __init__(self, *args, think: int = 4, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.think_budget = max(1, int(think))
        self.metrics["version"] = "8.7"
        self.metrics["think"] = self.think_budget
        self.metrics["branches"] = 0
        self.metrics["pruned"] = 0

    def _try(self, strat: str, user: str, live: bool, isolated: bool) -> Node:
        self.metrics["branches"] += 1
        if strat == "closed":
            r = solve_closed(user)
            ok = 1 if r and "clase de problema" not in (r or "") else 0
            if r and "clase de problema" in r:
                ok = 1  # honesto cuenta
            return Node(strat, ok, ok, r or "", "oracle", ["closed", "verify"])
        if strat == "count":
            r = count_letter(user) or say_number(user)
            ok = 1 if r else 0
            return Node(strat, ok, ok, r or "", "count", ["count", "verify"])
        if strat == "memory":
            low = fold_es(user)
            if parse_age(user) or parse_born(user):
                t = super().think(user, live=False, isolated=isolated)
                return Node(strat, 1, outcome_ok(t.reply), t.reply, "memory", ["memory"])
            if any(k in low for k in ("quien soy", "de donde soy", "que edad", "como me llamo")):
                t = super().think(user, live=False, isolated=isolated)
                bad = "postal" in fold_es(t.reply) or "ramazzotti" in fold_es(t.reply)
                return Node(strat, 0 if bad else 1, 0 if bad else outcome_ok(t.reply), t.reply, "memory", ["memory"])
            return Node(strat, 0, 0, "", "", ["memory", "prune"])
        if strat == "opinion":
            if "opinas" in fold_es(user) or "feel about" in fold_es(user) or "esta bien" in fold_es(user):
                t = super().think(user, live=live, isolated=isolated)
                return Node(
                    strat,
                    1 if getattr(t, "judged", False) else 0,
                    outcome_ok(t.reply),
                    t.reply,
                    t.source or "",
                    ["opinion", "verify"],
                )
            return Node(strat, 0, 0, "", "", ["opinion", "prune"])
        if strat == "retrieve":
            t = super().think(user, live=False, isolated=isolated)
            weak = not outcome_ok(t.reply) or fold_es(t.reply).startswith("no tengo")
            return Node(
                strat,
                0 if weak else 1,
                0 if weak else 1,
                t.reply,
                t.source or "",
                ["retrieve", "verify"],
            )
        if strat == "harvest":
            if not live:
                return Node(strat, 0, 0, "", "", ["harvest", "prune"])
            t = super().think(user, live=True, isolated=isolated)
            weak = not outcome_ok(t.reply) or fold_es(t.reply).startswith("no tengo")
            return Node(
                strat,
                0 if weak else 1,
                0 if weak else 1,
                t.reply,
                t.source or "",
                ["harvest", "verify"],
            )
        return Node(strat, 0, 0, "", "", ["prune"])

    def think(self, user: str, live: Optional[bool] = None, isolated: bool = False) -> Turn87:
        use_live = self.live if live is None else live
        kind, _topics = __import__("navi8_reason", fromlist=["classify"]).classify(
            user, last_topic=""
        )
        # barato: un paso, sin árbol
        if kind in (
            "trivial",
            "social",
            "identity",
            "self_conscious",
            "capability",
            "code",
            "math",
            "too_big",
            "puzzle",
        ):
            t = super().think(user, live=use_live, isolated=isolated)
            return Turn87(
                user=t.user,
                reply=t.reply.replace("8.6 de rxOS", "8.7 de rxOS").replace("8.5 de rxOS", "8.7 de rxOS"),
                mask=t.mask,
                ms=t.ms,
                version="8.7",
                cards=t.cards,
                live=t.live,
                source=t.source,
                used_ctx=t.used_ctx,
                learned=t.learned,
                plan=t.plan,
                entropy=getattr(t, "entropy", 0.0),
                states=getattr(t, "states", None),
                judged=getattr(t, "judged", False),
                budget=1,
                trace=[kind],
            )

        budget = self.think_budget
        trace: List[str] = []
        best: Optional[Node] = None
        for strat in order_strats(self.ctx):
            if budget <= 0:
                break
            budget -= 1
            node = self._try(strat, user, use_live, isolated)
            mark = "✓" if node.outcome else "✗"
            trace.append(f"{strat}{mark}")
            if node.process == 0 and node.outcome == 0:
                self.metrics["pruned"] += 1
                continue
            if node.outcome == 1:
                bump_policy(self.ctx, strat, 1)
                best = node
                break
            if best is None or node.process > best.process:
                best = node

        if not best or not best.reply:
            t = super().think(user, live=use_live, isolated=isolated)
            reply = t.reply
            src = t.source
            states = getattr(t, "states", None)
            judged = getattr(t, "judged", False)
        else:
            reply = best.reply
            src = best.source
            states = best.states
            judged = best.strat == "opinion"

        self.metrics["turns"] += 1
        return Turn87(
            user=user,
            reply=reply,
            mask="teach" if judged else "news",
            ms=0.0,
            version="8.7",
            cards=[],
            live=bool(src.startswith("http")) if src else False,
            source=src or "",
            used_ctx=False,
            learned=False,
            plan=None,
            entropy=0.0,
            states=states,
            judged=judged,
            budget=self.think_budget,
            trace=trace,
        )
