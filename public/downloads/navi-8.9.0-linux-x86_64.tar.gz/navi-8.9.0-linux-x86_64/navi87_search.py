"""
NAVI 8.7 — cómputo en inferencia (estilo o1, sin transformer).

o1 = CoT oculto + RL sobre tokens.
8.7 = árbol de *estrategias* (closed / memoria / retrieve / harvest /
opinión) + premio 0/1 VERIFY + más presupuesto = más ramas.

No hay PPO, no hay P(token), no hay pista de mil palabras.
La «política» son contadores: la estrategia que VERIFY aprueba se usa antes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from navi8_reason import classify, is_junk_extract
from navi75_voice import fold_es

STRATS = ("closed", "count", "memory", "retrieve", "harvest", "opinion")


@dataclass
class Node:
    strat: str
    process: int  # 1 si el paso verifica
    outcome: int  # 1 si la respuesta final sirve
    reply: str = ""
    source: str = ""
    states: List[str] = field(default_factory=list)


def outcome_ok(reply: str) -> bool:
    r = fold_es(reply or "")
    if not r or len(r) < 8:
        return 0
    if r.startswith("te escucho"):
        return 0
    if r.startswith("resultados:"):
        return 0
    if "google (http" in r:
        return 0
    return 1


def policy_key(name: str) -> str:
    return "pol_" + name


def order_strats(ctx) -> List[str]:
    scored = []
    for s in STRATS:
        try:
            n = int(ctx.fact(policy_key(s)) or "0")
        except Exception:
            n = 0
        scored.append((-n, s))
    scored.sort()
    return [s for _n, s in scored]


def bump_policy(ctx, name: str, delta: int = 1) -> None:
    key = policy_key(name)
    try:
        n = int(ctx.fact(key) or "0")
    except Exception:
        n = 0
    ctx.put_fact(key, str(max(0, n + delta)), "policy")
