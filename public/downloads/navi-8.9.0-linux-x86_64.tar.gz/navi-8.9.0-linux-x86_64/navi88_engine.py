"""
NAVI 8.8 — 8.7 + supervivencia de políticas.

El que responde es el organismo campeón del nicho.
Entrenar = torneo VERIFY: el malo se duerme, el bueno copia ejemplos.
No es un LLM. No hay gradientes.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from navi75_voice import fold_es
from navi87_engine import NAVI87Engine, Turn87
from navi88_life import (
    DEFAULT_POP,
    Organism,
    Population,
    load_pop,
    mutate,
    save_pop,
)
from navi88_talk import training_set, verify_item


@dataclass
class Turn88(Turn87):
    version: str = "8.8"
    organism: str = ""
    fitness: float = 0.0
    generation: int = 0
    reason: Optional[List[str]] = None


class NAVI88Engine(NAVI87Engine):
    VERSION = "8.8"
    ROLE = "assistant-survival"

    def __init__(
        self,
        *args,
        pop_path: Optional[Path] = None,
        think: int = 4,
        **kwargs,
    ) -> None:
        super().__init__(*args, think=think, **kwargs)
        self.pop_path = Path(pop_path) if pop_path else DEFAULT_POP
        self.pop: Population = load_pop(self.pop_path, version="8.8")
        self.metrics["version"] = "8.8"
        self.metrics["survived"] = 0
        self.metrics["slept"] = 0

    def _org_for(self, user: str) -> Organism:
        guessed = self.pop.guess_niche(user)
        champ = self.pop.champion(guessed)
        routed = champ.route(user)
        if routed != guessed and self.pop.alive_in(routed):
            return self.pop.champion(routed)
        return champ

    def think(self, user: str, live: Optional[bool] = None, isolated: bool = False) -> Turn88:
        use_live = self.live if live is None else live
        from navi75_voice import looks_capability, looks_id, looks_self_conscious

        from navi75_voice import looks_bio_recall, looks_poem_feedback

        if looks_id(user) or looks_self_conscious(user) or looks_capability(user):
            org = self.pop.champion("identity")
            route = "identity"
        elif looks_bio_recall(user) or looks_poem_feedback(user):
            org = self.pop.champion("social")
            route = "social"
        else:
            org = self._org_for(user)
            route = org.route(user)
        from navi89_maze import looks_maze, say_maze

        if looks_maze(user):
            reply = say_maze(user)
            turn = Turn88(
                user=user,
                reply=reply,
                mask="reason",
                ms=0.0,
                version="8.8",
                cards=[],
                live=False,
                source="oracle-maze",
                used_ctx=False,
                learned=False,
                plan=None,
                entropy=0.0,
                states=["maze", "bfs", "answer"],
                judged=False,
                budget=1,
                trace=["maze", "bfs"],
                organism=org.id,
                fitness=round(org.fitness, 3),
                generation=self.pop.generation,
            )
            from navi89_reason import explain

            turn.reason = explain(self, user, turn)
            return turn
        t = self._run_route(user, route, use_live, isolated)
        reply = (t.reply or "").replace("8.7 de rxOS", "8.8 de rxOS").replace(
            "8.6 de rxOS", "8.8 de rxOS"
        )
        trace = list(getattr(t, "trace", None) or [])
        if f"org:{org.id}" not in trace:
            trace = [f"org:{org.id}", f"route:{route}"] + trace
        turn = Turn88(
            user=user,
            reply=reply,
            mask=t.mask,
            ms=getattr(t, "ms", 0.0) or 0.0,
            version="8.8",
            cards=getattr(t, "cards", None) or [],
            live=getattr(t, "live", False),
            source=getattr(t, "source", "") or "",
            used_ctx=getattr(t, "used_ctx", False),
            learned=getattr(t, "learned", False),
            plan=getattr(t, "plan", None),
            entropy=getattr(t, "entropy", 0.0) or 0.0,
            states=getattr(t, "states", None),
            judged=getattr(t, "judged", False),
            budget=getattr(t, "budget", 1) or 1,
            trace=trace,
            organism=org.id,
            fitness=round(org.fitness, 3),
            generation=self.pop.generation,
        )
        from navi89_reason import explain

        turn.reason = explain(self, user, turn)
        return turn

    def _run_route(self, user: str, route: str, live: bool, isolated: bool) -> Turn87:
        # social / identity / puzzle / code: barato, sin harvest
        if route == "identity":
            from navi75_voice import looks_capability, looks_self_conscious

            if looks_self_conscious(user):
                return self._cheap(user, "self_conscious", live, isolated)
            if looks_capability(user):
                return self._cheap(user, "capability", live, isolated)
            return self._cheap(user, "identity", live, isolated)
        if route in ("social", "puzzle", "code"):
            kind = {"puzzle": "puzzle", "code": "code"}.get(route, "social")
            return self._cheap(user, kind, live, isolated)
        return super().think(user, live=live, isolated=isolated)

    def _cheap(self, user: str, kind: str, live: bool, isolated: bool) -> Turn87:
        """Fuerza el camino barato de 8.7 (sin árbol de harvest)."""

        def _forced(u, last_topic=""):
            return kind, []

        import navi8_engine
        import navi8_reason
        import navi85_engine
        import navi86_engine

        mods = (navi8_reason, navi8_engine, navi85_engine, navi86_engine)
        olds = [getattr(m, "classify", None) for m in mods]
        for m in mods:
            if hasattr(m, "classify"):
                m.classify = _forced
        try:
            t = NAVI87Engine.think(
                self,
                user,
                live=False if kind != "fact" else live,
                isolated=isolated,
            )
        finally:
            for m, old in zip(mods, olds):
                if old is not None:
                    m.classify = old
        return t

    def survive(
        self,
        generations: int = 6,
        include_talk: bool = True,
        seed: int = 8,
    ) -> dict:
        """Torneo. El perdedor se duerme. El ganador aprende el enunciado."""
        rng = random.Random(seed + self.pop.generation)
        items = training_set(include_talk=include_talk)
        hist = []
        for g in range(max(1, generations)):
            self.pop.generation += 1
            gen = self.pop.generation
            hits = 0
            n = 0
            for item in items:
                niche = item.get("niche") or self.pop.guess_niche(item["ask"])
                pool = self.pop.alive_in(niche) or [self.pop.champion(niche)]
                a = pool[0] if len(pool) == 1 else rng.choice(pool)
                b = None
                if len(pool) > 1:
                    b = rng.choice([o for o in pool if o.id != a.id] or pool)
                ca, cb = self._score(a, item), None
                if b:
                    cb = self._score(b, item)
                winner, loser, ok = a, b, ca
                if b is not None and cb is not None:
                    if cb and not ca:
                        winner, loser, ok = b, a, True
                    elif ca and not cb:
                        winner, loser, ok = a, b, True
                    elif ca and cb:
                        winner = a if a.fitness >= b.fitness else b
                        loser = b if winner is a else a
                        ok = True
                    else:
                        ok = False
                winner.reward(ok, gen)
                if ok:
                    winner.learn_example(item["ask"])
                    hits += 1
                if loser is not None:
                    loser.reward(False, gen)
                    last_of_kind = len(self.pop.alive_in(loser.niche)) <= 1
                    champ = self.pop.champion(loser.niche)
                    if (
                        loser.should_sleep(gen)
                        and not last_of_kind
                        and loser.id != champ.id
                    ):
                        loser.alive = False
                        self.pop.dormant += 1
                        self.metrics["slept"] += 1
                n += 1
            # reproducción del campeón si la presión ya subió
            if rng.random() < 0.25 + 0.45 * (hits / float(n or 1)):
                kid = mutate(self.pop.champion("social"), gen, rng)
                self.pop.organisms.append(kid)
                self.pop.born += 1
            rate = hits / float(n or 1)
            hist.append({"gen": gen, "rate": round(rate, 3), "alive": sum(1 for o in self.pop.organisms if o.alive)})
            self.metrics["survived"] += 1
            print(
                f"  [survive {self.VERSION}] gen={gen} rate={rate:.3f} "
                f"alive={hist[-1]['alive']} slept={self.pop.dormant}",
                flush=True,
            )
        save_pop(self.pop, self.pop_path)
        return {
            "version": self.VERSION,
            "generations": generations,
            "history": hist,
            "pop": self.pop.snapshot(),
            "items": len(items),
        }

    def _score(self, org: Organism, item: dict) -> bool:
        route = org.route(item["ask"])
        # un organismo de harvest en nicho social falla si enruta a fact
        if item.get("niche") == "social" and route == "fact":
            return False
        if item.get("niche") == "puzzle" and route not in ("puzzle",):
            return False
        t = self._run_route(item["ask"], route, live=False, isolated=True)
        return verify_item(t.reply, item)

    def save(self, pop_only: bool = False) -> None:
        save_pop(self.pop, self.pop_path)
        if pop_only:
            return
        try:
            from navi7_lab import CAT_PATH

            self.base.cat.save(CAT_PATH)
        except KeyboardInterrupt:
            print("corte: población ya en disco.", flush=True)
            raise

    def snapshot(self) -> dict:
        snap = super().snapshot()
        snap["version"] = "8.8"
        snap["life"] = self.pop.snapshot()
        return snap
