"""
NAVI 8.8 — supervivencia de organismos de política.

No es backprop. No se borra ninguna ficha (KCC).
Un organismo = orden de detectores + nicho + ejemplos de conversación.
Fitness = VERIFY 0/1. El perdedor se duerme; el ganador se reproduce.
La curva es sigmoide: al principio se explora, luego se endurece.
"""

from __future__ import annotations

import json
import math
import random
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional

from navi75_voice import (
    fold_es,
    looks_ack,
    looks_capability,
    looks_code,
    looks_feel,
    looks_greet,
    looks_id,
    looks_intro,
    looks_meta_social,
    looks_mood,
    looks_name_recall,
    looks_opinion,
    looks_place_recall,
    looks_question,
    looks_search,
    looks_self_conscious,
)

DEFAULT_POP = Path("lab/navi88/pop.json")
NICHES = ("social", "puzzle", "fact", "code", "identity")

_DETECT_MAP = {
    "ack": "social",
    "greet": "social",
    "mood": "social",
    "intro": "social",
    "recall": "social",
    "meta": "social",
    "riddle": "puzzle",
    "closed": "puzzle",
    "count": "puzzle",
    "code": "code",
    "id": "identity",
    "conscious": "identity",
    "capability": "identity",
    "search": "fact",
    "question": "fact",
    "opinion": "fact",
}


def _near(a: str, b: str) -> bool:
    a, b = fold_es(a), fold_es(b)
    if not a or not b:
        return False
    if a == b or a.startswith(b) or b.startswith(a):
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) == len(b):
        return sum(x != y for x, y in zip(a, b)) <= 1
    long, short = (a, b) if len(a) > len(b) else (b, a)
    i = j = miss = 0
    while i < len(long) and j < len(short):
        if long[i] == short[j]:
            i += 1
            j += 1
        else:
            miss += 1
            i += 1
            if miss > 1:
                return False
    return True


def detectors() -> Dict[str, Callable[[str], bool]]:
    from navi86_skills import count_letter, say_number, solve_closed

    return {
        "ack": looks_ack,
        "greet": lambda s: looks_greet(s) or fold_es(s).strip(" ?¿!.") in {
            "hola", "hey", "buenas",
        },
        "mood": lambda s: looks_mood(s) or looks_feel(s),
        "intro": looks_intro,
        "recall": lambda s: looks_name_recall(s) or looks_place_recall(s),
        "meta": looks_meta_social,
        "riddle": lambda s: solve_closed(s) is not None,
        "closed": lambda s: solve_closed(s) is not None,
        "count": lambda s: bool(count_letter(s) or say_number(s)),
        "code": looks_code,
        "id": looks_id,
        "conscious": looks_self_conscious,
        "capability": looks_capability,
        "search": looks_search,
        "question": looks_question,
        "opinion": looks_opinion,
    }


def niche_of_kind(kind: str) -> str:
    if kind in ("trivial", "social"):
        return "social"
    if kind in ("puzzle", "math"):
        return "puzzle"
    if kind in ("code",):
        return "code"
    if kind in ("identity", "self_conscious", "capability"):
        return "identity"
    return "fact"


def sigmoid(gen: int, center: int = 4, k: float = 1.4) -> float:
    """0→1. Al principio explorar; luego seleccionar fuerte."""
    return 1.0 / (1.0 + math.exp(-(gen - center) / max(0.4, k)))


@dataclass
class Organism:
    id: str
    niche: str
    detectors: List[str]
    examples: List[str] = field(default_factory=list)
    fallback: str = ""
    fitness: float = 0.5
    wins: int = 0
    losses: int = 0
    generation: int = 0
    alive: bool = True
    parent: str = ""

    def route(self, user: str) -> str:
        u = fold_es(user).strip(" ?¿!.")
        for ex in self.examples:
            if _near(u, ex):
                return self.niche
        table = detectors()
        for name in self.detectors:
            fn = table.get(name)
            if fn:
                try:
                    if fn(user) or fn(u):
                        return _DETECT_MAP.get(name, self.niche)
                except Exception:
                    continue
        return self.fallback or self.niche

    def learn_example(self, user: str) -> None:
        u = fold_es(user).strip(" ?¿!.")
        if u and u not in self.examples:
            self.examples.append(u)
            if len(self.examples) > 80:
                self.examples = self.examples[-80:]

    def reward(self, ok: bool, gen: int) -> None:
        press = 0.12 + 0.38 * sigmoid(gen)
        if ok:
            self.wins += 1
            self.fitness = min(1.0, self.fitness + press * (1.0 - self.fitness))
        else:
            self.losses += 1
            self.fitness = max(0.0, self.fitness - press * self.fitness)

    def should_sleep(self, gen: int) -> bool:
        if not self.alive:
            return False
        floor = 0.18 + 0.22 * sigmoid(gen)
        return self.losses >= 3 and self.fitness < floor and self.wins < self.losses


@dataclass
class Population:
    version: str = "8.8"
    generation: int = 0
    organisms: List[Organism] = field(default_factory=list)
    dormant: int = 0
    born: int = 0

    def alive_in(self, niche: str) -> List[Organism]:
        return [o for o in self.organisms if o.alive and o.niche == niche]

    def champion(self, niche: str) -> Organism:
        pool = self.alive_in(niche)
        if not pool:
            pool = [o for o in self.organisms if o.alive]
        if not pool:
            org = _seed_one(niche, "rescue")
            self.organisms.append(org)
            return org
        return max(pool, key=lambda o: (o.fitness, o.wins, -o.losses))

    def second(self, niche: str) -> Optional[Organism]:
        pool = sorted(
            self.alive_in(niche),
            key=lambda o: (o.fitness, o.wins),
            reverse=True,
        )
        if len(pool) >= 2:
            return pool[1]
        others = [o for o in self.organisms if o.alive and o.id != self.champion(niche).id]
        return others[0] if others else None

    def guess_niche(self, user: str) -> str:
        from navi8_reason import classify

        kind, _ = classify(user)
        return niche_of_kind(kind)

    def snapshot(self) -> dict:
        alive = sum(1 for o in self.organisms if o.alive)
        return {
            "version": self.version,
            "generation": self.generation,
            "alive": alive,
            "dormant": sum(1 for o in self.organisms if not o.alive),
            "born": self.born,
            "best": {
                n: round(self.champion(n).fitness, 3) for n in NICHES if self.alive_in(n)
            },
        }


def _seed_one(niche: str, tag: str) -> Organism:
    seeds = {
        "social": ["ack", "greet", "mood", "intro", "recall", "meta", "question"],
        "puzzle": ["riddle", "closed", "count", "question"],
        "fact": ["search", "question", "opinion"],
        "code": ["code", "question"],
        "identity": ["conscious", "capability", "id", "question"],
    }
    return Organism(
        id=f"{niche}-{tag}",
        niche=niche,
        detectors=list(seeds.get(niche, ["question"])),
        fitness=0.55,
    )


def seed_population(version: str = "8.8") -> Population:
    """Buenos + malos. Los malos mueren al entrenar (se duermen)."""
    pop = Population(version=version)
    for n in NICHES:
        pop.organisms.append(_seed_one(n, "alpha"))
    # depredadores: cosechan todo. Deben perder en social/puzzle.
    pop.organisms.append(
        Organism(
            id="social-harvest",
            niche="social",
            detectors=["question", "search"],
            fallback="fact",
            fitness=0.45,
        )
    )
    pop.organisms.append(
        Organism(
            id="puzzle-harvest",
            niche="puzzle",
            detectors=["question", "search"],
            fallback="fact",
            fitness=0.45,
        )
    )
    pop.organisms.append(
        Organism(
            id="fact-alpha2",
            niche="fact",
            detectors=["question", "search", "opinion"],
            fitness=0.52,
        )
    )
    pop.born = len(pop.organisms)
    return pop


def mutate(parent: Organism, gen: int, rng: random.Random) -> Organism:
    kids = list(parent.detectors)
    if kids and rng.random() < 0.5:
        i, j = rng.randrange(len(kids)), rng.randrange(len(kids))
        kids[i], kids[j] = kids[j], kids[i]
    extra = [d for d in _DETECT_MAP if d not in kids]
    if extra and rng.random() < 0.35:
        kids.insert(0, rng.choice(extra))
    child = Organism(
        id=f"{parent.niche}-g{gen}-{rng.randrange(1000, 9999)}",
        niche=parent.niche,
        detectors=kids[:10],
        examples=list(parent.examples[-40:]),
        fallback=parent.fallback,
        fitness=0.5 * parent.fitness + 0.25,
        generation=gen,
        parent=parent.id,
    )
    return child


def save_pop(pop: Population, path: Optional[Path] = None) -> Path:
    dest = Path(path) if path else DEFAULT_POP
    dest.parent.mkdir(parents=True, exist_ok=True)
    blob = {
        "version": pop.version,
        "generation": pop.generation,
        "dormant": pop.dormant,
        "born": pop.born,
        "saved": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "organisms": [asdict(o) for o in pop.organisms],
    }
    dest.write_text(json.dumps(blob, ensure_ascii=False, indent=2), encoding="utf-8")
    return dest


def load_pop(path: Optional[Path] = None, version: str = "8.8") -> Population:
    src = Path(path) if path else DEFAULT_POP
    if not src.exists():
        return seed_population(version)
    data = json.loads(src.read_text(encoding="utf-8"))
    pop = Population(
        version=data.get("version") or version,
        generation=int(data.get("generation") or 0),
        dormant=int(data.get("dormant") or 0),
        born=int(data.get("born") or 0),
    )
    for raw in data.get("organisms") or []:
        pop.organisms.append(Organism(**{k: raw[k] for k in Organism.__dataclass_fields__ if k in raw}))
    if not pop.organisms:
        return seed_population(version)
    return pop
