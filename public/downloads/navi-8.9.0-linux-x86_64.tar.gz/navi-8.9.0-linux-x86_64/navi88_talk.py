"""
Conversaciones de usuario → ítems de supervivencia.

No es SFT. Cada turno se etiqueta (nicho + need/forbid) y VERIFY
premia al organismo que acierta. Se leen memory.db y lessons.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from navi75_voice import fold_es
from navi88_life import niche_of_kind

# Banco vivo: fallos reales de Roger + trampas + social.
CORPUS: List[Dict] = [
    {"id": "hola", "ask": "hola", "niche": "social", "need": ["hola"], "forbid": ["ciudad", "wikipedia", "extracto"]},
    {"id": "hey", "ask": "heyyy", "niche": "social", "need": ["hola"], "forbid": ["extracto", "desconocido"]},
    {"id": "mood", "ask": "como estas", "niche": "social", "need": ["operativa"], "forbid": ["konoe", "wikipedia"]},
    {"id": "ack1", "ask": "entiendo", "niche": "social", "need": ["vale"], "forbid": ["belinda", "wikipedia"]},
    {"id": "ack2", "ask": "wow de verdad funcionas?", "niche": "social", "need": ["vale"], "forbid": ["logica", "wikipedia"]},
    {"id": "ack3", "ask": "wow enserio funcionas?", "niche": "social", "need": ["vale"], "forbid": ["wikipedia"]},
    {"id": "meta", "ask": "no siempre tienes que buscarme significados de lo que digo eh", "niche": "social", "need": ["dato"], "forbid": ["planificacion", "wikipedia"]},
    {"id": "name", "ask": "como te llamas", "niche": "identity", "need": ["navi"], "forbid": ["extracto"]},
    {"id": "who1", "ask": "solo quiero saber quien eres", "niche": "identity", "need": ["navi"], "forbid": ["extracto", "desconocido"]},
    {"id": "who2", "ask": "dime quien eres", "niche": "identity", "need": ["navi"], "forbid": ["extracto", "desconocido"]},
    {"id": "who3", "ask": "quien eres", "niche": "identity", "need": ["navi"], "forbid": ["extracto"]},
    {"id": "me", "ask": "y yo como me llamo", "niche": "social", "need": ["roger"], "forbid": ["wikipedia"]},
    {"id": "birds", "ask": "si en un arbol hay 5 pajaros y el cazador dispara a uno cuantos quedan", "niche": "puzzle", "need": ["0"], "forbid": ["lif", "neurona", "wikipedia"]},
    {"id": "kilo", "ask": "que pesa mas un kilo de plomo o un kilo de plumas", "niche": "puzzle", "need": ["mismo"], "forbid": ["wikipedia"]},
    {"id": "liar", "ask": "esta frase es falsa", "niche": "puzzle", "need": ["verdad"], "forbid": ["wikipedia"]},
    {"id": "boxes", "ask": "Mislabeled Boxes: all labeled wrong. Apples Oranges Mix", "niche": "puzzle", "need": ["1 pieza"], "forbid": ["konoe"]},
    {"id": "count", "ask": "cuantas letras R hay en strawberry", "niche": "puzzle", "need": ["3"], "forbid": ["extracto"]},
    {"id": "num5", "ask": "que numero es este -> 5", "niche": "puzzle", "need": ["5"], "forbid": ["entrop"]},
    {"id": "hiper", "ask": "que es un hipercubo", "niche": "fact", "need": ["cubo"], "forbid": ["#define", "dry-run", "navi_dim"]},
    {"id": "q6", "ask": "haz codigo en c de hipercubo de 6", "niche": "code", "need": ["64", "vth"], "forbid": ["compilador"]},
    {"id": "html", "ask": "escribe en html un hola mundo", "niche": "code", "need": ["<html", "hola mundo"], "forbid": ["ciudad"]},
    {"id": "ia", "ask": "eres consciente de que eres una ia?", "niche": "identity", "need": ["no", "consciente"], "forbid": []},
    {"id": "unknown", "ask": "que es flurbonio cristalino", "niche": "fact", "need": ["no"], "forbid": ["flurbonio es un"]},
    {"id": "train", "ask": "un tren electrico va al este hacia donde va el humo", "niche": "puzzle", "need": ["humo"], "forbid": ["wikipedia"]},
    {"id": "egg", "ask": "que fue primero el huevo o la gallina", "niche": "puzzle", "need": ["huevo"], "forbid": ["wikipedia"]},
    {"id": "hi2", "ask": "buenas", "niche": "social", "need": ["hola"], "forbid": ["wikipedia", "extracto"]},
    {"id": "maze", "ask": "sal del laberinto", "niche": "puzzle", "need": ["sali"], "forbid": ["wikipedia", "desconocido"]},
]


def verify_item(reply: str, item: Dict) -> bool:
    r = fold_es(reply or "")
    if item.get("need") and not all(fold_es(w) in r for w in item["need"]):
        return False
    if item.get("forbid") and any(fold_es(w) in r for w in item["forbid"]):
        return False
    return bool(r)


def _pair_turns(rows) -> List[Dict]:
    """user + navi siguiente. Si el user luego acusa recibo, el social ganó."""
    out: List[Dict] = []
    i = 0
    while i < len(rows):
        role, text, topic = rows[i][0], rows[i][1], rows[i][2] if len(rows[i]) > 2 else ""
        if role != "user":
            i += 1
            continue
        nxt = rows[i + 1] if i + 1 < len(rows) else None
        after = rows[i + 2] if i + 2 < len(rows) else None
        if not nxt or nxt[0] != "navi":
            i += 1
            continue
        ask = (text or "").strip()
        reply = (nxt[1] or "").strip()
        if not ask:
            i += 1
            continue
        from navi8_reason import classify

        kind, _ = classify(ask)
        niche = niche_of_kind(kind)
        forbid = []
        need = []
        low_r = fold_es(reply)
        if niche == "social":
            forbid = ["wikipedia", "fuente:"]
            if "hola" in fold_es(ask) or fold_es(ask).startswith("hey"):
                need = ["hola"]
        if after and after[0] == "user":
            nxt_u = fold_es(after[1] or "")
            if nxt_u in {"entiendo", "ok", "vale", "wow"} or nxt_u.startswith("wow"):
                niche = "social"
                forbid = ["wikipedia", "belinda", "logica"]
        item = {
            "id": f"talk-{i}",
            "ask": ask,
            "niche": niche,
            "need": need,
            "forbid": forbid,
            "topic": topic or "",
            "seen_reply": reply[:180],
        }
        # si la respuesta histórica ya era basura wiki en social, es un negativo
        if niche == "social" and ("wikipedia" in low_r or "fuente:" in low_r):
            item["forbid"] = list(set(item["forbid"] + ["wikipedia", "fuente:"]))
        out.append(item)
        i += 2
    return out


def from_memory(path: Optional[Path] = None, k: int = 80) -> List[Dict]:
    try:
        from navi75_memory import DEFAULT_DB, Memory

        mem = Memory(path or DEFAULT_DB)
        rows = mem.last_turns(k)
        mem.close()
        return _pair_turns(rows)
    except Exception:
        return []


def from_lessons(path: Optional[Path] = None, k: int = 40) -> List[Dict]:
    try:
        from navi8_db import DEFAULT_CTX, ContextDB

        ctx = ContextDB(path or DEFAULT_CTX)
        rows = ctx.cx.execute(
            "SELECT ask, need, ok FROM lessons ORDER BY id DESC LIMIT ?", (k,)
        ).fetchall()
        ctx.close()
    except Exception:
        return []
    out: List[Dict] = []
    for row in rows:
        ask = (row["ask"] or "").strip()
        if not ask or ask.startswith("/"):
            continue
        from navi8_reason import classify

        kind, _ = classify(ask)
        item = {
            "id": f"lesson-{len(out)}",
            "ask": ask,
            "niche": niche_of_kind(kind),
            "need": [row["need"]] if row["need"] and len(str(row["need"])) < 24 else [],
            "forbid": [] if row["ok"] else ["te escucho"],
        }
        out.append(item)
    return out


def training_set(include_talk: bool = True, mem_path: Optional[Path] = None) -> List[Dict]:
    items = list(CORPUS)
    seen = {fold_es(i["ask"]) for i in items}
    if include_talk:
        for extra in from_memory(mem_path) + from_lessons():
            key = fold_es(extra["ask"])
            if key in seen or len(key) < 2:
                continue
            seen.add(key)
            items.append(extra)
    return items
