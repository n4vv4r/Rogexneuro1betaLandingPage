"""
NAVI 8.9 — dos conciencias recíprocas.

Inteligencia aquí = dos organismos se hablan:
  PROPOSE  sugiere una ruta y una respuesta
  CRITIC   VERIFY: ¿fuente, oracle, social sin Wikipedia?
Si el crítico tumba, responde el segundo. Si coinciden, hay acuerdo.

No es o3. Es el germen del multiagente de NAVI 9.
KCC: nadie se borra. El perdedor del debate se duerme si ya iba mal.
"""

from __future__ import annotations

from typing import Optional, Tuple

from navi75_voice import fold_es
from navi88_life import Population


def critic_ok(user: str, reply: str, route: str) -> bool:
    r = fold_es(reply or "")
    if not r or len(r) < 6:
        return False
    if r.startswith("te escucho"):
        return False
    if route == "social" and any(
        k in r for k in ("wikipedia", "fuente:", "belinda", "eigengrau")
    ):
        return False
    if route == "puzzle" and any(k in r for k in ("lif", "neurona", "wikipedia")):
        return False
    if "google (http" in r or r.startswith("resultados:"):
        return False
    return True


def debate(
    pop: Population,
    user: str,
    run,
) -> Tuple[str, str, str, list]:
    """Devuelve (reply, source, winner_id, trace)."""
    niche = pop.guess_niche(user)
    propose = pop.champion(niche)
    critic = pop.second(niche)
    route_p = propose.route(user)
    t_p = run(user, route_p)
    reply_p = getattr(t_p, "reply", "") or ""
    src_p = getattr(t_p, "source", "") or ""
    ok_p = critic_ok(user, reply_p, route_p)
    trace = [f"propose:{propose.id}", f"route:{route_p}", "propose✓" if ok_p else "propose✗"]
    if critic is None:
        return reply_p, src_p, propose.id, trace + ["solo"]
    route_c = critic.route(user)
    t_c = run(user, route_c)
    reply_c = getattr(t_c, "reply", "") or ""
    src_c = getattr(t_c, "source", "") or ""
    ok_c = critic_ok(user, reply_c, route_c)
    trace.append(f"critic:{critic.id}")
    trace.append("critic✓" if ok_c else "critic✗")
    if ok_p and ok_c:
        trace.append("acuerdo→propose")
        return reply_p, src_p, propose.id, trace
    if ok_p and not ok_c:
        trace.append("dual→propose")
        return reply_p, src_p, propose.id, trace
    if ok_c and not ok_p:
        trace.append("dual→critic")
        return reply_c, src_c, critic.id, trace
    # nadie verifica: honesto
    trace.append("dual✗")
    if reply_p:
        return reply_p, src_p, propose.id, trace
    return reply_c, src_c, critic.id, trace
