"""
NAVI 8.9 — 8.8 + dos conciencias + más generaciones.

Parte del host: el motor. La cara es tui/navi89.c + tui/navi89-rs
(el usuario cambia 8.8 ↔ 8.9 y ve fitness/generación).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from navi88_engine import NAVI88Engine, Turn88
from navi88_life import DEFAULT_POP, load_pop, save_pop
from navi89_dual import debate

DEFAULT_POP89 = Path("lab/navi89/pop.json")


@dataclass
class Turn89(Turn88):
    version: str = "8.9"
    voices: int = 2


class NAVI89Engine(NAVI88Engine):
    VERSION = "8.9"
    ROLE = "assistant-dual-conscience"

    def __init__(self, *args, pop_path: Optional[Path] = None, **kwargs) -> None:
        # no llamamos super().__init__ completo dos veces: rehacemos pop
        path = Path(pop_path) if pop_path else DEFAULT_POP89
        super().__init__(*args, pop_path=path, **kwargs)
        self.pop_path = path
        if not path.exists() and DEFAULT_POP.exists():
            # 8.9 nace de 8.8 (misma sangre, más debate)
            self.pop = load_pop(DEFAULT_POP, version="8.9")
            self.pop.version = "8.9"
        else:
            self.pop.version = "8.9"
        self.metrics["version"] = "8.9"
        self.metrics["debates"] = 0

    def think(self, user: str, live: Optional[bool] = None, isolated: bool = False) -> Turn89:
        use_live = self.live if live is None else live
        from navi75_voice import fold_es, looks_capability, looks_id, looks_self_conscious
        from navi89_maze import looks_maze, say_maze
        from navi89_reason import explain

        if looks_maze(user):
            reply = say_maze(user)
            turn = Turn89(
                user=user,
                reply=reply,
                mask="reason",
                ms=0.0,
                version="8.9",
                cards=[],
                live=False,
                source="oracle-maze",
                used_ctx=False,
                learned=False,
                plan=None,
                entropy=0.0,
                states=["maze", "bfs", "answer"],
                judged=False,
                budget=1,
                trace=["maze", "bfs", "exit" if "Salí" in reply else "stuck"],
                organism=self.pop.champion("puzzle").id,
                fitness=round(self.pop.champion("puzzle").fitness, 3),
                generation=self.pop.generation,
                voices=2,
            )
            turn.reason = explain(self, user, turn)
            return turn

        from navi75_voice import looks_bio_recall, looks_intro, looks_poem_feedback
        from navi86_skills import parse_age, parse_born

        if (
            looks_bio_recall(user)
            or looks_poem_feedback(user)
            or looks_intro(user)
            or parse_age(user)
            or parse_born(user)
            or fold_es(user).startswith("soy de ")
        ):
            t = self._run_route(user, "social", use_live, isolated)
            reply = (t.reply or "").replace("8.8 de rxOS", "8.9 de rxOS")
            turn = Turn89(
                user=user,
                reply=reply,
                mask=t.mask or "talk",
                ms=getattr(t, "ms", 0.0) or 0.0,
                version="8.9",
                cards=[],
                live=False,
                source=getattr(t, "source", "") or "memory",
                used_ctx=True,
                learned=False,
                plan=None,
                entropy=0.0,
                states=["social", "memory", "answer"],
                judged=False,
                budget=1,
                trace=["bio-override", "social"],
                organism=self.pop.champion("social").id,
                fitness=round(self.pop.champion("social").fitness, 3),
                generation=self.pop.generation,
                voices=2,
            )
            turn.reason = explain(self, user, turn)
            return turn

        if looks_id(user) or looks_self_conscious(user) or looks_capability(user):
            t = self._run_route(user, "identity", use_live, isolated)
            reply = (t.reply or "").replace("8.8 de rxOS", "8.9 de rxOS").replace(
                "8.7 de rxOS", "8.9 de rxOS"
            ).replace("8.6 de rxOS", "8.9 de rxOS")
            turn = Turn89(
                user=user,
                reply=reply,
                mask=t.mask or "talk",
                ms=getattr(t, "ms", 0.0) or 0.0,
                version="8.9",
                cards=getattr(t, "cards", None) or [],
                live=False,
                source=getattr(t, "source", "") or "seed-8",
                used_ctx=False,
                learned=False,
                plan=None,
                entropy=0.0,
                states=["identity", "answer"],
                judged=False,
                budget=1,
                trace=["id-override", "identity"],
                organism=self.pop.champion("identity").id,
                fitness=round(self.pop.champion("identity").fitness, 3),
                generation=self.pop.generation,
                voices=2,
            )
            turn.reason = explain(self, user, turn)
            return turn

        def run(u, route):
            return self._run_route(u, route, use_live, isolated)

        reply, src, winner, trace = debate(self.pop, user, run)
        self.metrics["debates"] += 1
        org = next((o for o in self.pop.organisms if o.id == winner), self.pop.champion("social"))
        reply = (reply or "").replace("8.8 de rxOS", "8.9 de rxOS").replace(
            "8.7 de rxOS", "8.9 de rxOS"
        ).replace("8.6 de rxOS", "8.9 de rxOS")
        turn = Turn89(
            user=user,
            reply=reply,
            mask="talk",
            ms=0.0,
            version="8.9",
            cards=[],
            live=bool(src.startswith("http")) if src else False,
            source=src,
            used_ctx=False,
            learned=False,
            plan=None,
            entropy=0.0,
            states=["propose", "critic", "answer"],
            judged=False,
            budget=2,
            trace=trace,
            organism=winner,
            fitness=round(org.fitness, 3),
            generation=self.pop.generation,
            voices=2,
        )
        turn.reason = explain(self, user, turn)
        return turn

    def inherit_88(self) -> None:
        if DEFAULT_POP.exists():
            self.pop = load_pop(DEFAULT_POP, version="8.9")
            self.pop.version = "8.9"

    def snapshot(self) -> dict:
        snap = super().snapshot()
        snap["version"] = "8.9"
        snap["voices"] = 2
        snap["life"] = self.pop.snapshot()
        return snap
