"""
Laberinto 2D — oráculo BFS.

No es un ratón que aprendió. Es un grafo + cola.
S = start, E = exit, # = muro, . = suelo.
"""

from __future__ import annotations

from collections import deque
from typing import List, Optional, Tuple

from navi75_voice import fold_es

DEFAULT = [
    "###########",
    "#S..#.....#",
    "#.##.#.#..#",
    "#.#....#.##",
    "#.###.##..#",
    "#.....#..E#",
    "###########",
]


def parse(lines: List[str]) -> Tuple[List[str], Tuple[int, int], Tuple[int, int]]:
    grid = [list(r) for r in lines if r.strip()]
    s = e = None
    for y, row in enumerate(grid):
        for x, c in enumerate(row):
            if c in "Ss":
                s = (x, y)
            if c in "Ee":
                e = (x, y)
    if s is None or e is None:
        raise ValueError("hace falta S y E")
    return ["".join(r) for r in grid], s, e


def solve(lines: Optional[List[str]] = None) -> dict:
    raw = lines or DEFAULT
    grid, start, end = parse(raw)
    w, h = len(grid[0]), len(grid)
    q = deque([(start, [start])])
    seen = {start}
    found = None
    while q:
        (x, y), path = q.popleft()
        if (x, y) == end:
            found = path
            break
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if nx < 0 or ny < 0 or nx >= w or ny >= h:
                continue
            if grid[ny][nx] == "#":
                continue
            if (nx, ny) in seen:
                continue
            seen.add((nx, ny))
            q.append(((nx, ny), path + [(nx, ny)]))
    painted = [list(r) for r in grid]
    if found:
        for x, y in found[1:-1]:
            if painted[y][x] == ".":
                painted[y][x] = "*"
    view = ["".join(r) for r in painted]
    return {
        "ok": found is not None,
        "steps": (len(found) - 1) if found else 0,
        "visited": len(seen),
        "view": view,
        "reason": [
            "PARSE laberinto 2D (S/E/#)",
            f"BFS cola 4-vecinos  visitados={len(seen)}",
            "SALIDA" if found else "SIN SALIDA",
            f"pasos={len(found) - 1}" if found else "atrapado",
        ],
    }


def looks_maze(user: str) -> bool:
    t = fold_es(user)
    if any(k in t for k in ("laberinto", "maze", "sal del laberinto", "resuelve el laberinto")):
        return True
    lines = [ln for ln in (user or "").splitlines() if ln.strip()]
    if len(lines) >= 3 and any("#" * 3 in ln for ln in lines):
        return "S" in user and "E" in user
    return False


def extract_grid(user: str) -> Optional[List[str]]:
    lines = [ln.rstrip("\n") for ln in (user or "").splitlines() if set(ln.strip()) <= set("#.SE se")]
    lines = [ln.strip() for ln in lines if ln.strip() and "#" in ln]
    if len(lines) >= 3:
        return lines
    return None


def say_maze(user: str) -> str:
    grid = extract_grid(user)
    r = solve(grid)
    body = "\n".join(r["view"])
    if r["ok"]:
        return (
            f"Salí. BFS, {r['steps']} pasos, {r['visited']} celdas vistas.\n"
            f"No es aprendizaje: es un grafo. * = camino.\n{body}"
        )
    return f"Sin salida. Visité {r['visited']} celdas. No invento un agujero.\n{body}"
