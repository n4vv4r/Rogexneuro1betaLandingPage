"""
Razonamiento interno visible. No es CoT de un LLM.

Cada línea es un paso VERIFY que ya ocurrió: clasificar, organismo,
ruta, propose/critic, ficha, laberinto.
"""

from __future__ import annotations

from typing import List

from navi75_voice import fold_es
from navi8_reason import classify
from navi88_life import niche_of_kind


def explain(eng, user: str, turn) -> List[str]:
    lines: List[str] = []
    kind, topics = classify(user)
    niche = niche_of_kind(kind)
    lines.append(f"PARSE  kind={kind}  nicho={niche}  temas={topics or '—'}")
    pop = getattr(eng, "pop", None)
    if pop:
        org = None
        oid = getattr(turn, "organism", "") or ""
        for o in pop.organisms:
            if o.id == oid:
                org = o
                break
        if org is None:
            org = pop.champion(niche)
        route = org.route(user)
        lines.append(
            f"ORG    {org.id}  fit={org.fitness:.2f}  vivo={int(org.alive)}  "
            f"gen={org.generation}"
        )
        lines.append(f"GENES  detectores={','.join(org.detectors[:8])}")
        lines.append(f"RUTA   {route}  (el organismo elige, no un token)")
    tr = list(getattr(turn, "trace", None) or [])
    if tr:
        lines.append("TRAZA  " + " → ".join(tr))
    src = getattr(turn, "source", "") or ""
    if src:
        lines.append(f"FUENTE {src}")
    cards = getattr(turn, "cards", None) or []
    if cards:
        lines.append("FICHAS " + ", ".join(str(c) for c in cards[:4]))
    reply = fold_es(getattr(turn, "reply", "") or "")
    if reply.startswith("no tengo"):
        lines.append("VERIFY no hay extracto → DESCONOCIDO (honesto)")
    elif "wikipedia" in reply or (src or "").startswith("http"):
        lines.append("VERIFY extracto con fuente")
    elif getattr(turn, "mask", "") in ("reason",) or "quedan 0" in reply:
        lines.append("VERIFY oráculo cerrado (no harvest)")
    else:
        lines.append("VERIFY respuesta de voz/oráculo local")
    extra = getattr(turn, "reason", None) or []
    for e in extra:
        if e not in lines:
            lines.append(str(e))
    lines.append(
        f"META   version={getattr(turn, 'version', '?')}  "
        f"voces={getattr(turn, 'voices', 1)}  "
        f"gen={getattr(turn, 'generation', 0)}"
    )
    return lines
