"""
Estadísticas medibles de 8.8 / 8.9.

Números reales (fichas, palabras, Q6=64 LIF). Las «neuronas de política»
son detectores + ejemplos: no son pesos de un transformer.
Sirve para --stats y para una ficha pre-beta, no para fingir un IQ.
"""

from __future__ import annotations

from typing import Dict, List

from navi75_voice import fold_es
from navi86_bulk import word_count
from navi88_talk import training_set, verify_item

Q6_NEURONS = 64  # LIF enteros del 6-cubo. 0% FPU.
Q6_EDGES = 64 * 6  # grado 6


def _examples(pop) -> int:
    return sum(len(o.examples) for o in pop.organisms)


def _detectors(pop) -> int:
    return sum(len(o.detectors) for o in pop.organisms if o.alive)


def _probe(eng, items: List[dict]) -> Dict:
    ok = 0
    social_ok = 0
    social_n = 0
    wiki_social = 0
    for it in items:
        t = eng.think(it["ask"], live=False, isolated=True)
        good = verify_item(t.reply, it)
        ok += int(good)
        if it.get("niche") == "social":
            social_n += 1
            social_ok += int(good)
            if "wikipedia" in fold_es(t.reply or ""):
                wiki_social += 1
    n = len(items) or 1
    return {
        "bank": n,
        "hits": ok,
        "rate": round(ok / float(n), 3),
        "social_rate": round(social_ok / float(social_n or 1), 3),
        "wiki_on_social": wiki_social,
    }


def collect(eng, probe: bool = True) -> dict:
    pop = getattr(eng, "pop", None)
    life = pop.snapshot() if pop else {}
    cards = len(eng.cat)
    words = word_count(eng)
    pages = 0
    lessons = 0
    try:
        snap = eng.ctx.snapshot()
        pages = int(snap.get("pages") or 0)
        lessons = int(snap.get("lessons") or 0)
    except Exception:
        pass
    units = _detectors(pop) if pop else 0
    ex = _examples(pop) if pop else 0
    # neuronas: Q6 (silicio) + unidades de política (organismos vivos)
    neurons = Q6_NEURONS + units
    board = {"truth": None, "skill": None, "calibration": None, "cost": "host CPU · 0 FPU · 0 GPU"}
    probe_r = {}
    if probe:
        items = [i for i in training_set(include_talk=False) if i.get("niche") != "fact" or "flurbonio" in i["ask"]]
        probe_r = _probe(eng, items)
        board["skill"] = probe_r["rate"]
        board["calibration"] = probe_r["social_rate"]
        board["truth"] = 1.0 if probe_r["wiki_on_social"] == 0 else round(
            1.0 - probe_r["wiki_on_social"] / float(max(1, probe_r["bank"])), 3
        )
    return {
        "model": getattr(eng, "VERSION", "?"),
        "generation": life.get("generation", 0),
        "voices": 2 if str(getattr(eng, "VERSION", "")).startswith("8.9") else 1,
        "fichas": cards,
        "palabras": words,
        "paginas": pages,
        "lecciones": lessons,
        "organismos_vivos": life.get("alive", 0),
        "organismos_dormidos": life.get("dormant", 0),
        "nacidos": life.get("born", 0),
        "ejemplos": ex,
        "neuronas_q6": Q6_NEURONS,
        "aristas_q6": Q6_EDGES,
        "unidades_politica": units,
        "neuronas": neurons,
        "fitness": life.get("best", {}),
        "ejes": board,
        "sonda": probe_r,
        "nota": (
            "neuronas = 64 LIF del cubo Q6 + detectores vivos. "
            "palabras = tokens de extractos con fuente. "
            "No es un LLM: sin ficha no inventa."
        ),
    }


def _c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m"


def _bar(v, width: int = 10) -> str:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return "·" * width
    x = max(0.0, min(1.0, x))
    n = int(round(x * width))
    col = "32" if x >= 0.8 else ("33" if x >= 0.5 else "31")
    return _c(col, "█" * n + "░" * (width - n))


def render(st: dict) -> str:
    fit = st.get("fitness") or {}
    ejes = st.get("ejes") or {}
    sonda = st.get("sonda") or {}
    acid = "38;2;0;230;160"
    blu = "38;2;80;180;255"
    dim = "90"
    head = _c(acid, f" NAVI {st.get('model')} ") + _c(dim, f" gen={st.get('generation')}  voces={st.get('voices')}")
    rows = [
        ("fichas", st.get("fichas"), "extractos con fuente"),
        ("palabras", st.get("palabras"), "tokens de ficha, no pretrain"),
        ("páginas", st.get("paginas"), "context.db"),
        ("lecciones", st.get("lecciones"), "ensayos VERIFY"),
        ("neuronas Q6", st.get("neuronas_q6"), "64 LIF · 0% FPU"),
        ("política", st.get("unidades_politica"), "detectores vivos"),
        ("ejemplos", st.get("ejemplos"), "enunciados clavados"),
        ("neuronas*", st.get("neuronas"), "Q6 + política (no GPT)"),
        ("vivos/dormidos", f"{st.get('organismos_vivos')}/{st.get('organismos_dormidos')}", "KCC: se duermen"),
        ("sonda", f"{sonda.get('hits', '—')}/{sonda.get('bank', '—')}  {sonda.get('rate', '—')}", "banco fijo"),
        ("verdad", ejes.get("truth"), _bar(ejes.get("truth"))),
        ("habilidad", ejes.get("skill"), _bar(ejes.get("skill"))),
        ("calibración", ejes.get("calibration"), _bar(ejes.get("calibration"))),
    ]
    for k, v in fit.items():
        rows.append((f"fit.{k}", v, _bar(v)))
    line = "─" * 72
    out = [
        head,
        _c(dim, line),
        _c(blu, f"{'métrica':<16}{'valor':>14}   nota"),
        _c(dim, line),
    ]
    for name, val, note in rows:
        out.append(f"{_c('1;37', f'{name:<16}')}{_c(acid, f'{str(val):>14}')}   {_c(dim, str(note))}")
    out.append(_c(dim, line))
    out.append(_c(dim, st.get("nota") or ""))
    out.append(_c(dim, "laberinto 2D = oráculo BFS, no un animal que aprendió el mapa."))
    return "\n".join(out)
