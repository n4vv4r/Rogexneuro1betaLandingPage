"""
Un comando: todas las maneras de entrenar 8.8 / 8.9.

No es SFT. Orden:
  1. heredar 8.8 (si 8.9)
  2. absorber tipos de fallo (identidad/social/puzzle) → ejemplos + detectores
  3. supervivencia VERIFY
  4. reps (refuerzo de fichas)
  5. bulk (palabras verificadas), si hay red
  6. coach (tablero)
Ctrl+C guarda población y sale.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Optional

from navi88_talk import training_set

REPORT = Path("lab/navi89/train_report.json")

_ID_FIRST = {
    "social": "ack",
    "identity": "id",
    "puzzle": "riddle",
    "code": "code",
    "fact": "question",
}


def absorb_types(eng) -> int:
    """Un fallo de tipo (identidad tratada como dato) se clava en el campeón."""
    n = 0
    for item in training_set(include_talk=True):
        niche = item.get("niche") or "fact"
        champ = eng.pop.champion(niche)
        routed = champ.route(item["ask"])
        if routed == niche:
            continue
        champ.learn_example(item["ask"])
        want = _ID_FIRST.get(niche)
        if want:
            dets = [d for d in champ.detectors if d != want]
            champ.detectors = [want] + dets
        n += 1
    # frases de identidad que el usuario ya usó
    ident = eng.pop.champion("identity")
    for phrase in (
        "quien eres",
        "dime quien eres",
        "solo quiero saber quien eres",
        "como te llamas",
        "hablame de ti",
    ):
        ident.learn_example(phrase)
    return n


def train(
    eng,
    generations: int = 8,
    bulk_n: int = 40,
    reps: int = 1,
    live: bool = True,
    from_88: bool = False,
    talk: bool = True,
) -> dict:
    t0 = time.time()
    phases = []
    print(
        f"[train {eng.VERSION}] survive+talk+tipos+reps+bulk+coach. "
        "VERIFY, no backprop. No reinicia 8.8 salvo --from-88.",
        flush=True,
    )
    empty = not getattr(eng, "pop", None) or not eng.pop.organisms
    if hasattr(eng, "inherit_88") and (from_88 or empty):
        try:
            before = eng.pop.generation
            eng.inherit_88()
            print(f"  [inherit88] gen {before} → {eng.pop.generation}", flush=True)
            phases.append({"phase": "inherit88", "ok": True})
        except Exception as e:
            phases.append({"phase": "inherit88", "ok": False, "err": str(e)})

    fixed = absorb_types(eng)
    print(f"  [tipos] {fixed} fallos clavados en el campeón", flush=True)
    phases.append({"phase": "types", "fixed": fixed})

    try:
        surv = eng.survive(generations=generations, include_talk=talk)
        phases.append({"phase": "survive", **{k: surv[k] for k in ("generations", "items") if k in surv}})
    except KeyboardInterrupt:
        print("\n[train] corte en survive — guardo.", flush=True)
        eng.save(pop_only=True)
        surv = {"cut": True}
        phases.append({"phase": "survive", "cut": True})

    if reps:
        try:
            from navi8_reps import rehearse

            print(f"  [reps] {reps}", flush=True)
            r = rehearse(eng, reps=reps, live=False)
            last = (r.get("curve") or [{}])[-1] if isinstance(r, dict) else {}
            phases.append({"phase": "reps", "rate": last.get("rate")})
        except KeyboardInterrupt:
            print("\n[train] corte en reps.", flush=True)
            eng.save(pop_only=True)
        except Exception as e:
            phases.append({"phase": "reps", "ok": False, "err": str(e)})

    if live and bulk_n:
        try:
            from navi86_bulk import bulk

            print(f"  [bulk] {bulk_n} fichas", flush=True)
            b = bulk(eng, n=bulk_n, live=True)
            phases.append({"phase": "bulk", "added": b.get("added"), "words": b.get("words")})
        except KeyboardInterrupt:
            print("\n[train] corte en bulk — guardo.", flush=True)
            eng.save(pop_only=True)
        except Exception as e:
            phases.append({"phase": "bulk", "ok": False, "err": str(e)})

    try:
        from navi85_coach import coach

        print("  [coach]", flush=True)
        c = coach(eng, live=False)
        phases.append(
            {
                "phase": "coach",
                "ok": c.get("ok") if isinstance(c, dict) else None,
                "n": c.get("n") if isinstance(c, dict) else None,
            }
        )
    except KeyboardInterrupt:
        print("\n[train] corte en coach.", flush=True)
    except Exception as e:
        phases.append({"phase": "coach", "ok": False, "err": str(e)})

    from navi89_stats import collect

    st = collect(eng, probe=True)
    eng.save()
    rep = {
        "version": getattr(eng, "VERSION", ""),
        "seconds": round(time.time() - t0, 2),
        "phases": phases,
        "stats": st,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[train] listo {rep['seconds']}s  → {REPORT}", flush=True)
    return rep
