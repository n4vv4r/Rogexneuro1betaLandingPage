"""
NAVI 8 — base de contexto local (SQLite).

Páginas visitadas, hechos, lecciones del drill y notas.
KCC: las páginas no se borran. Si hay extracto nuevo más largo, se refuerza.
"""

from __future__ import annotations

import sqlite3
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from navi7_schema import norm, tokens

DEFAULT_CTX = Path("lab/navi8/context.db")


class ContextDB:
    def __init__(self, path: Optional[Path] = None) -> None:
        self.path = Path(path) if path else DEFAULT_CTX
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.cx = sqlite3.connect(str(self.path))
        self.cx.row_factory = sqlite3.Row
        self.cx.executescript(
            """
            CREATE TABLE IF NOT EXISTS pages (
                url TEXT PRIMARY KEY,
                title TEXT,
                extract TEXT,
                fetched_at TEXT,
                hits INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS facts (
                key TEXT PRIMARY KEY,
                value TEXT,
                source TEXT,
                updated TEXT
            );
            CREATE TABLE IF NOT EXISTS lessons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT,
                ask TEXT,
                need TEXT,
                ok INTEGER,
                tries INTEGER
            );
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT,
                topic TEXT,
                text TEXT
            );
            """
        )
        self.cx.commit()

    def close(self) -> None:
        try:
            self.cx.close()
        except sqlite3.Error:
            pass

    def put_page(self, url: str, title: str, extract: str) -> None:
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.cx.execute(
            "INSERT INTO pages(url,title,extract,fetched_at,hits) VALUES(?,?,?,?,1) "
            "ON CONFLICT(url) DO UPDATE SET "
            "title=excluded.title, "
            "extract=CASE WHEN length(excluded.extract)>length(pages.extract) "
            "THEN excluded.extract ELSE pages.extract END, "
            "fetched_at=excluded.fetched_at, hits=pages.hits+1",
            (url, title or "", extract or "", now),
        )
        self.cx.commit()

    def find_pages(self, query: str, k: int = 4) -> List[Tuple[float, str, str, str]]:
        qtok = set(tokens(query))
        qn = norm(query)
        scored = []
        for row in self.cx.execute("SELECT url, title, extract FROM pages"):
            bag = set(tokens(row["title"] or "")) | set(tokens(row["url"] or ""))
            bag |= set(tokens((row["extract"] or "")[:200]))
            s = 0.0
            if qtok and bag:
                s = len(qtok & bag) / float(len(qtok | bag))
            tn = norm(row["title"] or "")
            un = norm(row["url"] or "")
            tflat = tn.replace(" ", "")
            qflat = qn.replace(" ", "")
            if qn and (qn in tn or qn in un or tn in qn):
                s += 0.55
            elif qflat and (qflat in tflat or qflat in un.replace(" ", "") or tflat in qflat):
                s += 0.50
            if s > 0.12:
                scored.append((s, row["url"], row["title"] or "", row["extract"] or ""))
        scored.sort(reverse=True)
        return scored[:k]

    def put_fact(self, key: str, value: str, source: str = "") -> None:
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.cx.execute(
            "INSERT INTO facts(key,value,source,updated) VALUES(?,?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, "
            "source=excluded.source, updated=excluded.updated",
            ((key or "").strip().lower(), value or "", source or "", now),
        )
        self.cx.commit()

    def fact(self, key: str) -> str:
        row = self.cx.execute(
            "SELECT value FROM facts WHERE key=?", ((key or "").strip().lower(),)
        ).fetchone()
        return (row["value"] if row else "") or ""

    def log_lesson(self, ask: str, need: str, ok: bool, tries: int) -> None:
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.cx.execute(
            "INSERT INTO lessons(ts,ask,need,ok,tries) VALUES(?,?,?,?,?)",
            (now, ask, need, int(ok), tries),
        )
        self.cx.commit()

    def weak_asks(self, k: int = 16) -> List[str]:
        """Preguntas que fallaron VERIFY, las más recientes primero."""
        rows = self.cx.execute(
            "SELECT ask, ok FROM lessons ORDER BY id DESC LIMIT 120"
        ).fetchall()
        out: List[str] = []
        seen = set()
        for row in rows:
            ask = (row["ask"] or "").strip()
            if not ask or ask in seen or row["ok"]:
                continue
            seen.add(ask)
            out.append(ask)
            if len(out) >= k:
                break
        return out

    def note(self, topic: str, text: str) -> None:
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.cx.execute(
            "INSERT INTO notes(ts,topic,text) VALUES(?,?,?)",
            (now, topic or "", text or ""),
        )
        self.cx.commit()

    def snapshot(self) -> Dict:
        n = {
            t: self.cx.execute(f"SELECT COUNT(*) c FROM {t}").fetchone()["c"]
            for t in ("pages", "facts", "lessons", "notes")
        }
        return {"path": str(self.path), **n}
