"""
NAVI 8 — 7.5 + contexto local + plan.

Si 7.5 no verifica (Te escucho / DESCONOCIDO / lista DDG), 8 mira la
base SQLite, cosecha la URL o el tema, guarda la página y reintenta.
Pregunta compuesta: un plan de temas, una ficha por tema, sin puente inventado.
No es un LLM. No hay backprop. Aprender = escribir extractos en disco.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

from navi7_lab import CAT_PATH
from navi75_engine import NAVI75Engine, Turn75
from navi75_harvest import harvest_topic, page_fits
from navi75_voice import fold_es, say_can, say_conscious, say_world, topic_from
from navi8_db import DEFAULT_CTX, ContextDB
from navi8_reason import (
    classify,
    clean_extract,
    is_conscious_denial,
    is_junk_extract,
    say_id8,
    synthesize,
)


def _weak(reply: str) -> bool:
    r = fold_es(reply or "")
    if r.startswith("te escucho"):
        return True
    if "desconocido" in r and "fuera de catalogo" not in r:
        return True
    if r.startswith("no tengo una ficha") or r.startswith("no tengo ficha"):
        return True
    if r.startswith("resultados:") or "google (http" in r:
        return True
    return False


def _solid_hit(card, topic: str, min_score: float = 0.28):
    from navi7_schema import tokens as tok
    from navi75_harvest import looks_code_extract

    qtok = set(tok(topic))
    bag = set(card.keyset()) | set(tok(card.title)) | set(tok(card.extract or ""))
    if is_junk_extract(card.extract or ""):
        return False
    want_code = any(
        k in fold_es(topic)
        for k in ("codigo", "q6", "haz codigo", "hipercubo de 6", "escribe")
    )
    if not want_code and looks_code_extract(card.extract or ""):
        return False
    if not page_fits(topic, card.title, card.extract or ""):
        return False
    distinctive = {
        w
        for w in qtok
        if len(w) >= 6
        and w not in {"teoria", "sistema", "metodo", "special", "statements", "problem"}
    }
    if distinctive and not (distinctive & bag):
        collapsed = fold_es(card.title).replace(" ", "")
        if not any(q.replace(" ", "") in collapsed or q in (card.source or "") for q in distinctive):
            return False
    elif qtok and not (qtok & bag):
        collapsed = fold_es(card.title).replace(" ", "")
        if not any(q.replace(" ", "") in collapsed or q in (card.source or "") for q in qtok):
            return False
    return True


@dataclass
class Turn8(Turn75):
    version: str = "8"
    used_ctx: bool = False
    learned: bool = False
    plan: Optional[List[str]] = None


class NAVI8Engine:
    VERSION = "8"
    ROLE = "assistant-context-db"

    def __init__(
        self,
        live: bool = True,
        db_path: Optional[Path] = None,
        ctx_path: Optional[Path] = None,
    ) -> None:
        self.base = NAVI75Engine(live=live, db_path=db_path)
        if CAT_PATH.exists():
            self.base.load(CAT_PATH)
        self.ctx = ContextDB(ctx_path or DEFAULT_CTX)
        self.live = live
        self.metrics = {
            "turns": 0,
            "ctx_hits": 0,
            "self_learn": 0,
            "weak": 0,
            "plans": 0,
            "joins": 0,
            "cal_short": 0,
            "version": "8",
        }

    @property
    def cat(self):
        return self.base.cat

    def _remember_card(self, card) -> None:
        if not card or is_junk_extract(card.extract or ""):
            return
        extract = clean_extract(card.extract, card.title)
        card.extract = extract
        self.base.cat.add(card)
        self.ctx.put_page(card.source or card.title, card.title, extract)

    def _gather(
        self, topics: List[str], use_live: bool
    ) -> Tuple[List[Tuple[str, str, str]], bool, bool]:
        """RETRIEVE catálogo → context.db → harvest. Una ficha por tema."""
        pieces: List[Tuple[str, str, str]] = []
        used_ctx = False
        learned = False
        for topic in topics:
            if not topic:
                continue
            found = None
            hits = self.cat.retrieve(topic, k=6)
            for card, score in hits:
                if score >= 0.28 and _solid_hit(card, topic):
                    found = (card.title, card.extract, card.source or "")
                    break
            if found is None:
                pages = self.ctx.find_pages(topic)
                if pages:
                    _s, url, title, extract = pages[0]
                    if extract and not is_junk_extract(extract):
                        found = (title or topic, extract, url)
                        used_ctx = True
                        self.metrics["ctx_hits"] += 1
            if found is None and use_live:
                card = harvest_topic(topic)
                if (
                    card
                    and card.extract
                    and not is_junk_extract(card.extract)
                    and page_fits(topic, card.title, card.extract)
                ):
                    self._remember_card(card)
                    found = (card.title, card.extract, card.source or "")
                    learned = True
                    self.metrics["self_learn"] += 1
            if found:
                title, extract, src = found
                extract = clean_extract(extract, title)
                key = fold_es(title).replace(" ", "")
                if any(fold_es(p[0]).replace(" ", "") == key for p in pieces):
                    continue
                pieces.append((title, extract, src))
        return pieces, used_ctx, learned

    def think(self, user: str, live: Optional[bool] = None, isolated: bool = False) -> Turn8:
        use_live = self.live if live is None else live
        last = ""
        if not isolated:
            try:
                last = self.base.mem.last_topic()
            except Exception:
                last = ""
        kind, topics = classify(user, last_topic=last)
        try:
            self.base.mem.save_turn(
                "user",
                user,
                kind,
                (topics[0] if topics else "") or topic_from(user),
            )
        except Exception:
            pass
        used_ctx = False
        learned = False
        plan = topics if kind == "compound" else None
        reply = ""
        source = ""
        mask = "talk"

        # Calibration: trivial stays short. No harvest.
        if kind == "puzzle":
            t = self.base.think(user, live=False)
            self.metrics["turns"] += 1
            return Turn8(
                user=t.user,
                reply=t.reply,
                mask="reason",
                ms=t.ms,
                version="8",
                cards=[],
                live=False,
                source="oracle-puzzle",
                used_ctx=False,
                learned=False,
                plan=None,
            )

        if kind == "search":
            t = self.base.think(user, live=use_live)
            self.metrics["turns"] += 1
            self.ctx.log_lesson(user, kind, not _weak(t.reply), 1)
            return Turn8(
                user=t.user,
                reply=t.reply,
                mask=t.mask or "news",
                ms=t.ms,
                version="8",
                cards=t.cards,
                live=t.live,
                source=t.source or "",
                used_ctx=False,
                learned=t.live,
                plan=None,
            )

        if kind == "opinion":
            from navi75_voice import say_feel

            last = ""
            try:
                last = self.base.mem.last_topic()
            except Exception:
                last = ""
            self.metrics["turns"] += 1
            return Turn8(
                user=user,
                reply=say_feel(last),
                mask="talk",
                ms=0.0,
                version="8",
                cards=[],
                live=False,
                source="seed-8",
                used_ctx=False,
                learned=False,
                plan=None,
            )

        if kind in ("trivial", "social", "too_big"):
            t = self.base.think(user, live=False)
            self.metrics["cal_short"] += 1
            self.metrics["turns"] += 1
            self.ctx.log_lesson(user, kind, True, 1)
            return Turn8(
                user=t.user,
                reply=t.reply,
                mask=t.mask,
                ms=t.ms,
                version="8",
                cards=t.cards,
                live=False,
                source=t.source or "",
                used_ctx=False,
                learned=False,
                plan=None,
            )

        if kind == "capability":
            self.metrics["turns"] += 1
            self.ctx.log_lesson(user, kind, True, 1)
            return Turn8(
                user=user,
                reply=say_can(),
                mask="talk",
                ms=0.0,
                version="8",
                cards=[],
                live=False,
                source="seed-8",
                used_ctx=False,
                learned=False,
                plan=None,
            )

        if kind == "code":
            t = self.base.think(user, live=False)
            self.metrics["turns"] += 1
            self.ctx.log_lesson(user, kind, not _weak(t.reply), 1)
            return Turn8(
                user=t.user,
                reply=t.reply,
                mask="code",
                ms=t.ms,
                version="8",
                cards=t.cards,
                live=False,
                source=t.source or "",
                used_ctx=False,
                learned=False,
                plan=None,
            )

        if kind == "identity":
            t = self.base.think(user, live=False)
            name = ""
            try:
                name = self.base.mem.fact("user_name")
            except Exception:
                name = ""
            reply = say_id8(len(self.cat), self.ctx.snapshot().get("pages", 0), name)
            self.metrics["turns"] += 1
            self.ctx.log_lesson(user, kind, True, 1)
            return Turn8(
                user=t.user,
                reply=reply,
                mask="talk",
                ms=t.ms,
                version="8",
                cards=[],
                live=False,
                source="seed-8",
                used_ctx=False,
                learned=False,
                plan=None,
            )

        if kind == "self_conscious":
            self.metrics["turns"] += 1
            self.ctx.log_lesson(user, kind, True, 1)
            return Turn8(
                user=user,
                reply=say_conscious().replace("NAVI 7.5", "NAVI 8"),
                mask="talk",
                ms=0.0,
                version="8",
                cards=[],
                live=False,
                source="seed-8",
                used_ctx=False,
                learned=False,
                plan=None,
            )

        # Strategy: compound → plan → gather → synthesize
        if kind == "compound" and topics:
            self.metrics["plans"] += 1
            pieces, used_ctx, learned = self._gather(topics, use_live)
            joined = synthesize(user, pieces)
            if joined:
                self.metrics["joins"] += 1
                reply = joined
                source = pieces[0][2] if pieces else ""
                mask = "teach"
                self.metrics["turns"] += 1
                self.ctx.log_lesson(user, " ".join(topics), True, 1 + int(learned))
                return Turn8(
                    user=user,
                    reply=reply,
                    mask=mask,
                    ms=0.0,
                    version="8",
                    cards=[p[0] for p in pieces],
                    live=learned,
                    source=source,
                    used_ctx=used_ctx,
                    learned=learned,
                    plan=plan,
                )

        t = self.base.think(user, live=use_live)
        reply = t.reply
        source = t.source
        mask = t.mask

        # Identity: 8, not 7.5
        if mask == "talk" and "me llamo navi" in fold_es(reply) and "7.5" in reply:
            name = ""
            try:
                name = self.base.mem.fact("user_name")
            except Exception:
                name = ""
            reply = say_id8(len(self.cat), self.ctx.snapshot().get("pages", 0), name)
            source = "seed-8"

        # Calibration: philosophical 'conciencia' must not stay as denial
        if kind != "self_conscious" and is_conscious_denial(reply):
            reply = ""
            mask = "unknown"

        # VERIFY: no robar talk/código/math. El tema tiene que estar en la ficha.
        if mask in ("talk", "code", "math", "poem"):
            self.metrics["turns"] += 1
            self.ctx.log_lesson(user, kind or mask, True, 1)
            return Turn8(
                user=t.user,
                reply=reply,
                mask=mask,
                ms=t.ms,
                version="8",
                cards=t.cards,
                live=t.live,
                source=source or "",
                used_ctx=False,
                learned=False,
                plan=plan,
            )

        if reply and topics:
            from navi7_schema import tokens as tok

            bag = set(tok(reply))
            need = {w for w in tok(topics[0]) if len(w) >= 5}
            if need and not (need & bag):
                reply = ""
                mask = "unknown"

        if _weak(reply) or not reply:
            self.metrics["weak"] += 1
            topic = (topics[0] if topics else "") or topic_from(user)
            pieces, used_ctx, learned = self._gather(
                topics or [topic], use_live
            )
            joined = synthesize(user, pieces)
            if joined:
                reply = joined
                source = pieces[0][2] if pieces else source
                mask = "news"
            elif use_live and topic:
                card = harvest_topic(topic)
                if (
                    card
                    and card.extract
                    and not is_junk_extract(card.extract)
                    and page_fits(topic, card.title, card.extract)
                ):
                    self._remember_card(card)
                    reply = say_world(
                        card.title,
                        clean_extract(card.extract, card.title),
                        card.source,
                        live=True,
                    )
                    source = card.source
                    learned = True
                    self.metrics["self_learn"] += 1
                    mask = "news"

        self.metrics["turns"] += 1
        self.ctx.log_lesson(user, "", not _weak(reply), 1 if not learned else 2)
        return Turn8(
            user=t.user,
            reply=reply,
            mask=mask,
            ms=t.ms,
            version="8",
            cards=t.cards,
            live=t.live or learned,
            source=source or "",
            used_ctx=used_ctx,
            learned=learned,
            plan=plan,
        )

    def learn(self, title: str) -> Optional[str]:
        card = harvest_topic(title)
        if not card or is_junk_extract(card.extract or ""):
            return None
        extract = clean_extract(card.extract, card.title)
        card.extract = extract
        self.base.cat.add(card)
        self.ctx.put_page(card.source or title, card.title, extract)
        self.base.save(CAT_PATH)
        return f"{card.title}\n{extract}\nfuente: {card.source}"

    def ingest(self, url: str) -> Optional[str]:
        return self.learn(url)

    def save(self) -> None:
        self.base.save(CAT_PATH)

    def snapshot(self) -> dict:
        snap = self.base.snapshot()
        snap["version"] = "8"
        snap["context"] = self.ctx.snapshot()
        snap["engine8"] = dict(self.metrics)
        return snap
