"""
NAVI 8 — Skills → Calibration → Strategy → Abstraction.

No es un LLM. No hay SFT, GRPO ni tokens de pensamiento.
La taxonomía de Lambert se traduce al bucle RLC:

  Skills      : math / código / harvest con verificador (extracto o eval).
  Calibration : presupuesto según dificultad; no sobrepensar un hola;
                no robar «conciencia» filosófica como identidad.
  Strategy    : pregunta compuesta → plan de temas → una ficha por tema.
  Abstraction : juntar extractos de catálogo + context.db; parar si VERIFY.

Anti-sincofantería: sin extracto no se afirma el puente.
Goodhart: el rate del drill no manda; un DESCONOCIDO honesto es correcto.
"""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

from navi66_lang import correct_text
from navi75_harvest import as_url, clean_extract
from navi75_voice import (
    fold_es,
    looks_capability,
    looks_code,
    looks_feel,
    looks_followup,
    looks_opinion,
    looks_greet,
    looks_search,
    looks_id,
    looks_intro,
    looks_meta_social,
    looks_ack,
    looks_mood,
    looks_name_recall,
    looks_place_recall,
    looks_bio_recall,
    looks_poem_feedback,
    looks_question,
    looks_self_conscious,
    looks_too_big,
    topic_from,
)
_TRIVIAL = (
    "hola",
    "hey",
    "buenos dias",
    "buenas tardes",
    "buenas",
    "gracias",
    "de nada",
    "adios",
    "hasta luego",
    "buenas noches",
    "como estas",
    "que tal",
    "como va",
    "como te va",
)

_SEPS = (
    " segun ",
    " entre ",
    " las ideas del ",
    " las ideas de ",
    " aparte de ",
    " versus ",
    " comparado con ",
    " y el ",
    " con el ",
    " con la ",
)

_BARE_PREFS = (
    "que es ",
    "que son ",
    "que hacen en ",
    "que hacen ",
    "que hace ",
    "quien fue ",
    "quien es ",
    "explica ",
    "define ",
    "como funciona ",
    "como junta ",
    "como se forma ",
    "como se ",
    "como ",
    "hablame de ",
    "de que trata ",
    "el proyecto de ",
    "proyecto de ",
    "busca ",
    "aprende ",
    "ensena ",
    "el ",
    "la ",
    "los ",
    "las ",
    "un ",
    "una ",
    "ideas del ",
    "ideas de ",
    "de ",
    "del ",
    "en ",
)

_BARE_SUFS = (
    " en sus sistemas",
    " en sus sistema",
    " sus sistemas",
    " en sus",
)


def bare_topic(s: str) -> str:
    t = fold_es(s or "").strip(" ?¿!.")
    changed = True
    while changed and t:
        changed = False
        for pref in _BARE_PREFS:
            if t.startswith(pref) and len(t) > len(pref) + 2:
                t = t[len(pref) :].strip(" ?¿!.")
                changed = True
                break
        for suf in _BARE_SUFS:
            if t.endswith(suf) and len(t) > len(suf) + 2:
                t = t[: -len(suf)].strip(" ?¿!.")
                changed = True
                break
    return t.strip(" ?¿!.")


def looks_trivial(low: str) -> bool:
    core = fold_es(low).strip(" ?¿!.")
    if looks_code(core) or "hola mundo" in core or "hello world" in core:
        return False
    if core in _TRIVIAL:
        return True
    return looks_greet(core)


def split_topics(user: str) -> List[str]:
    """Temas de una pregunta compuesta. Sin inventar entidades."""
    raw = (user or "").strip()
    low = fold_es(raw)
    out: List[str] = []
    rest = low
    url = as_url(raw)
    if url:
        out.append(url)
        host = fold_es(
            url.replace("https://", "").replace("http://", "").strip("/")
        )
        rest = rest.replace(host, " ")
        rest = rest.replace(host.replace("www.", ""), " ")
        rest = rest.replace(host.split("/")[0].replace("www.", ""), " ")

    split_done = False
    for sep in _SEPS:
        if sep in f" {rest} ":
            blob = f" {rest} "
            left, right = blob.split(sep, 1)
            for part in (left, right):
                p = bare_topic(part)
                if p and p not in out:
                    out.append(p)
            split_done = True
            break

    if not split_done:
        leftover = bare_topic(topic_from(rest) if rest.strip() else low)
        if leftover and leftover not in out:
            # no duplicar la pregunta entera si ya hay host
            if not (url and leftover == fold_es(raw).strip(" ?¿!.")):
                if leftover not in (fold_es(raw).strip(" ?¿!.")):
                    out.append(leftover)
                elif not url:
                    out.append(leftover)

    cleaned: List[str] = []
    seen = set()
    for t in out:
        t = bare_topic(t)
        if not t:
            continue
        if t in (
            "sus sistemas", "sistemas", "ideas", "humano", "humanos",
            "relacion", "relacion tiene", "y que relacion tiene",
        ):
            continue
        key = t.replace("https://", "").replace("http://", "").replace("www.", "").strip("/")
        key = key.replace(".com", "").replace(".club", "").replace(" ", "")
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(t)
    return cleaned


def classify(user: str, last_topic: str = "") -> Tuple[str, List[str]]:
    """Devuelve (fase, temas). Clasifica el texto ya corregido si se puede."""
    try:
        cleaned = correct_text(user).text or user
    except Exception:
        cleaned = user
    from navi86_skills import looks_english_prompt, parse_age, parse_born, solve_closed

    if looks_english_prompt(user or ""):
        cleaned = user
        low = fold_es(user)
    low = fold_es(cleaned)
    if solve_closed(user or cleaned):
        return "puzzle", []
    try:
        from navi89_maze import looks_maze

        if looks_maze(user or cleaned):
            return "puzzle", []
    except Exception:
        pass
    if parse_age(user or cleaned) or parse_born(user or cleaned):
        return "social", []
    if "kcc" in low and (
        "knights computer" in low or "siglas" in low or low.startswith("kcc es ")
    ):
        return "social", []
    if looks_self_conscious(low):
        return "self_conscious", []
    if looks_capability(low):
        return "capability", []
    if looks_id(low):
        return "identity", []
    if looks_too_big(low):
        return "too_big", []
    if looks_opinion(low):
        return "opinion", []
    if looks_feel(low):
        return "social", []
    if looks_search(low) or looks_search(fold_es(user)):
        t = topic_from(user)
        return "search", [t] if t else []
    if looks_code(low):
        return "code", []
    if looks_ack(low) or looks_ack(fold_es(user)):
        return "social", []
    if looks_trivial(low):
        return "trivial", []
    if (
        looks_intro(low)
        or looks_mood(low)
        or looks_meta_social(low)
        or looks_bio_recall(low)
        or looks_name_recall(low)
        or looks_place_recall(low)
        or looks_poem_feedback(low)
    ):
        return "social", []
    topics = split_topics(cleaned)
    if looks_followup(low) and last_topic:
        prev = bare_topic(last_topic)
        if prev and prev not in topics:
            topics = [prev] + topics
        topics = [t for t in topics if t not in ("relacion", "relacion tiene")]
        if len(topics) >= 2:
            return "compound", topics
        return "fact", topics or [prev]
    if len(topics) >= 2:
        return "compound", topics
    if looks_question(low):
        t = topics[0] if topics else bare_topic(topic_from(cleaned))
        return "fact", [t] if t else [bare_topic(cleaned)]
    return "other", topics


def is_conscious_denial(reply: str) -> bool:
    r = fold_es(reply or "")
    return r.startswith("no. no soy consciente") or r.startswith(
        "no. no soy consciente ni tengo"
    )


def is_junk_extract(extract: str) -> bool:
    e = (extract or "").strip()
    if not e:
        return True
    if e.startswith("Resultados:") or e.lower().startswith("google (http"):
        return True
    return False


def synthesize(
    user: str,
    pieces: Sequence[Tuple[str, str, str]],
) -> Optional[str]:
    """Junta extractos. Si no hay puente en ficha, lo dice."""
    solid = [
        (t, e, s)
        for t, e, s in pieces
        if e and not is_junk_extract(e)
    ]
    if not solid:
        return None
    if len(solid) == 1:
        title, extract, source = solid[0]
        src = f" Fuente: {source}." if source else ""
        return f"{extract}{src}"
    bits: List[str] = []
    for title, extract, source in solid:
        src = f" ({source})" if source else ""
        bits.append(f"{title}{src}: {extract}")
    bits.append(
        "En las fichas no hay un extracto que una estos temas. "
        "No invento el puente. Si tienes una URL o un texto, /learn."
    )
    return " ".join(bits)


def say_id8(n_cards: int, n_pages: int, user_name: str = "") -> str:
    who = (user_name or "").strip().split()[0] if user_name else ""
    hello = f"Hola, {who}. " if who else ""
    return (
        f"{hello}Me llamo NAVI. Soy la 8 de rxOS: 7.5 más una base de "
        f"contexto local. Llevo {n_cards} fichas y {n_pages} páginas en disco. "
        "Si VERIFY falla, miro esa base y, si hace falta, cosecho. "
        "No soy un LLM: sin extracto no invento."
    )
