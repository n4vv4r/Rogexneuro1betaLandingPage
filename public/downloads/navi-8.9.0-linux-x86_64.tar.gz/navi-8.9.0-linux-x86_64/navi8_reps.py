"""
Ensayos con VERIFY. Más repeticiones = retrieve más picado.

No es backprop. Cada ronda:
  acierto → refuerza la ficha (score++)
  fallo   → cosecha si hay red y reintenta
La curva de acierto debería subir (o quedarse alta). KCC: no se borra.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Dict, List, Optional

from navi75_drill import DRILLS
from navi75_voice import fold_es, looks_followup, topic_from
from navi8_reason import is_junk_extract

REPORT_PATH = Path("lab/navi8/reps_report.json")
BANK_CAP = 28


def _verify(reply: str, need: Optional[List[str]], title: str = "") -> bool:
    r = fold_es(reply or "")
    if not r or r.startswith("te escucho"):
        return False
    if r.startswith("no tengo") or "no invento" in r[:80]:
        return False
    if r.startswith("desconocido") or r.startswith("resultados:"):
        return False
    if need:
        return all(fold_es(w) in r for w in need)
    if title:
        toks = [w for w in fold_es(title).split() if len(w) >= 4]
        if toks and not any(w in r for w in toks):
            return False
    return len(r) > 24


def _bank(eng) -> List[Dict]:
    items: List[Dict] = []
    seen = set()

    def add(ask: str, need=None, harvest=None, title=""):
        key = fold_es(ask)
        if not ask or key in seen:
            return
        seen.add(key)
        items.append(
            {"ask": ask, "need": need or [], "harvest": harvest, "title": title}
        )

    if hasattr(eng, "ctx"):
        for ask in eng.ctx.weak_asks(8):
            if len(ask.split()) > 14 or looks_followup(ask):
                continue
            add(ask, harvest=topic_from(ask))

    add("soy Roger", ["roger", "encantad"], None, "intro")
    add("como me llamo", ["roger"], None, "recall")
    add("estoy triste", ["siento"], None, "mood")
    add("escribe un hola mundo en c", ["printf", "hola mundo"], None, "hello")
    add("escribe en html un hola mundo", ["html", "hola mundo"], None, "hello-html")
    for d in DRILLS:
        add(d["ask"], d.get("need"), d.get("harvest"), d.get("id"))

    cards = list(eng.cat.cards.values())
    cards.sort(key=lambda c: (int(c.score or 0), int(c.hits or 0)))
    for c in cards:
        title = (c.title or "").strip()
        if is_junk_extract(c.extract or ""):
            continue
        if not title or len(title) > 48 or len(title.split()) > 5:
            continue
        if any(x in title.lower() for x in ("http", "—", "smoke", "login")):
            continue
        add(f"qué es {title}", [title.split()[0][:8]], title, title)
        if len(items) >= BANK_CAP:
            break

    return items[:BANK_CAP]


def _one(eng, item: Dict, live: bool) -> Dict:
    t = eng.think(item["ask"], live=live, isolated=True)
    reply = t.reply or ""
    ok = _verify(reply, item.get("need"), item.get("title") or "")
    harvested = False
    if not ok and live and item.get("harvest"):
        if hasattr(eng, "learn"):
            eng.learn(item["harvest"])
        elif hasattr(eng, "base") and hasattr(eng.base, "learn_title"):
            eng.base.learn_title(item["harvest"])
        harvested = True
        t = eng.think(item["ask"], live=live, isolated=True)
        reply = t.reply or ""
        ok = _verify(reply, item.get("need"), item.get("title") or "")
    if ok:
        title = item.get("title") or item.get("harvest") or topic_from(item["ask"])
        if title:
            eng.cat.reinforce(title)
    return {
        "ok": ok,
        "harvested": harvested,
        "ask": item["ask"],
        "head": reply.replace("\n", " ")[:100],
    }


def rehearse(eng, reps: int = 3, live: bool = True) -> dict:
    """N rondas sobre el mismo banco. La tasa debería no bajar."""
    reps = max(1, int(reps))
    Path("lab/navi8").mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    bank = _bank(eng)
    print(
        f"[reps] {reps} ensayos × {len(bank)} preguntas. "
        "Acierto refuerza ficha. Fallo cosecha. No es backprop.",
        flush=True,
    )
    curve = []
    interrupted = False
    try:
        for i in range(1, reps + 1):
            ok = 0
            harvested = 0
            reinforced = 0
            for item in bank:
                row = _one(eng, item, live=live)
                ok += int(row["ok"])
                harvested += int(row["harvested"])
                if row["ok"]:
                    reinforced += 1
            rate = round(ok / float(len(bank) or 1), 3)
            curve.append(
                {
                    "rep": i,
                    "ok": ok,
                    "n": len(bank),
                    "rate": rate,
                    "harvested": harvested,
                    "reinforced": reinforced,
                    "cards": len(eng.cat),
                }
            )
            print(
                f"  [rep {i}/{reps}] {ok}/{len(bank)} rate={rate:.3f}  "
                f"cards={len(eng.cat)}  harvest={harvested}  +score={reinforced}",
                flush=True,
            )
            eng.save()
    except KeyboardInterrupt:
        interrupted = True
        print("\n[reps] cortado — guardo lo reforzado.", flush=True)
        eng.save()

    rates = [c["rate"] for c in curve]
    report = {
        "started": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "method": "rehearse-VERIFY (no backprop)",
        "reps": reps,
        "bank": len(bank),
        "curve": curve,
        "first": rates[0] if rates else 0.0,
        "last": rates[-1] if rates else 0.0,
        "delta": round((rates[-1] - rates[0]), 3) if len(rates) >= 2 else 0.0,
        "cards": len(eng.cat),
        "seconds": round(time.time() - t0, 2),
        "interrupted": interrupted,
        "kcc_destroyed": 0,
    }
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def print_reps(rep: dict) -> None:
    print("=== NAVI ensayos ===")
    print(
        f"reps={rep.get('reps')}  bank={rep.get('bank')}  "
        f"cards={rep.get('cards')}  {rep.get('seconds')}s"
    )
    rates = [c["rate"] for c in (rep.get("curve") or [])]
    if rates:
        arrow = " → ".join(f"{r:.2f}" for r in rates)
        print(f"CURVA  {arrow}   Δ={rep.get('delta'):+.3f}")
    print(f"report → {REPORT_PATH}")
    if (rep.get("last") or 0) < (rep.get("first") or 0):
        print("nota: la curva bajó — un harvest sucio o un banco distinto. KCC no poda.")
