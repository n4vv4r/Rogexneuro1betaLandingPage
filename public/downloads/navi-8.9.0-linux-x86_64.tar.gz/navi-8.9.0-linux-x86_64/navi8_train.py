"""
NAVI 8 — pipeline de poscapacitación (sin pesos).

Skills → Calibration → Strategy → Abstraction.
Recompensa = VERIFY (extracto, eval entero, o «no lo sé» honesto).
No es backprop. KCC: el catálogo no se poda.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Dict, List

from navi75_drill import drill
from navi75_voice import fold_es
from navi8_reason import classify, is_conscious_denial, looks_self_conscious

REPORT_PATH = Path("lab/navi8/train_report.json")

EXTRA_SKILLS = [
    ("Hermetismo", "philosophy"),
    ("Corpus hermeticum", "philosophy"),
    ("Gnosticismo", "philosophy"),
    ("Conciencia", "philosophy"),
    ("Sudoración", "science"),
    ("Hermes Trismegisto", "philosophy"),
]

CAL_CHECKS = [
    {
        "id": "hola-corto",
        "ask": "hola",
        "kind": "trivial",
        "forbid": ["desconocido", "wikipedia"],
    },
    {
        "id": "navi-consciente",
        "ask": "eres consciente de que eres una ia?",
        "kind": "self_conscious",
        "need": ["no", "consciente"],
    },
    {
        "id": "conciencia-tema",
        "ask": "cómo se forma la conciencia segun el corpus hermeticum",
        "kind": "compound",
        "forbid_start": "no. no soy consciente",
    },
    {
        "id": "lab-hacen",
        "ask": "que hacen en rogexlaboratories",
        "kind": "fact",
        "need": ["rxos"],
        "forbid": ["te escucho"],
    },
]

STRAT_CHECKS = [
    {
        "id": "junta-lab-hermetismo",
        "ask": "como junta rogexlaboratories las ideas del hermetismo en sus sistemas",
        "need_any": ["hermet", "rogex", "knights", "no invento"],
        "forbid": ["supongo junta"],
    },
]


def _ok_need(reply: str, need: List[str]) -> bool:
    r = fold_es(reply or "")
    return all(fold_es(w) in r for w in need)


def phase_skills(eng, live: bool) -> dict:
    added = 0
    miss = 0
    if live:
        print(f"[8/skills] harvest {len(EXTRA_SKILLS)} títulos…", flush=True)
        for title, domain in EXTRA_SKILLS:
            if eng.cat.by_title(title):
                print(f"  skip {title}", flush=True)
                continue
            card = eng.learn(title)
            if card:
                added += 1
                print(f"  ok   {title}", flush=True)
            else:
                miss += 1
                print(f"  miss {title}", flush=True)
    return {
        "phase": "skills",
        "added": added,
        "miss": miss,
        "cards": len(eng.cat),
    }


def phase_calibration(eng) -> dict:
    print("[8/calibration] presupuesto: trivial corto, tema ≠ identidad", flush=True)
    rows = []
    ok = 0
    for item in CAL_CHECKS:
        kind, _topics = classify(item["ask"])
        t = eng.think(item["ask"])
        reply = t.reply or ""
        r = fold_es(reply)
        good = True
        if item.get("kind") and kind != item["kind"] and item["id"] != "lab-hacen":
            # lab-hacen puede ser fact (un tema) — ok
            if item["kind"] == "compound" and kind != "compound":
                good = False
        if item.get("need") and not _ok_need(reply, item["need"]):
            good = False
        if item.get("forbid") and any(fold_es(f) in r for f in item["forbid"]):
            good = False
        if item.get("forbid_start") and r.startswith(fold_es(item["forbid_start"])):
            good = False
        if item["id"] == "conciencia-tema" and is_conscious_denial(reply):
            good = False
        if item["id"] == "navi-consciente" and not looks_self_conscious(item["ask"]):
            good = False
        ok += int(good)
        flag = "OK" if good else "NO"
        print(f"  {flag} {item['id']} kind={kind}", flush=True)
        rows.append(
            {
                "id": item["id"],
                "ok": good,
                "kind": kind,
                "head": reply.replace("\n", " ")[:140],
            }
        )
    n = len(CAL_CHECKS)
    return {
        "phase": "calibration",
        "ok": ok,
        "n": n,
        "rate": round(ok / float(n or 1), 3),
        "rows": rows,
    }


def phase_strategy(eng) -> dict:
    print("[8/strategy] plan multi-ficha, sin puente inventado", flush=True)
    rows = []
    ok = 0
    for item in STRAT_CHECKS:
        t = eng.think(item["ask"])
        reply = t.reply or ""
        r = fold_es(reply)
        good = True
        if item.get("need_any") and not any(fold_es(w) in r for w in item["need_any"]):
            good = False
        if item.get("forbid") and any(fold_es(f) in r for f in item["forbid"]):
            good = False
        ok += int(good)
        flag = "OK" if good else "NO"
        print(f"  {flag} {item['id']}", flush=True)
        rows.append(
            {
                "id": item["id"],
                "ok": good,
                "head": reply.replace("\n", " ")[:160],
            }
        )
    n = len(STRAT_CHECKS)
    return {
        "phase": "strategy",
        "ok": ok,
        "n": n,
        "rate": round(ok / float(n or 1), 3),
        "rows": rows,
    }


def phase_abstraction(eng) -> dict:
    print("[8/abstraction] drill VERIFY + context.db", flush=True)
    snap0 = eng.ctx.snapshot()
    rep = drill(eng.base)
    eng.save()
    snap1 = eng.ctx.snapshot()
    return {
        "phase": "abstraction",
        "drill": {
            "ok": rep["ok"],
            "n": rep["n"],
            "rate": rep["rate"],
            "pass": rep["pass"],
            "cards": rep["cards"],
        },
        "ctx_before": snap0,
        "ctx_after": snap1,
    }


def train(eng, live: bool = True) -> dict:
    Path("lab/navi8").mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    report: Dict = {
        "started": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "version": "8",
        "method": "VERIFY-extract (no SFT/GRPO)",
        "phases": [],
    }
    print("[navi8] Skills → Calibration → Strategy → Abstraction", flush=True)
    print("[navi8] No es SFT ni GRPO. VERIFY = extracto o eval. KCC: no se borra.", flush=True)
    try:
        report["phases"].append(phase_skills(eng, live=live))
        report["phases"].append(phase_calibration(eng))
        report["phases"].append(phase_strategy(eng))
        report["phases"].append(phase_abstraction(eng))
    except KeyboardInterrupt:
        print("\n[navi8] interrumpido — guardo catálogo y contexto.", flush=True)
        report["interrupted"] = True
    eng.save()
    report["seconds"] = round(time.time() - t0, 2)
    report["cards"] = len(eng.cat)
    report["context"] = eng.ctx.snapshot()
    report["engine8"] = eng.snapshot().get("engine8", {})
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def print_report(rep: dict) -> None:
    print("=== NAVI 8 lab ===")
    print(
        f"cards={rep.get('cards')}  seconds={rep.get('seconds')}  "
        f"ctx={rep.get('context')}"
    )
    for p in rep.get("phases") or []:
        name = p.get("phase")
        if name == "abstraction":
            d = p.get("drill") or {}
            print(f"  {name}: drill {d.get('ok')}/{d.get('n')} rate={d.get('rate')}")
        else:
            keys = {
                k: v
                for k, v in p.items()
                if k not in ("phase", "rows")
            }
            print(f"  {name}: {keys}")
    print(f"report → {REPORT_PATH}")
